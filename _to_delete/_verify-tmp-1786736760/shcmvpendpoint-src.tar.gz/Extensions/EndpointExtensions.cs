using ShcMvpEndPoint.Features.Auth.ChangePassword;
using ShcMvpEndPoint.Features.Auth.ForgotPassword;
using ShcMvpEndPoint.Features.Auth.Login;
using ShcMvpEndPoint.Features.Auth.Logout;
using ShcMvpEndPoint.Features.Auth.Refresh;
using ShcMvpEndPoint.Features.Auth.ResetPassword;
using ShcMvpEndPoint.Features.Auth.SwitchEmpresa;
using ShcMvpEndPoint.Features.Empresas.ActualizarAsignacion;
using ShcMvpEndPoint.Features.Empresas.ActualizarEmpresa;
using ShcMvpEndPoint.Features.Empresas.AsignarUsuarioEmpresa;
using ShcMvpEndPoint.Features.Empresas.CrearEmpresa;
using ShcMvpEndPoint.Features.Empresas.ListarEmpresas;
using ShcMvpEndPoint.Features.Empresas.ListarUsuariosEmpresa;

namespace ShcMvpEndPoint.Extensions;

// Vive en el host (no en ShcMvpEndPoint.Infrastructure) porque referencia tipos de
// Features/ — Infrastructure no puede depender del host sin crear una referencia circular
// (ver dotnet-vsa-rules skill, sección 3: Infrastructure -> Domain únicamente).
public static class EndpointExtensions
{
    public static void MapFeatureEndpoints(this IEndpointRouteBuilder app)
    {
        // Auth
        LoginEndpoint.Map(app);
        RefreshEndpoint.Map(app);
        SwitchEmpresaEndpoint.Map(app);
        LogoutEndpoint.Map(app);
        ForgotPasswordEndpoint.Map(app);
        ResetPasswordEndpoint.Map(app);
        ChangePasswordEndpoint.Map(app);

        // Empresas
        ListarEmpresasEndpoint.Map(app);
        CrearEmpresaEndpoint.Map(app);
        ActualizarEmpresaEndpoint.Map(app);
        ListarUsuariosEmpresaEndpoint.Map(app);
        AsignarUsuarioEmpresaEndpoint.Map(app);
        ActualizarAsignacionEndpoint.Map(app);
    }

    public static void AddFeatureHandlers(this IServiceCollection services)
    {
        // Auth
        services.AddScoped<LoginHandler>();
        services.AddScoped<RefreshHandler>();
        services.AddScoped<SwitchEmpresaHandler>();
        services.AddScoped<LogoutHandler>();
        services.AddScoped<ForgotPasswordHandler>();
        services.AddScoped<ResetPasswordHandler>();
        services.AddScoped<ChangePasswordHandler>();

        // Empresas
        services.AddScoped<ListarEmpresasHandler>();
        services.AddScoped<CrearEmpresaHandler>();
        services.AddScoped<ActualizarEmpresaHandler>();
        services.AddScoped<ListarUsuariosEmpresaHandler>();
        services.AddScoped<AsignarUsuarioEmpresaHandler>();
        services.AddScoped<ActualizarAsignacionHandler>();
    }
}
