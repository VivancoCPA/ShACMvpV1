using Dapper;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Persistence;

namespace ShcMvpEndPoint.Features.Empresas.ListarUsuariosEmpresa;

public sealed class ListarUsuariosEmpresaHandler(DapperConnectionFactory connectionFactory)
{
    public async Task<IEnumerable<UsuarioEmpresaListItem>> HandleAsync(Guid empresaId, CancellationToken ct)
    {
        using var connection = connectionFactory.CreateConnection();

        const string existsSql = "SELECT 1 FROM empresas WHERE id = @EmpresaId";
        var exists = await connection.ExecuteScalarAsync<int?>(new CommandDefinition(existsSql, new { EmpresaId = empresaId }, cancellationToken: ct));
        if (exists is null)
            throw new NotFoundException("Empresa no encontrada");

        const string sql = """
            SELECT ue.usuario_id AS "UsuarioId", ue.empresa_id AS "EmpresaId", ue.rol AS "Rol",
                   ue.estado AS "Estado", ue.fecha_asignacion AS "FechaAsignacion",
                   u.nombre AS "UsuarioNombre", u.apellido AS "UsuarioApellido",
                   u.email AS "UsuarioEmail", u.avatar_url AS "UsuarioAvatarUrl"
            FROM usuarios_empresa ue
            JOIN asp_net_users u ON u.id = ue.usuario_id
            WHERE ue.empresa_id = @EmpresaId
            ORDER BY ue.fecha_asignacion
            """;

        return await connection.QueryAsync<UsuarioEmpresaListItem>(
            new CommandDefinition(sql, new { EmpresaId = empresaId }, cancellationToken: ct));
    }
}
