namespace ShcMvpEndPoint.Features.Empresas.ListarUsuariosEmpresa;

public sealed record UsuarioEmpresaListItem(
    Guid UsuarioId,
    Guid EmpresaId,
    string Rol,
    string Estado,
    DateTime FechaAsignacion,
    string UsuarioNombre,
    string UsuarioApellido,
    string UsuarioEmail,
    string? UsuarioAvatarUrl);
