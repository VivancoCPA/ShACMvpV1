using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Features.Empresas.ListarUsuariosEmpresa;

public static class ListarUsuariosEmpresaEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapGet("/api/empresas/{id:guid}/usuarios", Handle)
           .RequireAuthorization(p => p.RequireRole(nameof(UserRole.SUPERADMIN)))
           .WithTags("Empresas")
           .WithName("ListarUsuariosEmpresa");

    private static async Task<IResult> Handle(Guid id, ListarUsuariosEmpresaHandler handler, CancellationToken ct)
    {
        var asignaciones = await handler.HandleAsync(id, ct);
        return Results.Ok(ApiResponse.Ok(asignaciones));
    }
}
