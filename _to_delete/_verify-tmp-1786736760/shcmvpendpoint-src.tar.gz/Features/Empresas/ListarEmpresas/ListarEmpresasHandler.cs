using Dapper;
using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Infrastructure.Persistence;

namespace ShcMvpEndPoint.Features.Empresas.ListarEmpresas;

public sealed class ListarEmpresasHandler(DapperConnectionFactory connectionFactory)
{
    public async Task<IEnumerable<Empresa>> HandleAsync(CancellationToken ct)
    {
        using var connection = connectionFactory.CreateConnection();

        const string sql = """
            SELECT id AS "Id", razon_social AS "RazonSocial", ruc AS "Ruc",
                   estado AS "Estado", logo_url AS "LogoUrl", fecha_alta AS "FechaAlta"
            FROM empresas
            ORDER BY razon_social
            """;

        return await connection.QueryAsync<Empresa>(new CommandDefinition(sql, cancellationToken: ct));
    }
}
