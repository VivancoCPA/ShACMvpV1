using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Features.Empresas.ListarEmpresas;

public static class ListarEmpresasEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapGet("/api/empresas", Handle)
           .RequireAuthorization(p => p.RequireRole(nameof(UserRole.SUPERADMIN)))
           .WithTags("Empresas")
           .WithName("ListarEmpresas");

    private static async Task<IResult> Handle(ListarEmpresasHandler handler, CancellationToken ct)
    {
        var empresas = await handler.HandleAsync(ct);
        return Results.Ok(ApiResponse.Ok(empresas));
    }
}
