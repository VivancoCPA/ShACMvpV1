using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Features.Empresas.ActualizarAsignacion;

public sealed record ActualizarAsignacionCommand(UsuarioEmpresaEstado Estado);
