using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Features.Empresas.ActualizarAsignacion;

public static class ActualizarAsignacionEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPatch("/api/empresas/{id:guid}/usuarios/{usuarioId:guid}", Handle)
           .RequireAuthorization(p => p.RequireRole(nameof(UserRole.SUPERADMIN)))
           .WithTags("Empresas")
           .WithName("ActualizarAsignacionUsuarioEmpresa");

    private static async Task<IResult> Handle(
        Guid id, Guid usuarioId, ActualizarAsignacionCommand command, ActualizarAsignacionHandler handler, CancellationToken ct)
    {
        var asignacion = await handler.HandleAsync(id, usuarioId, command, ct);
        return Results.Ok(ApiResponse.Ok(asignacion));
    }
}
