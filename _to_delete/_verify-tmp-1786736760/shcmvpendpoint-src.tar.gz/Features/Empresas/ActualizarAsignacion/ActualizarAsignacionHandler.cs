using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Persistence;

namespace ShcMvpEndPoint.Features.Empresas.ActualizarAsignacion;

public sealed class ActualizarAsignacionHandler(ShacDbContext db)
{
    public async Task<UsuarioEmpresa> HandleAsync(Guid empresaId, Guid usuarioId, ActualizarAsignacionCommand command, CancellationToken ct)
    {
        var asignacion = await db.UsuariosEmpresa.FirstOrDefaultAsync(
            ue => ue.EmpresaId == empresaId && ue.UsuarioId == usuarioId, ct)
            ?? throw new NotFoundException("Asignación no encontrada");

        asignacion.Estado = command.Estado;
        await db.SaveChangesAsync(ct);

        return asignacion;
    }
}
