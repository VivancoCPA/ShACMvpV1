using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Features.Empresas.AsignarUsuarioEmpresa;

public sealed record AsignarUsuarioEmpresaCommand(Guid UsuarioId, UserRole Rol);
