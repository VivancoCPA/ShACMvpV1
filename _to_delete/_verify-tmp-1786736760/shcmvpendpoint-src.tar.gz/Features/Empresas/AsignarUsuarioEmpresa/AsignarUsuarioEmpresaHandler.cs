using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Identity;
using ShcMvpEndPoint.Infrastructure.Persistence;

namespace ShcMvpEndPoint.Features.Empresas.AsignarUsuarioEmpresa;

public sealed record AsignarUsuarioEmpresaResult(UsuarioEmpresa Asignacion, bool WasCreated);

public sealed class AsignarUsuarioEmpresaHandler(ShacDbContext db, UserManager<ShacUser> userManager)
{
    public async Task<AsignarUsuarioEmpresaResult> HandleAsync(Guid empresaId, AsignarUsuarioEmpresaCommand command, CancellationToken ct)
    {
        var empresaExiste = await db.Empresas.AnyAsync(e => e.Id == empresaId, ct);
        if (!empresaExiste)
            throw new NotFoundException("Empresa no encontrada");

        var usuario = await userManager.FindByIdAsync(command.UsuarioId.ToString())
            ?? throw new NotFoundException("Usuario no encontrado");

        var existente = await db.UsuariosEmpresa.FirstOrDefaultAsync(
            ue => ue.UsuarioId == usuario.Id && ue.EmpresaId == empresaId, ct);

        if (existente is not null)
        {
            existente.Rol = command.Rol;
            existente.Estado = UsuarioEmpresaEstado.ACTIVO;
            await db.SaveChangesAsync(ct);
            return new AsignarUsuarioEmpresaResult(existente, WasCreated: false);
        }

        var nueva = new UsuarioEmpresa
        {
            Id = Guid.CreateVersion7(),
            UsuarioId = usuario.Id,
            EmpresaId = empresaId,
            Rol = command.Rol,
            Estado = UsuarioEmpresaEstado.ACTIVO,
            FechaAsignacion = DateTime.UtcNow,
        };
        db.UsuariosEmpresa.Add(nueva);
        await db.SaveChangesAsync(ct);

        return new AsignarUsuarioEmpresaResult(nueva, WasCreated: true);
    }
}
