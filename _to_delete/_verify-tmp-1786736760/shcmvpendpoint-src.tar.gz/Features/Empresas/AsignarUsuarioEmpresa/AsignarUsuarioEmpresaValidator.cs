using FluentValidation;
using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Features.Empresas.AsignarUsuarioEmpresa;

public sealed class AsignarUsuarioEmpresaValidator : AbstractValidator<AsignarUsuarioEmpresaCommand>
{
    public AsignarUsuarioEmpresaValidator()
    {
        RuleFor(x => x.UsuarioId).NotEmpty().WithMessage("usuarioId es requerido");

        // SUPERADMIN es un flag global (ShacUser.EsSuperadminMultiempresa), nunca un rol
        // asignable vía UsuarioEmpresa — ver asignarUsuarioEmpresa.schema.ts del frontend.
        RuleFor(x => x.Rol).NotEqual(UserRole.SUPERADMIN).WithMessage("SUPERADMIN no es un rol asignable.");
    }
}
