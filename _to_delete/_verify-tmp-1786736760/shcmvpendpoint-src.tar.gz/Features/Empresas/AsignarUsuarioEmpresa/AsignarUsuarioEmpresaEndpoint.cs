using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Infrastructure.Middleware;

namespace ShcMvpEndPoint.Features.Empresas.AsignarUsuarioEmpresa;

public static class AsignarUsuarioEmpresaEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/empresas/{id:guid}/usuarios", Handle)
           .AddEndpointFilter<ValidationFilter<AsignarUsuarioEmpresaCommand>>()
           .RequireAuthorization(p => p.RequireRole(nameof(UserRole.SUPERADMIN)))
           .WithTags("Empresas")
           .WithName("AsignarUsuarioEmpresa");

    private static async Task<IResult> Handle(
        Guid id, AsignarUsuarioEmpresaCommand command, AsignarUsuarioEmpresaHandler handler, CancellationToken ct)
    {
        var result = await handler.HandleAsync(id, command, ct);
        return result.WasCreated
            ? Results.Created($"/api/empresas/{id}/usuarios/{result.Asignacion.UsuarioId}", ApiResponse.Ok(result.Asignacion))
            : Results.Ok(ApiResponse.Ok(result.Asignacion));
    }
}
