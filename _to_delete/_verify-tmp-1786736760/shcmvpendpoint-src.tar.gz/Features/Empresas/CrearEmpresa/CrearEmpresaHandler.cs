using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Persistence;

namespace ShcMvpEndPoint.Features.Empresas.CrearEmpresa;

public sealed class CrearEmpresaHandler(ShacDbContext db)
{
    public async Task<Empresa> HandleAsync(CrearEmpresaCommand command, CancellationToken ct)
    {
        var rucDuplicado = await db.Empresas.AnyAsync(e => e.Ruc == command.Ruc, ct);
        if (rucDuplicado)
            throw new ConflictException("El RUC ya está registrado");

        var empresa = new Empresa
        {
            Id = Guid.CreateVersion7(),
            RazonSocial = command.RazonSocial,
            Ruc = command.Ruc,
            Estado = command.Estado ?? EmpresaEstado.ACTIVA,
            LogoUrl = command.LogoBase64,
            FechaAlta = DateTime.UtcNow,
        };

        db.Empresas.Add(empresa);
        await db.SaveChangesAsync(ct);

        return empresa;
    }
}
