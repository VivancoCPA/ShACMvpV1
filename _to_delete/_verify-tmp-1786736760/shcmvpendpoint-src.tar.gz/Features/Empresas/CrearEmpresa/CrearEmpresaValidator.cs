using FluentValidation;

namespace ShcMvpEndPoint.Features.Empresas.CrearEmpresa;

public sealed class CrearEmpresaValidator : AbstractValidator<CrearEmpresaCommand>
{
    public CrearEmpresaValidator()
    {
        RuleFor(x => x.RazonSocial).NotEmpty();
        RuleFor(x => x.Ruc).Matches(@"^\d{11}$").WithMessage("El RUC debe tener 11 dígitos.");
    }
}
