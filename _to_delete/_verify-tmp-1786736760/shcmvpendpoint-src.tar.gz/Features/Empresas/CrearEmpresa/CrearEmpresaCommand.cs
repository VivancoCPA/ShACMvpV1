using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Features.Empresas.CrearEmpresa;

public sealed record CrearEmpresaCommand(string RazonSocial, string Ruc, EmpresaEstado? Estado, string? LogoBase64);
