using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Infrastructure.Middleware;

namespace ShcMvpEndPoint.Features.Empresas.CrearEmpresa;

public static class CrearEmpresaEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/empresas", Handle)
           .AddEndpointFilter<ValidationFilter<CrearEmpresaCommand>>()
           .RequireAuthorization(p => p.RequireRole(nameof(UserRole.SUPERADMIN)))
           .WithTags("Empresas")
           .WithName("CrearEmpresa");

    private static async Task<IResult> Handle(CrearEmpresaCommand command, CrearEmpresaHandler handler, CancellationToken ct)
    {
        var empresa = await handler.HandleAsync(command, ct);
        return Results.Created($"/api/empresas/{empresa.Id}", ApiResponse.Ok(empresa));
    }
}
