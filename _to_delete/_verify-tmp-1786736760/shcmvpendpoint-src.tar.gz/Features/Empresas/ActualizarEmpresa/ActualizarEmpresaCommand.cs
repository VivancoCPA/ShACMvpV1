using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Features.Empresas.ActualizarEmpresa;

public sealed record ActualizarEmpresaCommand(string? RazonSocial, string? Ruc, EmpresaEstado? Estado, string? LogoBase64);
