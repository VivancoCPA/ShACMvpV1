using FluentValidation;

namespace ShcMvpEndPoint.Features.Empresas.ActualizarEmpresa;

public sealed class ActualizarEmpresaValidator : AbstractValidator<ActualizarEmpresaCommand>
{
    public ActualizarEmpresaValidator()
    {
        RuleFor(x => x.RazonSocial).NotEmpty().When(x => x.RazonSocial is not null);
        RuleFor(x => x.Ruc).Matches(@"^\d{11}$").WithMessage("El RUC debe tener 11 dígitos.").When(x => x.Ruc is not null);
    }
}
