using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Infrastructure.Middleware;

namespace ShcMvpEndPoint.Features.Empresas.ActualizarEmpresa;

public static class ActualizarEmpresaEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPatch("/api/empresas/{id:guid}", Handle)
           .AddEndpointFilter<ValidationFilter<ActualizarEmpresaCommand>>()
           .RequireAuthorization(p => p.RequireRole(nameof(UserRole.SUPERADMIN)))
           .WithTags("Empresas")
           .WithName("ActualizarEmpresa");

    private static async Task<IResult> Handle(Guid id, ActualizarEmpresaCommand command, ActualizarEmpresaHandler handler, CancellationToken ct)
    {
        var empresa = await handler.HandleAsync(id, command, ct);
        return Results.Ok(ApiResponse.Ok(empresa));
    }
}
