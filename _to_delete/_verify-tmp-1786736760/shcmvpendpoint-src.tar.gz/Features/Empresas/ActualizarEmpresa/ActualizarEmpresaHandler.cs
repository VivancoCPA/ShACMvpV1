using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Persistence;

namespace ShcMvpEndPoint.Features.Empresas.ActualizarEmpresa;

public sealed class ActualizarEmpresaHandler(ShacDbContext db)
{
    public async Task<Empresa> HandleAsync(Guid id, ActualizarEmpresaCommand command, CancellationToken ct)
    {
        var empresa = await db.Empresas.FirstOrDefaultAsync(e => e.Id == id, ct)
            ?? throw new NotFoundException("Empresa no encontrada");

        if (command.Ruc is not null && command.Ruc != empresa.Ruc)
        {
            var rucDuplicado = await db.Empresas.AnyAsync(e => e.Id != id && e.Ruc == command.Ruc, ct);
            if (rucDuplicado)
                throw new ConflictException("El RUC ya está registrado");
            empresa.Ruc = command.Ruc;
        }

        if (command.RazonSocial is not null)
            empresa.RazonSocial = command.RazonSocial;
        if (command.LogoBase64 is not null)
            empresa.LogoUrl = command.LogoBase64;

        // RN-EMP-005: al pasar de ACTIVA a INACTIVA, cascada a UsuarioEmpresa en la misma
        // operación — transacción explícita porque ExecuteUpdateAsync (cascada) y
        // SaveChangesAsync (empresa) son dos round-trips distintos a la BD.
        var dispararCascada = command.Estado == EmpresaEstado.INACTIVA && empresa.Estado == EmpresaEstado.ACTIVA;
        if (command.Estado is not null)
            empresa.Estado = command.Estado.Value;

        if (dispararCascada)
        {
            await using var transaction = await db.Database.BeginTransactionAsync(ct);

            await db.UsuariosEmpresa
                .Where(ue => ue.EmpresaId == id)
                .ExecuteUpdateAsync(setters => setters.SetProperty(ue => ue.Estado, UsuarioEmpresaEstado.INACTIVO), ct);

            await db.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);
        }
        else
        {
            await db.SaveChangesAsync(ct);
        }

        return empresa;
    }
}
