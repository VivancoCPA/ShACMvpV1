using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Infrastructure.Middleware;

namespace ShcMvpEndPoint.Features.Auth.ForgotPassword;

public static class ForgotPasswordEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/auth/forgot-password", Handle)
           .AddEndpointFilter<ValidationFilter<ForgotPasswordCommand>>()
           .AllowAnonymous()
           .WithTags("Auth")
           .WithName("ForgotPassword");

    private static async Task<IResult> Handle(ForgotPasswordCommand command, ForgotPasswordHandler handler, CancellationToken ct)
    {
        await handler.HandleAsync(command, ct);
        return Results.Ok(ApiResponse.Ok<object?>(null));
    }
}
