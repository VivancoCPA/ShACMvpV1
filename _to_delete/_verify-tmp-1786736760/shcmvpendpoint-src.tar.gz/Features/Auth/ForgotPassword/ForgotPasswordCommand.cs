namespace ShcMvpEndPoint.Features.Auth.ForgotPassword;

public sealed record ForgotPasswordCommand(string Email);
