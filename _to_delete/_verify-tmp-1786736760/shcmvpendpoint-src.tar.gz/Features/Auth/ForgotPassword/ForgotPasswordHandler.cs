using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using ShcMvpEndPoint.Infrastructure.Identity;

namespace ShcMvpEndPoint.Features.Auth.ForgotPassword;

public sealed class ForgotPasswordHandler(UserManager<ShacUser> userManager, ILogger<ForgotPasswordHandler> logger)
{
    // Siempre "éxito" desde afuera — nunca revela si el email existe (protección contra
    // enumeración de usuarios, ver contrato). Sin envío de email real todavía: el token
    // generado solo se loguea (server-side) hasta que exista esa infraestructura.
    public async Task HandleAsync(ForgotPasswordCommand command, CancellationToken ct)
    {
        var user = await userManager.FindByEmailAsync(command.Email);
        if (user is null || !user.Activo)
            return;

        var identityToken = await userManager.GeneratePasswordResetTokenAsync(user);
        var combinedToken = PasswordResetTokenCodec.Encode(user.Id, identityToken);

        logger.LogInformation(
            "Token de reset de contraseña generado para {Email} (sin envío de email real todavía): {Token}",
            command.Email, combinedToken);
    }
}
