using Microsoft.AspNetCore.Identity;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Identity;

namespace ShcMvpEndPoint.Features.Auth.ChangePassword;

public sealed class ChangePasswordHandler(UserManager<ShacUser> userManager)
{
    public async Task HandleAsync(Guid usuarioId, ChangePasswordCommand command, CancellationToken ct)
    {
        var user = await userManager.FindByIdAsync(usuarioId.ToString())
            ?? throw new UnauthorizedBusinessException("Sesión expirada");

        if (!await userManager.CheckPasswordAsync(user, command.CurrentPassword))
            throw new UnauthorizedBusinessException("Contraseña actual incorrecta");

        var result = await userManager.ChangePasswordAsync(user, command.CurrentPassword, command.NewPassword);
        if (!result.Succeeded)
            throw new BadRequestBusinessException(string.Join(" ", result.Errors.Select(e => e.Description)));
    }
}
