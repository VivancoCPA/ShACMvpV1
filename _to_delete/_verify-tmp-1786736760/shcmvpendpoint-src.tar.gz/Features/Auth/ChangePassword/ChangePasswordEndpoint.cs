using System.Security.Claims;
using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Infrastructure.Middleware;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Features.Auth.ChangePassword;

public static class ChangePasswordEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/auth/change-password", Handle)
           .AddEndpointFilter<ValidationFilter<ChangePasswordCommand>>()
           .RequireAuthorization()
           .WithTags("Auth")
           .WithName("ChangePassword");

    private static async Task<IResult> Handle(
        ChangePasswordCommand command, ChangePasswordHandler handler, ClaimsPrincipal user, CancellationToken ct)
    {
        await handler.HandleAsync(user.GetUsuarioId(), command, ct);
        return Results.Ok(ApiResponse.Ok<object?>(null));
    }
}
