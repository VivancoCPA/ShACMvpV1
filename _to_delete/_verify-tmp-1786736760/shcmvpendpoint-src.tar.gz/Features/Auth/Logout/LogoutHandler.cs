using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Infrastructure.Persistence;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Features.Auth.Logout;

public sealed class LogoutHandler(ShacDbContext db)
{
    public async Task HandleAsync(string? rawRefreshToken, CancellationToken ct)
    {
        if (string.IsNullOrEmpty(rawRefreshToken))
            return;

        var tokenHash = JwtTokenService.HashToken(rawRefreshToken);
        var token = await db.RefreshTokens.FirstOrDefaultAsync(t => t.TokenHash == tokenHash, ct);
        if (token is null || token.RevokedAt is not null)
            return;

        token.RevokedAt = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
    }
}
