using ShcMvpEndPoint.Domain.Common;

namespace ShcMvpEndPoint.Features.Auth.Logout;

public static class LogoutEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/auth/logout", Handle)
           .AllowAnonymous()
           .WithTags("Auth")
           .WithName("Logout");

    private static async Task<IResult> Handle(LogoutHandler handler, HttpRequest request, HttpResponse response, CancellationToken ct)
    {
        var rawRefreshToken = request.Cookies[AuthCookies.RefreshTokenCookieName];
        await handler.HandleAsync(rawRefreshToken, ct);
        response.DeleteRefreshTokenCookie();
        return Results.Ok(ApiResponse.Ok<object?>(null));
    }
}
