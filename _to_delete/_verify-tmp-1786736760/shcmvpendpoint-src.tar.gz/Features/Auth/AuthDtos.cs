using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Infrastructure.Identity;

namespace ShcMvpEndPoint.Features.Auth;

// Compartido entre Login/Refresh/SwitchEmpresa — misma forma de sesión en los tres, ver
// docs/SHAC-Contrato-API.md sección 11.
public sealed record UserDto(
    Guid Id,
    string Nombre,
    string Apellido,
    string Email,
    string? Rol,
    Guid? AreaId,
    List<Guid> AreaIds,
    string? AvatarUrl,
    DateTime CreatedAt,
    DateTime? LastLogin,
    bool Activo,
    bool EsSuperadminMultiempresa)
{
    public static UserDto From(ShacUser user, UserRole? rolEfectivo) => new(
        user.Id,
        user.Nombre,
        user.Apellido,
        user.Email!,
        rolEfectivo?.ToString(),
        user.AreaId,
        user.AreaIds,
        user.AvatarUrl,
        user.CreatedAt,
        user.LastLogin,
        user.Activo,
        user.EsSuperadminMultiempresa);
}

public sealed record SessionResponse(string AccessToken, UserDto User, Guid? EmpresaActivaId, List<Empresa> EmpresasDisponibles);

public sealed record SelectionRequiredResponse(bool RequiresEmpresaSelection, List<Empresa> EmpresasDisponibles)
{
    public SelectionRequiredResponse(List<Empresa> empresasDisponibles) : this(true, empresasDisponibles)
    {
    }
}
