using System.Text;

namespace ShcMvpEndPoint.Features.Auth;

// El contrato de /forgot-password y /reset-password (heredado del mock) no incluye email/userId
// en el body de /reset-password — solo `{ token, password }` — porque el mock nunca implementó
// envío real de email (ver CLAUDE.md, "Recuperación de contraseña — estado actual"). Sin esa
// referencia, /reset-password no puede resolver a qué ShacUser pertenece el token de Identity
// para llamar UserManager.ResetPasswordAsync. Codificamos el userId junto al token real de
// Identity en el string opaco que viajaría por email, preservando el contrato público tal cual
// y sin inventar un campo nuevo que el frontend no envía.
public static class PasswordResetTokenCodec
{
    public static string Encode(Guid userId, string identityToken) =>
        Convert.ToBase64String(Encoding.UTF8.GetBytes($"{userId}:{identityToken}"));

    public static bool TryDecode(string combinedToken, out Guid userId, out string identityToken)
    {
        userId = default;
        identityToken = "";
        try
        {
            var raw = Encoding.UTF8.GetString(Convert.FromBase64String(combinedToken));
            var separatorIndex = raw.IndexOf(':');
            if (separatorIndex <= 0)
                return false;

            if (!Guid.TryParse(raw[..separatorIndex], out userId))
                return false;

            identityToken = raw[(separatorIndex + 1)..];
            return identityToken.Length > 0;
        }
        catch (FormatException)
        {
            return false;
        }
    }
}
