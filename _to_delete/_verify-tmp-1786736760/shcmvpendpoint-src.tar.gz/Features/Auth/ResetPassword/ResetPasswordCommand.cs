namespace ShcMvpEndPoint.Features.Auth.ResetPassword;

public sealed record ResetPasswordCommand(string Token, string Password);
