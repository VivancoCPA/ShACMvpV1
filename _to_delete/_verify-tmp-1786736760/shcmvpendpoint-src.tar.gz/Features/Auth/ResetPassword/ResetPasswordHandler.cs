using Microsoft.AspNetCore.Identity;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Identity;

namespace ShcMvpEndPoint.Features.Auth.ResetPassword;

public sealed class ResetPasswordHandler(UserManager<ShacUser> userManager)
{
    public async Task HandleAsync(ResetPasswordCommand command, CancellationToken ct)
    {
        if (!PasswordResetTokenCodec.TryDecode(command.Token, out var userId, out var identityToken))
            throw new BadRequestBusinessException("Token inválido o expirado");

        var user = await userManager.FindByIdAsync(userId.ToString());
        if (user is null)
            throw new BadRequestBusinessException("Token inválido o expirado");

        var result = await userManager.ResetPasswordAsync(user, identityToken, command.Password);
        if (!result.Succeeded)
            throw new BadRequestBusinessException("Token inválido o expirado");
    }
}
