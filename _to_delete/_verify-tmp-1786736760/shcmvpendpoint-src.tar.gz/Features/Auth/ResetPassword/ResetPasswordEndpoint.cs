using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Infrastructure.Middleware;

namespace ShcMvpEndPoint.Features.Auth.ResetPassword;

public static class ResetPasswordEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/auth/reset-password", Handle)
           .AddEndpointFilter<ValidationFilter<ResetPasswordCommand>>()
           .AllowAnonymous()
           .WithTags("Auth")
           .WithName("ResetPassword");

    private static async Task<IResult> Handle(ResetPasswordCommand command, ResetPasswordHandler handler, CancellationToken ct)
    {
        await handler.HandleAsync(command, ct);
        return Results.Ok(ApiResponse.Ok<object?>(null));
    }
}
