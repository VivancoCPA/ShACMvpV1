namespace ShcMvpEndPoint.Features.Auth.Login;

public sealed record LoginCommand(string Email, string Password, Guid? EmpresaId);
