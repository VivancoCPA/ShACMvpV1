using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Infrastructure.Middleware;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Features.Auth.Login;

public static class LoginEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/auth/login", Handle)
           .AddEndpointFilter<ValidationFilter<LoginCommand>>()
           .AllowAnonymous()
           .WithTags("Auth")
           .WithName("Login");

    private static async Task<IResult> Handle(
        LoginCommand command, LoginHandler handler, JwtTokenService jwtTokenService, HttpResponse response, CancellationToken ct)
    {
        var result = await handler.HandleAsync(command, ct);

        if (result is LoginResult.Resolved res)
        {
            response.AppendRefreshTokenCookie(res.RawRefreshToken, jwtTokenService.RefreshTokenExpirationDays);
            return Results.Ok(ApiResponse.Ok(res.Response));
        }

        var sel = (LoginResult.SelectionRequired)result;
        return Results.Ok(ApiResponse.Ok(sel.Response));
    }
}
