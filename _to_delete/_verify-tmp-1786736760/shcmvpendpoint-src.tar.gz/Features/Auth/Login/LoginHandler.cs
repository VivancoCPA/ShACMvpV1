using Microsoft.AspNetCore.Identity;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Identity;
using ShcMvpEndPoint.Infrastructure.Persistence;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Features.Auth.Login;

public abstract record LoginResult
{
    public sealed record SelectionRequired(SelectionRequiredResponse Response) : LoginResult;
    public sealed record Resolved(SessionResponse Response, string RawRefreshToken) : LoginResult;
}

public sealed class LoginHandler(
    UserManager<ShacUser> userManager,
    ShacDbContext db,
    SessionResolver sessionResolver,
    JwtTokenService jwtTokenService)
{
    public async Task<LoginResult> HandleAsync(LoginCommand command, CancellationToken ct)
    {
        var user = await userManager.FindByEmailAsync(command.Email);
        if (user is null || !await userManager.CheckPasswordAsync(user, command.Password))
            throw new UnauthorizedBusinessException("Credenciales inválidas");

        if (!user.Activo)
            throw new ForbiddenBusinessException("Usuario deshabilitado, contacte al administrador");

        var resolution = await sessionResolver.ResolveSessionAsync(user, command.EmpresaId, ct);

        return resolution switch
        {
            SessionResolution.SelectionRequired sel =>
                new LoginResult.SelectionRequired(new SelectionRequiredResponse(sel.EmpresasDisponibles)),
            SessionResolution.Error err => throw new ForbiddenBusinessException(err.Message),
            SessionResolution.Resolved res => await CompleteLoginAsync(user, res, ct),
            _ => throw new InvalidOperationException("Resolución de sesión inesperada."),
        };
    }

    private async Task<LoginResult.Resolved> CompleteLoginAsync(ShacUser user, SessionResolution.Resolved res, CancellationToken ct)
    {
        user.LastLogin = DateTime.UtcNow;

        var accessToken = jwtTokenService.GenerateAccessToken(user, res.EmpresaActivaId, res.RolEfectivo);
        var (rawRefreshToken, refreshTokenEntity) = jwtTokenService.GenerateRefreshToken(user.Id);
        refreshTokenEntity.EmpresaActivaId = res.EmpresaActivaId;
        db.RefreshTokens.Add(refreshTokenEntity);

        await db.SaveChangesAsync(ct);

        var response = new SessionResponse(accessToken, UserDto.From(user, res.RolEfectivo), res.EmpresaActivaId, res.EmpresasDisponibles);
        return new LoginResult.Resolved(response, rawRefreshToken);
    }
}
