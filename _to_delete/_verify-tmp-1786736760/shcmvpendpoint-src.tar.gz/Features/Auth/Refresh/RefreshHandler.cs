using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Identity;
using ShcMvpEndPoint.Infrastructure.Persistence;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Features.Auth.Refresh;

public sealed record RefreshResult(SessionResponse Response, string RawRefreshToken);

public sealed class RefreshHandler(
    UserManager<ShacUser> userManager,
    ShacDbContext db,
    SessionResolver sessionResolver,
    JwtTokenService jwtTokenService)
{
    public async Task<RefreshResult> HandleAsync(string? rawRefreshToken, CancellationToken ct)
    {
        if (string.IsNullOrEmpty(rawRefreshToken))
            throw new UnauthorizedBusinessException("Sesión expirada");

        var tokenHash = JwtTokenService.HashToken(rawRefreshToken);
        var currentToken = await db.RefreshTokens.FirstOrDefaultAsync(t => t.TokenHash == tokenHash, ct);
        if (currentToken is null || !currentToken.IsActive)
            throw new UnauthorizedBusinessException("Sesión expirada");

        var user = await userManager.FindByIdAsync(currentToken.UsuarioId.ToString());
        if (user is null)
            throw new UnauthorizedBusinessException("Sesión expirada");

        Guid? empresaActivaId;
        Domain.Enums.UserRole? rolEfectivo;
        List<Domain.Entities.Empresa> empresasDisponibles;

        if (user.EsSuperadminMultiempresa)
        {
            empresaActivaId = null;
            rolEfectivo = Domain.Enums.UserRole.SUPERADMIN;
            empresasDisponibles = [];
        }
        else
        {
            empresasDisponibles = await sessionResolver.GetEmpresasActivasParaUsuarioAsync(user.Id, ct);
            if (empresasDisponibles.Count == 0)
                throw new UnauthorizedBusinessException("El usuario no tiene ninguna empresa asignada");

            empresaActivaId = currentToken.EmpresaActivaId is not null
                && empresasDisponibles.Any(e => e.Id == currentToken.EmpresaActivaId)
                ? currentToken.EmpresaActivaId
                : empresasDisponibles[0].Id;

            rolEfectivo = await sessionResolver.GetRolEfectivoAsync(user.Id, empresaActivaId.Value, ct);
            if (rolEfectivo is null)
                throw new UnauthorizedBusinessException("Sesión expirada");
        }

        var accessToken = jwtTokenService.GenerateAccessToken(user, empresaActivaId, rolEfectivo);

        currentToken.RevokedAt = DateTime.UtcNow;
        var (rawNewToken, newTokenEntity) = jwtTokenService.GenerateRefreshToken(user.Id);
        newTokenEntity.EmpresaActivaId = empresaActivaId;
        db.RefreshTokens.Add(newTokenEntity);

        await db.SaveChangesAsync(ct);

        var response = new SessionResponse(accessToken, UserDto.From(user, rolEfectivo), empresaActivaId, empresasDisponibles);
        return new RefreshResult(response, rawNewToken);
    }
}
