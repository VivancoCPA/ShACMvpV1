using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Features.Auth.Refresh;

public static class RefreshEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/auth/refresh", Handle)
           .AllowAnonymous()
           .WithTags("Auth")
           .WithName("Refresh");

    private static async Task<IResult> Handle(
        RefreshHandler handler, JwtTokenService jwtTokenService, HttpRequest request, HttpResponse response, CancellationToken ct)
    {
        var rawRefreshToken = request.Cookies[AuthCookies.RefreshTokenCookieName];
        var result = await handler.HandleAsync(rawRefreshToken, ct);

        response.AppendRefreshTokenCookie(result.RawRefreshToken, jwtTokenService.RefreshTokenExpirationDays);
        return Results.Ok(ApiResponse.Ok(result.Response));
    }
}
