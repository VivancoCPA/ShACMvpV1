namespace ShcMvpEndPoint.Features.Auth;

// Cookie httpOnly real para el refresh token — reemplaza el parche de localStorage que usaba
// el mock MSW (ver CLAUDE.md, sección Auth). withCredentials ya está asumido en el cliente Axios
// del frontend.
public static class AuthCookies
{
    public const string RefreshTokenCookieName = "shac_refresh_token";

    public static void AppendRefreshTokenCookie(this HttpResponse response, string rawToken, int expirationDays)
    {
        response.Cookies.Append(RefreshTokenCookieName, rawToken, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Strict,
            Expires = DateTimeOffset.UtcNow.AddDays(expirationDays),
            Path = "/api/auth",
        });
    }

    public static void DeleteRefreshTokenCookie(this HttpResponse response) =>
        response.Cookies.Delete(RefreshTokenCookieName, new CookieOptions { Path = "/api/auth" });
}
