namespace ShcMvpEndPoint.Features.Auth.SwitchEmpresa;

public sealed record SwitchEmpresaCommand(Guid EmpresaId);
