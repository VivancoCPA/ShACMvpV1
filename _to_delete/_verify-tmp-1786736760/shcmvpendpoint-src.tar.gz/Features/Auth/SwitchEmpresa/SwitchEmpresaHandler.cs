using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Domain.Exceptions;
using ShcMvpEndPoint.Infrastructure.Identity;
using ShcMvpEndPoint.Infrastructure.Persistence;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Features.Auth.SwitchEmpresa;

public sealed class SwitchEmpresaHandler(
    UserManager<ShacUser> userManager,
    ShacDbContext db,
    SessionResolver sessionResolver,
    JwtTokenService jwtTokenService)
{
    public async Task<SessionResponse> HandleAsync(
        Guid usuarioId, SwitchEmpresaCommand command, string? currentRawRefreshToken, CancellationToken ct)
    {
        var user = await userManager.FindByIdAsync(usuarioId.ToString())
            ?? throw new UnauthorizedBusinessException("Sesión expirada");

        if (user.EsSuperadminMultiempresa)
            throw new ForbiddenBusinessException("Superadmin no cambia de empresa");

        var resolution = await sessionResolver.ResolveSessionAsync(user, command.EmpresaId, ct);
        var resolved = resolution as SessionResolution.Resolved
            ?? throw MapNonResolvedError(resolution);

        // No rota el refresh token (igual que el mock) — solo actualiza qué empresa restaurar
        // en el próximo /refresh, si el cliente mandó una cookie de refresh válida.
        if (!string.IsNullOrEmpty(currentRawRefreshToken))
        {
            var tokenHash = JwtTokenService.HashToken(currentRawRefreshToken);
            var currentToken = await db.RefreshTokens.FirstOrDefaultAsync(t => t.TokenHash == tokenHash, ct);
            if (currentToken is not null && currentToken.IsActive)
            {
                currentToken.EmpresaActivaId = resolved.EmpresaActivaId;
                await db.SaveChangesAsync(ct);
            }
        }

        var accessToken = jwtTokenService.GenerateAccessToken(user, resolved.EmpresaActivaId, resolved.RolEfectivo);
        return new SessionResponse(accessToken, UserDto.From(user, resolved.RolEfectivo), resolved.EmpresaActivaId, resolved.EmpresasDisponibles);
    }

    private static Exception MapNonResolvedError(object resolution) => resolution switch
    {
        // No debería ocurrir: se pasó empresaId explícito, pero por si acaso no matchea
        // ninguna asignación, se trata como empresa inválida (mismo criterio que el mock).
        SessionResolution.SelectionRequired => new ForbiddenBusinessException("La empresa indicada no está asignada a este usuario"),
        SessionResolution.Error err => new ForbiddenBusinessException(err.Message),
        _ => new InvalidOperationException("Resolución de sesión inesperada."),
    };
}
