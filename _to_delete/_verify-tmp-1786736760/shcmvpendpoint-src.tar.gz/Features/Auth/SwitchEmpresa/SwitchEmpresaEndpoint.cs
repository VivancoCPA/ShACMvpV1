using System.Security.Claims;
using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Infrastructure.Middleware;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Features.Auth.SwitchEmpresa;

public static class SwitchEmpresaEndpoint
{
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/auth/switch-empresa", Handle)
           .AddEndpointFilter<ValidationFilter<SwitchEmpresaCommand>>()
           .RequireAuthorization()
           .WithTags("Auth")
           .WithName("SwitchEmpresa");

    private static async Task<IResult> Handle(
        SwitchEmpresaCommand command, SwitchEmpresaHandler handler, ClaimsPrincipal user, HttpRequest request, CancellationToken ct)
    {
        var currentRawRefreshToken = request.Cookies[AuthCookies.RefreshTokenCookieName];
        var response = await handler.HandleAsync(user.GetUsuarioId(), command, currentRawRefreshToken, ct);
        return Results.Ok(ApiResponse.Ok(response));
    }
}
