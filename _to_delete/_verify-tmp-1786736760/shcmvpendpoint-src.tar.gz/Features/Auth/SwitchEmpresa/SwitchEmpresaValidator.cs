using FluentValidation;

namespace ShcMvpEndPoint.Features.Auth.SwitchEmpresa;

public sealed class SwitchEmpresaValidator : AbstractValidator<SwitchEmpresaCommand>
{
    public SwitchEmpresaValidator()
    {
        RuleFor(x => x.EmpresaId).NotEmpty().WithMessage("empresaId es requerido");
    }
}
