using System.Net;
using System.Net.Http.Json;

namespace ShcMvpEndPoint.Tests.Features.Auth;

public sealed class LoginEndpointTests(ShacWebApplicationFactory factory) : IClassFixture<ShacWebApplicationFactory>
{
    [Fact]
    public async Task Login_ConCredencialesInexistentes_Devuelve401ConEnvelopeApiResponse()
    {
        var client = factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/auth/login", new { email = "nadie@shac.pe", password = "loquesea" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<ApiResponseEnvelope>();
        Assert.NotNull(body);
        Assert.False(body!.Success);
        Assert.Equal("Credenciales inválidas", body.Message);
    }

    [Fact]
    public async Task CrearEmpresa_SinToken_Devuelve401()
    {
        var client = factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/empresas", new { razonSocial = "Test SAC", ruc = "12345678901" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    private sealed record ApiResponseEnvelope(object? Data, bool Success, string? Message);
}
