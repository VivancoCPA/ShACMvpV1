# SHAC Backend — Instrucciones para Claude Code: scaffolding inicial

> Generado por Cowork 2026-08-14. Este documento es la instrucción de trabajo para Claude Code — Cowork investigó y documentó, Claude Code ejecuta. Los dos documentos de grounding (`docs/SHAC-Contrato-API.md` y `docs/SHAC-Arquitectura.md`) viven en esta misma carpeta; toda decisión de contrato HTTP o de arquitectura debe verificarse contra ellos, no inventarse.

## Contexto

El proyecto backend se llama **`ShcMvpEndPoint`** (nombre ya fijado por estandarización — no renombrar carpeta, `.csproj` ni `.slnx`), ubicado en `C:\Users\ANTONIO\source\repos\OpenSpec\ShcMvp\ShcMvpEndPoint`, junto a `shc-controldoc` (el frontend React existente) dentro de `ShcMvp`. Ya existe un proyecto Web mínimo creado desde Visual Studio ahí (`ShcMvpEndPoint.csproj`, `ShcMvpEndPoint.slnx`, `Program.cs` básico, target `.NET 10.0` — confirmado, no cambiar a una LTS anterior). Es el backend .NET real que reemplazará al mock MSW del frontend — el frontend **no se toca** en este trabajo.

**Nota sobre la carpeta `shc-backEnd`** (vacía salvo por `docs/` y este mismo archivo, al mismo nivel que `ShcMvpEndPoint`): es un remanente de un primer intento de nombre de carpeta, ya abandonado — no usarla, no moverla. Todo el trabajo va en `ShcMvpEndPoint`.

**Git**: `ShcMvpEndPoint` NO tiene git propio todavía y vive dentro de la carpeta `ShcMvp`, que sí tiene su propio repo git (el del frontend, `shc-controldoc`). Antes de cualquier otro paso: `git init` **dentro de `ShcMvpEndPoint`** como repo independiente, y agregar la línea `ShcMvpEndPoint/` al `.gitignore` de `ShcMvp` (el repo padre) para que el backend no quede rastreado por accidente en el repo del frontend. Confirmar que `git status` dentro de `ShcMvp` ya no vea archivos de `ShcMvpEndPoint` después de este cambio.

El objetivo de esta primera sesión es dejar la solución scaffolded, compilando, con Postgres en Docker funcionando, y **un módulo de referencia completo end-to-end** (Auth + Empresas) que establezca el patrón que todos los módulos siguientes replicarán.

Decisiones ya tomadas (no hay que re-decidir esto, ver `docs/SHAC-Arquitectura.md` sección "Decisiones sobre las preguntas abiertas"):
- Vertical Slice Architecture con Minimal APIs, sin MediatR.
- Dapper para toda acción de lectura (GET), EF Core para toda escritura (POST/PUT/PATCH/DELETE).
- ASP.NET Core Identity para el motor de usuarios, pero SIN `MapIdentityApi` — los 6 endpoints de Auth se escriben como slices propios que usan `UserManager<ShacUser>`/`SignInManager<ShacUser>` internamente y devuelven el envelope `ApiResponse<T>` tal como lo espera el frontend.
- RBAC vive enteramente en una tabla `UsuarioEmpresa` custom (usuarioId, empresaId, rol, activo) — los roles de Identity (`AspNetRoles`) no se usan para permisos de negocio.
- Almacenamiento de archivos: disco local del contenedor Docker (no S3/Azure Blob) para el MVP.
- Refresh token: cookie `httpOnly` real (el mock usaba localStorage solo como parche de MSW — el backend real NO debe replicar eso, ver `docs/SHAC-Contrato-API.md` sección 11 y `CLAUDE.md` del frontend si se necesita más detalle).

## Paso 0 — Instalar el skill de Vertical Slice

Hay un skill ya preparado en `_skill-to-install/dotnet-vsa-rules/` (SKILL.md + carpeta `references/`), adaptado a la estructura de 4 proyectos y a las decisiones de este documento. Moverlo a su ubicación real como **primer paso**, antes de tocar nada más:

```
mover _skill-to-install/dotnet-vsa-rules/  →  .claude/skills/dotnet-vsa-rules/
```

(en Windows/PowerShell: `Move-Item _skill-to-install\dotnet-vsa-rules .claude\skills\dotnet-vsa-rules` — crear `.claude\skills\` antes si no existe). Después de moverlo, eliminar la carpeta `_skill-to-install/` vacía. Confirmar que `.claude/skills/dotnet-vsa-rules/SKILL.md` existe antes de seguir.

**⚠️ Importante — reiniciar la sesión después de este paso.** `.claude/skills/` no existía en este repo antes de este movimiento — es la primera vez que aparece. Claude Code detecta cambios en caliente *dentro* de carpetas de skills que ya estaba observando al arrancar la sesión, pero no detecta la aparición de una carpeta `.claude/skills/` completamente nueva en una sesión ya en marcha. **Por lo tanto: después de mover el skill, terminar esta sesión de Claude Code y volver a abrirla (`claude` de nuevo en `ShcMvpEndPoint`) antes de continuar con el Paso 1.** Si se sigue trabajando en la misma sesión sin reiniciar, el skill queda en disco pero Claude Code no lo carga, y todos los pasos siguientes se ejecutarían sin su guía sin que se note el error.

Todos los pasos de este documento, desde el Paso 1 en adelante (ya con la sesión reiniciada), deben ejecutarse siguiendo ese skill — se activa automáticamente al trabajar con Minimal APIs/CQRS en este repo, pero está bien invocarlo explícitamente con `/dotnet-vsa-rules` al empezar cada módulo nuevo.

## Paso 1 — Git, y completar la solución sobre el proyecto ya creado

En `C:\Users\ANTONIO\source\repos\OpenSpec\ShcMvp\ShcMvpEndPoint`:

1. `git init` ahí mismo (repo independiente — ver nota de Git en "Contexto" arriba) + agregar `ShcMvpEndPoint/` al `.gitignore` de `ShcMvp` (repo padre).
2. El proyecto host **ya existe** como `ShcMvpEndPoint` (`ShcMvpEndPoint.csproj` + `Program.cs` mínimo, target `.NET 10.0`) — este cumple el rol de `Shac.Api` en `docs/SHAC-Arquitectura.md` sección 1 (host: ASP.NET Core Minimal API). **No renombrarlo.** Agregar como proyectos hermanos, referenciados desde `ShcMvpEndPoint.csproj` y todos agregados a `ShcMvpEndPoint.slnx`:
   - `ShcMvpEndPoint.Domain` (class library — entidades EF Core, enums, sin dependencias de infraestructura).
   - `ShcMvpEndPoint.Infrastructure` (class library — `ShacDbContext` de EF Core, `DapperConnectionFactory`, configuración de Identity). Referencia a `ShcMvpEndPoint.Domain`.
   - `ShcMvpEndPoint.Tests` (xUnit, con `Microsoft.AspNetCore.Mvc.Testing` para `WebApplicationFactory` y `Testcontainers.PostgreSql` para tests de integración contra Postgres real).
   - Referencias: `ShcMvpEndPoint` → `ShcMvpEndPoint.Infrastructure` → `ShcMvpEndPoint.Domain`. `ShcMvpEndPoint` también referencia `ShcMvpEndPoint.Domain` directamente si hace falta.
   - En los documentos `docs/SHAC-Arquitectura.md` y `docs/SHAC-Contrato-API.md`, cualquier mención a `Shac.Api`/`Shac.Domain`/`Shac.Infrastructure`/`Shac.Tests` debe leerse como `ShcMvpEndPoint`/`ShcMvpEndPoint.Domain`/`ShcMvpEndPoint.Infrastructure`/`ShcMvpEndPoint.Tests` respectivamente — son los mismos roles arquitectónicos, solo cambió el nombre por estandarización.
3. Paquetes NuGet mínimos a instalar (target ya fijado en `.NET 10.0` — usar las versiones de paquete compatibles con esa versión, más recientes disponibles a la fecha):
   - `Npgsql.EntityFrameworkCore.PostgreSQL` (EF Core provider Postgres).
   - `Dapper` + `Npgsql` (conexión directa para queries).
   - `Microsoft.AspNetCore.Identity.EntityFrameworkCore`.
   - `Microsoft.AspNetCore.Authentication.JwtBearer`.
   - `FluentValidation` (para los validators de cada Command, ya que los schemas Zod del frontend son la referencia de qué se valida — ver shapes en `docs/SHAC-Contrato-API.md`).
   - `Swashbuckle.AspNetCore` (OpenAPI/Swagger, útil para que el frontend team verifique el contrato interactivamente).
4. Crear `.gitignore` estándar de .NET + excluir `appsettings.Development.json` si va a contener secretos locales (usar `appsettings.Development.json.example` en su lugar, o variables de entorno vía `.env` + docker-compose).

## Paso 2 — Docker Compose (Postgres + almacenamiento de archivos)

Crear `docker-compose.yml` en la raíz del repo con:
- Servicio `postgres` (imagen oficial `postgres:16` o similar): usuario/password/db vía variables de entorno (`.env`, no hardcodeadas), puerto mapeado (ej. `5432:5432`), volumen nombrado para persistencia (`pgdata`), healthcheck (`pg_isready`).
- Un volumen (o bind mount) para almacenamiento de archivos del backend (documentos: original, distribución, publicado — ver `docs/SHAC-Contrato-API.md` sección 1.3), montado en el contenedor de la API en una ruta fija (ej. `/data/documentos`) cuando se agregue el servicio de la API al compose (puede ser en un paso posterior si primero se corre la API con `dotnet run` local apuntando a Postgres en Docker).
- `.env.example` documentando las variables esperadas (usuario/password/db de Postgres, cadena de conexión).

## Paso 3 — Convenciones compartidas (`Shac.Api/Shared/`)

Antes de tocar cualquier módulo, dejar listo lo que todos los slices van a reutilizar:

1. `ApiResponse<T>` — exactamente el shape de `docs/SHAC-Contrato-API.md` sección "Convenciones globales": `{ data: T, success: bool, message?: string, errors?: string[], pagination?: {page, pageSize, totalItems, totalPages} }`. Con helpers estáticos `ApiResponse.Ok(data)`, `ApiResponse.Fail(message, errors?)`, `ApiResponse.Paged(data, pagination)`.
2. Middleware/filter que resuelve `empresaActivaId` desde el JWT (claim custom) e inyecta un `IEmpresaContext` (o similar) accesible por los handlers — es el mecanismo central para el scoping por empresa que aplica a casi todos los módulos (ver regla en "Convenciones globales" del contrato: filtrar por `empresaId` antes que cualquier otro filtro, 404 uniforme para recursos de otra empresa).
3. Un exception handler / `IResult` helper uniforme para mapear excepciones de validación (FluentValidation) a `400` con `ApiResponse.Fail`, y un patrón para 404/409/422 consistente con lo documentado por módulo en el contrato.
4. Configuración base de `Program.cs`: DI de `ShacDbContext` (EF Core), `DapperConnectionFactory` (Npgsql), Identity (`AddIdentity<ShacUser, IdentityRole<Guid>>` o similar, recordando que los roles de Identity NO se usan para RBAC de negocio — ver decisión arriba), JWT Bearer authentication, Swagger.

## Paso 4 — Módulo de referencia 1: Auth + Identity

Implementar como primer slice completo, siguiendo `docs/SHAC-Contrato-API.md` sección 11 (Auth) y sección 7 (Empresas, para `UsuarioEmpresa`) al pie de la letra:

1. `ShacUser : IdentityUser<Guid>` con los campos extra: `Nombre`, `Apellido`, `Area` (home area), `AreasAsignadas` (solo Supervisor), `Activo`, `LastLogin`.
2. Entidad `UsuarioEmpresa` (fuera de Identity): `UsuarioId, EmpresaId, Rol, Estado, FechaAsignacion` — esta tabla es la única fuente del rol efectivo, ver decisión de arquitectura.
3. Los 6 endpoints de Auth como slices independientes (`Features/Auth/Login/`, `.../Refresh/`, `.../SwitchEmpresa/`, `.../Logout/`, `.../ForgotPassword/`, `.../ResetPassword/`), usando `UserManager`/`SignInManager` internamente, NUNCA `MapIdentityApi`.
4. Refresh token como cookie `httpOnly` + `Secure` + `SameSite` real (no localStorage, no en el body de la respuesta) — replicar exactamente el comportamiento que `CLAUDE.md` del frontend documenta como obligatorio para el backend real.
5. El JWT emitido debe llevar el rol efectivo de la empresa activa (resuelto desde `UsuarioEmpresa`), recalculado en login, refresh y switch-empresa — no un rol fijo de Identity.
6. Flujo de selección de empresa multi-tenant tal como está descrito en el contrato (login sin `empresaId` → `requiresEmpresaSelection`, segunda llamada con `empresaId` completa el login) — el contrato deja esto marcado como "asumido, a confirmar" (flag 8 de la sección "Flags de revisión"); implementarlo como está documentado y avisar si aparece alguna inconsistencia real al hacerlo.

## Paso 5 — Módulo de referencia 2: Empresas

Implementar los 6 endpoints de `docs/SHAC-Contrato-API.md` sección 7 completos (CRUD de empresas + asignación de usuarios), ya que `UsuarioEmpresa` es prerequisito de todo el sistema de permisos. Poner especial atención a la regla transaccional: desactivar una empresa debe cascadear a todas sus filas `UsuarioEmpresa` en la misma operación (ver sección 7 del contrato).

## Qué NO hacer en esta primera sesión

- No tocar Documentos todavía (sección 1 del contrato) — es el módulo más complejo (manejo de archivos, firmas) y tiene 5 decisiones de producto aún pendientes de Toño (ver sección 1.7 del contrato). Se aborda en una sesión posterior.
- No implementar el job asíncrono de notificaciones de vencimiento todavía (flag 4 de "Flags de revisión" del contrato) — requiere decidir la infraestructura de jobs (Hangfire, Quartz.NET, o `IHostedService` simple) en una sesión dedicada.
- No preocuparse por S3/Azure Blob — ya está decidido que es disco local para el MVP.

## Al terminar

Dejar un resumen corto (qué se scaffoldeó, qué compila, qué tests de integración corren) para que la siguiente sesión de Cowork lo verifique contra el repo antes de seguir con el próximo módulo.
