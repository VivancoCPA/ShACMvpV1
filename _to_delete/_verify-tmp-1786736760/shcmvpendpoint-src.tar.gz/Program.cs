using System.Text.Json.Serialization;
using FluentValidation;
using Microsoft.OpenApi;
using ShcMvpEndPoint.Extensions;
using ShcMvpEndPoint.Infrastructure.Extensions;

var builder = WebApplication.CreateBuilder(args);

const string CorsPolicyName = "ShacFrontend";
var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
    ?? ["http://localhost:5173"];

// 1. Infraestructura (EF Core, Identity, Dapper, JWT, exception handler)
builder.Services.AddInfrastructure(builder.Configuration);

// 2. Feature handlers + validators de FluentValidation (escaneo del assembly del host)
builder.Services.AddFeatureHandlers();
builder.Services.AddValidatorsFromAssemblyContaining<Program>();

builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
    // Sin naming policy propia: los enums (UserRole, EmpresaEstado, ...) deben viajar tal cual
    // están declarados ("SUPERADMIN", "ACTIVA") — son literales exactos del contrato TS, no camelCase.
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
});

builder.Services.AddCors(options =>
    options.AddPolicy(CorsPolicyName, policy =>
        policy.WithOrigins(allowedOrigins)
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials()));

builder.Services.AddOpenApi();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "SHAC API", Version = "v1" });

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Bearer — pegar solo el token, sin el prefijo \"Bearer \".",
    });
    // TODO: candado "Authorize" por endpoint requiere AddSecurityRequirement con una referencia
    // al esquema — Microsoft.OpenApi 2.x cambió esa API (OpenApiReference/ReferenceType ya no
    // existen así) y Swashbuckle.AspNetCore 10.2.3 aún no documenta el reemplazo. Definición del
    // esquema queda lista arriba; falta solo enlazarla globalmente en una sesión futura.
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseExceptionHandler();

app.UseCors(CorsPolicyName);
app.UseHttpsRedirection();

// Orden obligatorio: Authentication antes de Authorization.
app.UseAuthentication();
app.UseAuthorization();

app.MapFeatureEndpoints();

app.Run();

// Visible para WebApplicationFactory<Program> en ShcMvpEndPoint.Tests (los top-level statements
// generan una clase Program implícita e internal por defecto).
public partial class Program;
