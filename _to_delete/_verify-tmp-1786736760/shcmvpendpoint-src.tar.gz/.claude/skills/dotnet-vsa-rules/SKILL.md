---
name: dotnet-vsa-rules
version: 1.1.0
description: Reglas y estándares estructurados para el backend .NET de SHAC (proyecto ShcMvpEndPoint) que usa arquitectura Vertical Slice (VSA). Se activa al programar Minimal APIs, CQRS con EF Core y Dapper, o al añadir nuevos endpoints/features en este backend.
---

# Vertical Slice Architecture — Backend ShcMvpEndPoint (.NET 10)

Guía de referencia para el desarrollo de APIs REST en `ShcMvpEndPoint` siguiendo Vertical Slice Architecture (VSA). Adaptado 2026-08-14 a partir de un skill genérico de VSA para calzar con las decisiones ya tomadas para este proyecto — ver `docs/SHAC-Arquitectura.md` y `docs/SHAC-Contrato-API.md` en la raíz del repo para el contexto completo (contrato HTTP exacto por módulo, convenciones globales, flags de revisión).

---

## 1. Principios Fundamentales

| # | Principio | Descripción |
|---|-----------|-------------|
| 1 | **Feature = Directorio** | Cada caso de uso vive en su propio directorio con handler, DTOs, validación |
| 2 | **Entry Point único** | Cada feature expone un solo método público `Map(IEndpointRouteBuilder)` |
| 3 | **Mínimo acoplamiento entre slices** | Máximo acoplamiento dentro de un slice |
| 4 | **Sin abstracciones prematuras** | No crear repositorios/servicios genéricos hasta que haya duplicación real en 3+ slices |
| 5 | **CQRS nativo** | Commands (escrituras) separados de Queries (lecturas) por naturaleza del slice |

---

## 2. Stack Tecnológico (ya decidido para este proyecto — no renegociar)

- **Framework:** .NET 10 / Minimal APIs (confirmado, no bajar a una LTS anterior)
- **ORM (Escritura):** Entity Framework Core (PostgreSQL)
- **Micro-ORM (Lectura):** Dapper (SELECT con SQL raw)
- **Validación:** FluentValidation
- **Identidad & Auth:** ASP.NET Core Identity (`UserManager`/`SignInManager`, **NUNCA** `MapIdentityApi` — los 6 endpoints de Auth son slices propios que devuelven el envelope `ApiResponse<T>`) + JWT Bearer
- **Manejador de Mensajes:** Ninguno (sin MediatR, inyección directa de Handlers)
- **RBAC:** vive enteramente en una tabla custom `UsuarioEmpresa` (usuarioId, empresaId, rol, activo) — **los roles de ASP.NET Identity (`AspNetRoles`) NO se usan para permisos de negocio.** El rol efectivo de un usuario es siempre relativo a la empresa activa de su sesión, nunca un atributo fijo del usuario.
- **Almacenamiento de archivos:** disco local del contenedor Docker para el MVP (no S3/Azure Blob).
- **Refresh token:** cookie `httpOnly` + `Secure` + `SameSite` real — nunca en el body de la respuesta ni en localStorage.

---

## 3. Estructura del Proyecto — 4 proyectos separados (NO un solo proyecto)

Esta es la única diferencia real respecto al skill genérico de VSA de referencia: aquí la solución está dividida en 4 proyectos .csproj, no en carpetas dentro de un único proyecto.

```
ShcMvpEndPoint.slnx
│
├── ShcMvpEndPoint/                       # Host — Minimal API, Composition Root
│   ├── Features/                         # ⭐ Corazón de la arquitectura
│   │   └── {DomainPlural}/               # Agrupado por dominio (ej. Documentos, Incidentes)
│   │       └── {Operacion}{Domain}/      # Directorio único por caso de uso (ej. CrearDocumento)
│   │           ├── {Op}{Domain}Endpoint.cs   # Minimal API endpoint (entry point)
│   │           ├── {Op}{Domain}Command.cs    # Command/Query record + Handler
│   │           └── {Op}{Domain}Validator.cs  # FluentValidation (si aplica)
│   ├── Shared/                           # ApiResponse<T>, EmpresaContext, exception handling
│   ├── Program.cs                        # Composition Root
│   └── appsettings.json
│
├── ShcMvpEndPoint.Domain/                # Entidades del dominio (POCOs), enums — sin dependencias de infraestructura
│   └── Entities/
│
├── ShcMvpEndPoint.Infrastructure/        # Cross-cutting concerns
│   ├── Persistence/                      # ShacDbContext (EF Core), DapperConnectionFactory, Migraciones
│   ├── Identity/                         # ShacUser : IdentityUser<Guid>, config de Identity
│   ├── Middleware/                       # ValidationFilter genérico, resolución de empresaActivaId desde JWT
│   └── Extensions/                       # ServiceCollectionExtensions, EndpointExtensions
│
└── ShcMvpEndPoint.Tests/                 # xUnit + WebApplicationFactory + Testcontainers.PostgreSql
```

Referencias entre proyectos: `ShcMvpEndPoint` → `ShcMvpEndPoint.Infrastructure` → `ShcMvpEndPoint.Domain`. `ShcMvpEndPoint` también referencia `ShcMvpEndPoint.Domain` directamente cuando lo necesite (p.ej. los Endpoints/Commands referencian entidades de dominio sin pasar por Infrastructure).

---

## 4. Referencias Detalladas (Patrones y Código)

Los patrones de código de `references/code_patterns.md` y `references/infrastructure_and_auth.md` siguen siendo válidos tal cual — solo hay que leer `AppDbContext` como `ShacDbContext` (vive en `ShcMvpEndPoint.Infrastructure/Persistence/`) y `{ProjectName}` como `ShcMvpEndPoint` en los namespaces:

- 📑 **[Patrones de Código y DTOs](references/code_patterns.md):** Plantillas de código para Commands, Queries, Endpoints (Minimal APIs), Validadores y paquetes NuGet.
- ⚙️ **[Infraestructura y Seguridad JWT](references/infrastructure_and_auth.md):** Reglas para `ShacDbContext`, `DapperConnectionFactory`, `ValidationFilter`, autenticación/autorización JWT.

**Dos añadidos que esos archivos de referencia NO cubren (específicos de este proyecto, no del skill genérico):**

1. **Envelope `ApiResponse<T>` obligatorio** en toda respuesta (ver `docs/SHAC-Contrato-API.md`, "Convenciones globales"): `{ data: T, success: bool, message?: string, errors?: string[], pagination?: {...} }`. Los Endpoints devuelven `Results.Ok(ApiResponse.Ok(response))` (o el helper equivalente), no el DTO desnudo — a diferencia del ejemplo `Results.Created($"...", response)` de `code_patterns.md`, que hay que envolver.
2. **Scoping por `empresaId`** en casi todos los módulos (ver contrato): cada Query/Command handler que toque datos de negocio recibe `empresaActivaId` (resuelto desde el JWT vía el middleware/servicio de `ShcMvpEndPoint.Infrastructure/Middleware/`) y lo aplica como primer filtro — nunca confiar en un `empresaId` que venga del body/query del cliente para mutaciones. Un recurso de otra empresa responde igual que uno inexistente (404 uniforme, nunca 403 que filtre existencia cross-tenant).

---

## 5. Reglas del Composition Root (`ShcMvpEndPoint/Program.cs`)

```csharp
using ShcMvpEndPoint.Infrastructure.Extensions;

var builder = WebApplication.CreateBuilder(args);

// 1. Registrar Infraestructura (EF Core, Identity, Dapper, FluentValidation)
builder.Services.AddInfrastructure(builder.Configuration);

// 2. Registrar Feature Handlers como Scoped
builder.Services.AddFeatureHandlers();

builder.Services.AddOpenApi();
builder.Services.AddCors(options =>
    options.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
    app.MapOpenApi();

app.UseCors();
app.UseHttpsRedirection();

// ⚠️ Orden obligatorio: Authentication antes de Authorization
app.UseAuthentication();
app.UseAuthorization();

// 3. Registrar todos los endpoints de las Features
app.MapFeatureEndpoints();

app.Run();
```

---

## 6. Convenciones de Nomenclatura

| Elemento | Convención | Ejemplo |
|----------|-----------|---------|
| Directorio feature | `{Operación}{Domain}/` | `CrearDocumento/` |
| Endpoint class | `{Operación}{Domain}Endpoint` | `CrearDocumentoEndpoint` |
| Command/Query record | `{Operación}{Domain}Command` / `{Op}{Domain}Query` | `CrearDocumentoCommand` |
| Handler class | `{Operación}{Domain}CommandHandler` | `CrearDocumentoCommandHandler` |
| Response record | `{Operación}{Domain}Response` | `CrearDocumentoResponse` |
| Validator class | `{Operación}{Domain}Validator` | `CrearDocumentoValidator` |
| Entry point method | `Map` (estático) | `CrearDocumentoEndpoint.Map(app)` |
| Tablas / Columnas PostgreSQL | `snake_case` (plural para tablas) | `documentos`, `usuario_empresa` |
| Rutas API | tal como están en `docs/SHAC-Contrato-API.md` (no inventar convención propia) | `/api/documents`, `/api/quality-events` |

**Nota sobre rutas**: el contrato de API ya fija los paths exactos (algunos en inglés `/api/documents`, otros mixtos) porque el frontend ya los consume así — no "limpiar"/normalizar los nombres de ruta al implementar, deben calzar carácter por carácter con `docs/SHAC-Contrato-API.md`.

---

## 7. Reglas Estrictas (SÍ y NO)

### ✅ SÍ hacer
1. **Un directorio = un caso de uso:** nunca mezcles lógica de múltiples endpoints en un mismo slice.
2. **Un `Map()` público por feature:** todo lo demás dentro del archivo de Endpoint debe ser privado o internal.
3. **EF Core solo para escrituras:** Commands (INSERT, UPDATE, DELETE), vía `ShacDbContext` de `ShcMvpEndPoint.Infrastructure`.
4. **Dapper solo para lecturas:** Queries (SELECT), vía `DapperConnectionFactory`.
5. **FluentValidation por Command:** cada command que reciba parámetros del cliente debe tener su validador.
6. **`Guid.CreateVersion7()`** para IDs eficientes y ordenados cronológicamente.
7. **CancellationToken:** propágalo siempre hacia los métodos asíncronos de acceso a datos.
8. **Envolver toda respuesta en `ApiResponse<T>`** (ver sección 4).
9. **Aplicar el scoping por `empresaId`** en todo handler que toque datos de negocio (ver sección 4).

### ❌ NO hacer
1. **No usar MediatR.**
2. **No crear capas de servicio o repositorios genéricos** hasta que haya duplicación real en 3+ slices.
3. **No importar código entre slices** — compartir vía `Domain/` o `Infrastructure/`.
4. **No usar Controllers** — solo Minimal APIs.
5. **No usar EF Core para lecturas** salvo excepción de rendimiento justificada.
6. **No usar body en `MapDelete`/`MapGet`** — usa `[AsParameters]` con query strings.
7. **No usar `MapIdentityApi`** para Auth (ver sección 2).
8. **No usar los roles de Identity (`AspNetRoles`) para autorización de negocio** — siempre `UsuarioEmpresa` (ver sección 2).
9. **No devolver un DTO desnudo** — siempre `ApiResponse<T>`.

---

## 8. Checklist para Agregar una Nueva Feature

```markdown
- [ ] Verificar el contrato exacto del endpoint en docs/SHAC-Contrato-API.md antes de escribir código (path, body, response, status codes)
- [ ] Crear directorio: ShcMvpEndPoint/Features/{DomainPlural}/{Operación}{Domain}/
- [ ] Crear Command/Query record + Handler (EF Core si es escritura, Dapper si es lectura)
- [ ] Aplicar scoping por empresaId si el módulo lo requiere (ver contrato)
- [ ] Crear Validator (si es Command con input)
- [ ] Crear Endpoint con método Map() estático, respuesta envuelta en ApiResponse<T>
- [ ] Definir autorización: .RequireAuthorization() (protegido) o .AllowAnonymous() (público)
- [ ] Registrar handler en EndpointExtensions.AddFeatureHandlers() (ShcMvpEndPoint.Infrastructure)
- [ ] Registrar endpoint en EndpointExtensions.MapFeatureEndpoints()
- [ ] Si requiere una nueva entidad de base de datos:
  - [ ] Crear clase en ShcMvpEndPoint.Domain/Entities/
  - [ ] Agregar DbSet<T> en ShacDbContext (ShcMvpEndPoint.Infrastructure)
  - [ ] Configurar mapping de tablas y columnas (snake_case)
  - [ ] Ejecutar: dotnet ef migrations add {NombreMigracion}
- [ ] Verificar compilación: dotnet build
```
