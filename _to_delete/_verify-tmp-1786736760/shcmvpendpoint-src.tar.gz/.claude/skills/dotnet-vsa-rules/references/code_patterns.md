# Patrones de Código y DTOs en Vertical Slice

Este archivo contiene las plantillas estándar y ejemplos de código para implementar las operaciones principales de un Slice Vertical en .NET 10+.

---

## 1. Command (Escritura) — EF Core

Usado para operaciones que mutan el estado (`POST`, `PUT`, `DELETE`). Utiliza **Entity Framework Core** para interactuar con la base de datos.

```csharp
// ── {Operation}{Domain}Command.cs ───────────────────────────────

// Request DTO (Inmutable)
public record Create{Domain}Command(string Name, string? OptionalField);

// Response DTO
public record Create{Domain}Response(Guid Id, string Name);

// Handler — usa EF Core para persistir la entidad de dominio
public class Create{Domain}CommandHandler
{
    private readonly AppDbContext _db;

    public Create{Domain}CommandHandler(AppDbContext db) => _db = db;

    public async Task<Create{Domain}Response> HandleAsync(
        Create{Domain}Command command, CancellationToken ct)
    {
        var entity = new {Domain}
        {
            Id = Guid.CreateVersion7(), // Genera un Guid UUIDv7 ordenado cronológicamente
            Name = command.Name
        };

        _db.{DomainPlural}.Add(entity);
        await _db.SaveChangesAsync(ct);

        return new Create{Domain}Response(entity.Id, entity.Name);
    }
}
```

---

## 2. Query (Lectura) — Dapper

Usado para operaciones de obtención de datos (`GET` individual o listados). Utiliza **Dapper** con SQL raw para maximizar el rendimiento.

```csharp
// ── Get{Domain}Query.cs ─────────────────────────────────────────

using Dapper;

// Response DTO (Dapper mapea directamente a este record por posición/nombre)
public record Get{Domain}Response(Guid Id, string Name, string? OptionalField);

// Handler — usa Dapper con consultas SQL puras
public class Get{Domain}QueryHandler
{
    private readonly DapperConnectionFactory _connectionFactory;

    public Get{Domain}QueryHandler(DapperConnectionFactory connectionFactory) =>
        _connectionFactory = connectionFactory;

    public async Task<Get{Domain}Response?> HandleAsync(Guid id, CancellationToken ct)
    {
        using var connection = _connectionFactory.CreateConnection();

        const string sql = """
            SELECT id AS Id, name AS Name, optional_field AS OptionalField
            FROM {table_name}
            WHERE id = @Id
            """;

        return await connection.QueryFirstOrDefaultAsync<Get{Domain}Response>(
            new CommandDefinition(sql, new { Id = id }, cancellationToken: ct));
    }
}
```

> ⚠️ **Regla de Tipos:** Usa `long` (no `int`) para resultados de agregados como `COUNT(*)`, `SUM()`, o `AVG()` en PostgreSQL, ya que Dapper requiere coincidencia exacta de tipos y PostgreSQL retorna `bigint` (Int64).

---

## 3. Endpoint — Minimal API (Entry Point)

Representa el punto de entrada al slice vertical. Debe exponer un único método estático `Map`.

```csharp
// ── Create{Domain}Endpoint.cs ───────────────────────────────────

public static class Create{Domain}Endpoint
{
    // ⭐ ÚNICO método público — Registra el endpoint en las rutas del framework
    public static void Map(IEndpointRouteBuilder app) =>
        app.MapPost("/api/{route}", Handle)
           .AddEndpointFilter<ValidationFilter<Create{Domain}Command>>()
           .WithTags("{DomainPlural}")
           .WithName("Create{Domain}")
           .Produces<Create{Domain}Response>(StatusCodes.Status201Created)
           .ProducesValidationProblem();

    // Método privado — Orquesta la llamada e inyecta dependencias
    private static async Task<IResult> Handle(
        Create{Domain}Command command,
        Create{Domain}CommandHandler handler,
        CancellationToken ct)
    {
        var response = await handler.HandleAsync(command, ct);
        return Results.Created($"/api/{route}/{response.Id}", response);
    }
}
```

---

## 4. Validator — FluentValidation

Proporciona las reglas de validación para las solicitudes entrantes antes de que lleguen al handler.

```csharp
// ── Create{Domain}Validator.cs ──────────────────────────────────

using FluentValidation;

public class Create{Domain}Validator : AbstractValidator<Create{Domain}Command>
{
    public Create{Domain}Validator()
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("El nombre es requerido.")
            .MaximumLength(200).WithMessage("El nombre no puede exceder 200 caracteres.");
    }
}
```

---

## 5. Paquetes NuGet Requeridos

Añadir estas dependencias en el archivo `.csproj`:

```xml
<!-- EF Core + PostgreSQL -->
<PackageReference Include="Npgsql.EntityFrameworkCore.PostgreSQL" Version="9.0.4" />
<PackageReference Include="Microsoft.EntityFrameworkCore" Version="9.0.4" />
<PackageReference Include="Microsoft.EntityFrameworkCore.Design" Version="9.0.4" />

<!-- Identity + JWT -->
<PackageReference Include="Microsoft.AspNetCore.Identity.EntityFrameworkCore" Version="9.0.4" />
<PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="9.0.4" />

<!-- FluentValidation -->
<PackageReference Include="FluentValidation.DependencyInjectionExtensions" Version="12.0.0" />

<!-- Dapper + Npgsql -->
<PackageReference Include="Dapper" Version="2.1.66" />
<PackageReference Include="Npgsql" Version="9.0.3" />

<!-- OpenAPI -->
<PackageReference Include="Microsoft.AspNetCore.OpenApi" Version="10.0.4" />
```
