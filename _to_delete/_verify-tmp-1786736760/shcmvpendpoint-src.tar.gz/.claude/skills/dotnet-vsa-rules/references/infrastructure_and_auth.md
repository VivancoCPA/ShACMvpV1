# Infraestructura y Seguridad JWT en Vertical Slice

Este archivo contiene las directrices detalladas para estructurar la capa de infraestructura compartida y las reglas de seguridad/autorización mediante JWT.

---

## 1. Reglas de Infrastructure

Los componentes de infraestructura se ubican bajo la carpeta `Infrastructure/` y sirven como soporte transversal (cross-cutting concerns) para los slices:

### 1.1 AppDbContext (EF Core)
- Hereda de `IdentityDbContext` si se usa ASP.NET Core Identity.
- Expone un `DbSet<T>` por cada entidad del dominio.
- Mapea nombres de tablas y columnas a **snake_case** en `OnModelCreating`.
- Se inyecta **únicamente** en los Command Handlers (mutaciones de estado).

### 1.2 DapperConnectionFactory
- Registrado como **Singleton** en el contenedor de DI.
- Almacena la cadena de conexión (nunca una conexión abierta).
- Crea y devuelve instancias de `NpgsqlConnection` bajo demanda.
- Se inyecta **únicamente** en los Query Handlers (lecturas de estado).

### 1.3 ValidationFilter\<T\>
- Filtro genérico `IEndpointFilter` que intercepta la petición.
- Resuelve `IValidator<T>` de FluentValidation desde DI.
- Si no está definido, continúa el flujo; si falla la validación, devuelve `Results.ValidationProblem()` (RFC 7807).
- Se asocia en el endpoint mediante `.AddEndpointFilter<ValidationFilter<T>>()`.

### 1.4 ServiceCollectionExtensions (`AddInfrastructure`)
Registra de forma centralizada:
- `AppDbContext` con el proveedor PostgreSQL (`Npgsql`).
- Identity con `IdentityUser`.
- `DapperConnectionFactory` como Singleton.
- Escaneo de validadores de FluentValidation en el assembly.

### 1.5 EndpointExtensions (`EndpointExtensions.cs`)
- `MapFeatureEndpoints()` — Registra manualmente las Minimal APIs llamando al método `Map` de cada Endpoint.
- `AddFeatureHandlers()` — Registra manualmente todos los Command y Query Handlers como **Scoped** en el contenedor de dependencias.

```csharp
// Ejemplo de registro manual explícito en EndpointExtensions.cs
public static void MapFeatureEndpoints(this IEndpointRouteBuilder app)
{
    // Medical Centers
    CreateMedicalCenterEndpoint.Map(app);
    GetMedicalCenterEndpoint.Map(app);
    
    // Doctors
    CreateDoctorEndpoint.Map(app);
}
```

---

## 2. Autorización JWT — Reglas

### 2.1 Configuración en appsettings.json
Define la clave y duración del token:
```json
{
  "Jwt": {
    "Key": "MinimoDe32CaracteresParaHmacSha256!",
    "Issuer": "{ProjectName}",
    "Audience": "{ProjectName}Clients",
    "ExpirationMinutes": "60"
  }
}
```
> ⚠️ **Seguridad:** Nunca subas la `Key` al control de versiones. Usa User Secrets para desarrollo y variables de entorno en producción.

### 2.2 Middleware — Orden obligatorio en Program.cs
El orden de registro en la canalización HTTP es estricto:
```csharp
app.UseCors();
app.UseHttpsRedirection();

// ⚠️ Orden obligatorio
app.UseAuthentication();   // Valida el JWT y establece el ClaimsPrincipal
app.UseAuthorization();    // Evalúa las políticas de seguridad

app.MapFeatureEndpoints();
```

### 2.3 Clasificación de Endpoints
- **Públicos (`.AllowAnonymous()`):** Endpoints de Auth como Login, Register, Health checks.
- **Autenticados (`.RequireAuthorization()`):** Cualquier endpoint de negocio que requiera una sesión activa.
- **Por Rol/Política (`.RequireAuthorization("Admin")`):** Acceso restringido a roles específicos.

```csharp
// Endpoint Público (Auth)
public static void Map(IEndpointRouteBuilder app) =>
    app.MapPost("/api/auth/login", Handle)
       .AddEndpointFilter<ValidationFilter<LoginCommand>>()
       .AllowAnonymous();

// Endpoint Protegido (JWT Obligatorio)
public static void Map(IEndpointRouteBuilder app) =>
    app.MapPost("/api/doctors", Handle)
       .AddEndpointFilter<ValidationFilter<CreateDoctorCommand>>()
       .RequireAuthorization();
```

### 2.4 claims del Usuario
Si el handler necesita información sobre el usuario que realiza la operación, inyecta `ClaimsPrincipal` directamente en la firma de tu método `Handle`:

```csharp
private static async Task<IResult> Handle(
    CreateDoctorCommand command,
    CreateDoctorCommandHandler handler,
    ClaimsPrincipal user,          // ← Inyectado por el pipeline de Minimal APIs
    CancellationToken ct)
{
    var userId = user.FindFirst(ClaimTypes.NameIdentifier)?.Value;
    // ...
    var response = await handler.HandleAsync(command, ct);
    return Results.Created($"/api/doctors/{response.Id}", response);
}
```
