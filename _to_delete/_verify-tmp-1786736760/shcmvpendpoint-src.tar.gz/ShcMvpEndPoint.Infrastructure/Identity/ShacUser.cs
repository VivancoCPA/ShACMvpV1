using Microsoft.AspNetCore.Identity;

namespace ShcMvpEndPoint.Infrastructure.Identity;

public class ShacUser : IdentityUser<Guid>
{
    public required string Nombre { get; set; }
    public required string Apellido { get; set; }

    // FK a Area.id (catálogo de M9 Áreas, aún no scaffoldeado en esta sesión) — sin
    // restricción de FK en la BD todavía, solo la columna.
    public Guid? AreaId { get; set; }

    // Áreas que este Supervisor gestiona para efectos de permisos (RN-QE-014). Solo
    // relevante para Rol === SUPERVISOR en alguna de sus UsuarioEmpresa.
    public List<Guid> AreaIds { get; set; } = [];

    public string? AvatarUrl { get; set; }
    public bool Activo { get; set; } = true;
    public DateTime CreatedAt { get; set; }
    public DateTime? LastLogin { get; set; }

    // Flag global independiente de UsuarioEmpresa: true resuelve la sesión con
    // rol SUPERADMIN y empresaActivaId null, sin importar asignaciones UsuarioEmpresa.
    public bool EsSuperadminMultiempresa { get; set; }
}
