using FluentValidation;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Domain.Exceptions;

namespace ShcMvpEndPoint.Infrastructure.Middleware;

public sealed class ApiExceptionHandler(ILogger<ApiExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        var (statusCode, response) = exception switch
        {
            BadRequestBusinessException ex => (StatusCodes.Status400BadRequest, ApiResponse.Fail(ex.Message)),
            NotFoundException ex => (StatusCodes.Status404NotFound, ApiResponse.Fail(ex.Message)),
            ConflictException ex => (StatusCodes.Status409Conflict, ApiResponse.Fail(ex.Message)),
            BusinessRuleException ex => (StatusCodes.Status422UnprocessableEntity, ApiResponse.Fail(ex.Message)),
            UnauthorizedBusinessException ex => (StatusCodes.Status401Unauthorized, ApiResponse.Fail(ex.Message)),
            ForbiddenBusinessException ex => (StatusCodes.Status403Forbidden, ApiResponse.Fail(ex.Message)),
            ValidationException ex => (StatusCodes.Status400BadRequest,
                ApiResponse.Fail("Error de validación.", ex.Errors.Select(e => e.ErrorMessage).ToArray())),
            _ => (StatusCodes.Status500InternalServerError, ApiResponse.Fail("Error interno del servidor.")),
        };

        if (statusCode == StatusCodes.Status500InternalServerError)
            logger.LogError(exception, "Excepción no controlada en {Path}", httpContext.Request.Path);

        httpContext.Response.StatusCode = statusCode;
        await httpContext.Response.WriteAsJsonAsync(response, cancellationToken);
        return true;
    }
}
