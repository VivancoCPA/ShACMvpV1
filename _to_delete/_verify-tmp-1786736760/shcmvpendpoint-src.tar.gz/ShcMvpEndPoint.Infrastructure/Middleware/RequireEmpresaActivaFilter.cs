using Microsoft.AspNetCore.Http;
using ShcMvpEndPoint.Domain.Common;
using ShcMvpEndPoint.Infrastructure.Security;

namespace ShcMvpEndPoint.Infrastructure.Middleware;

// Aplicar con .AddEndpointFilter<RequireEmpresaActivaFilter>() en toda mutación de un módulo
// scoped por empresa (Documentos, Incidentes, NC, QE, Locales, ...). Ver convención global del
// contrato de API: "Si la sesión no tiene empresa activa (empresaActivaId === null), las
// creaciones responden 401".
public sealed class RequireEmpresaActivaFilter : IEndpointFilter
{
    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var empresaActivaId = context.HttpContext.User.GetEmpresaActivaId();
        if (empresaActivaId is null)
        {
            return Results.Json(
                ApiResponse.Fail("No hay una empresa activa en la sesión."),
                statusCode: StatusCodes.Status401Unauthorized);
        }

        return await next(context);
    }
}
