using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Infrastructure.Identity;

namespace ShcMvpEndPoint.Infrastructure.Security;

public sealed class JwtTokenService(IOptions<JwtSettings> options)
{
    private readonly JwtSettings _settings = options.Value;

    // empresaActivaId/rolEfectivo nulos para SUPERADMIN (sin empresa activa) o sesiones sin
    // empresa resuelta todavía — recalculado siempre en login/refresh/switch-empresa, nunca cacheado.
    public string GenerateAccessToken(ShacUser user, Guid? empresaActivaId, UserRole? rolEfectivo)
    {
        List<Claim> claims =
        [
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Email, user.Email!),
            new("nombre", user.Nombre),
            new("apellido", user.Apellido),
        ];

        if (empresaActivaId is not null)
            claims.Add(new Claim(ShacClaimTypes.EmpresaActivaId, empresaActivaId.Value.ToString()));

        if (rolEfectivo is not null)
            claims.Add(new Claim(ClaimTypes.Role, rolEfectivo.Value.ToString()));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_settings.Key));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _settings.Issuer,
            audience: _settings.Audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(_settings.AccessTokenExpirationMinutes),
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    // Devuelve el token crudo (va en la cookie httpOnly) y la entidad a persistir (solo el hash).
    public (string RawToken, RefreshToken Entity) GenerateRefreshToken(Guid usuarioId)
    {
        var rawToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
        var entity = new RefreshToken
        {
            Id = Guid.CreateVersion7(),
            UsuarioId = usuarioId,
            TokenHash = HashToken(rawToken),
            CreatedAt = DateTime.UtcNow,
            ExpiresAt = DateTime.UtcNow.AddDays(_settings.RefreshTokenExpirationDays),
        };
        return (rawToken, entity);
    }

    public static string HashToken(string rawToken) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(rawToken)));

    public int RefreshTokenExpirationDays => _settings.RefreshTokenExpirationDays;
}
