using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Domain.Enums;
using ShcMvpEndPoint.Infrastructure.Identity;
using ShcMvpEndPoint.Infrastructure.Persistence;

namespace ShcMvpEndPoint.Infrastructure.Security;

public abstract record SessionResolution
{
    public sealed record Resolved(Guid? EmpresaActivaId, UserRole? RolEfectivo, List<Empresa> EmpresasDisponibles) : SessionResolution;
    public sealed record SelectionRequired(List<Empresa> EmpresasDisponibles) : SessionResolution;
    public sealed record Error(string Message) : SessionResolution;
}

// Traducción directa de `resolveSession()` en shc-controldoc/src/mocks/handlers/auth.handlers.ts —
// única fuente de verdad de la empresa activa + rol efectivo, usada por Login y SwitchEmpresa.
public sealed class SessionResolver(ShacDbContext db)
{
    public async Task<List<Empresa>> GetEmpresasActivasParaUsuarioAsync(Guid usuarioId, CancellationToken ct)
    {
        var empresaIds = await db.UsuariosEmpresa
            .Where(ue => ue.UsuarioId == usuarioId && ue.Estado == UsuarioEmpresaEstado.ACTIVO)
            .Select(ue => ue.EmpresaId)
            .ToListAsync(ct);

        return await db.Empresas.Where(e => empresaIds.Contains(e.Id)).ToListAsync(ct);
    }

    public async Task<UserRole?> GetRolEfectivoAsync(Guid usuarioId, Guid empresaId, CancellationToken ct)
    {
        var asignacion = await db.UsuariosEmpresa.FirstOrDefaultAsync(
            ue => ue.UsuarioId == usuarioId && ue.EmpresaId == empresaId && ue.Estado == UsuarioEmpresaEstado.ACTIVO, ct);
        return asignacion?.Rol;
    }

    public async Task<SessionResolution> ResolveSessionAsync(ShacUser user, Guid? empresaIdSolicitada, CancellationToken ct)
    {
        if (user.EsSuperadminMultiempresa)
            return new SessionResolution.Resolved(null, UserRole.SUPERADMIN, []);

        var empresasDisponibles = await GetEmpresasActivasParaUsuarioAsync(user.Id, ct);
        if (empresasDisponibles.Count == 0)
            return new SessionResolution.Error("El usuario no tiene ninguna empresa asignada");

        var resolvedEmpresaId = empresasDisponibles.Count == 1 ? empresasDisponibles[0].Id : empresaIdSolicitada;
        if (resolvedEmpresaId is null)
            return new SessionResolution.SelectionRequired(empresasDisponibles);

        var rol = await GetRolEfectivoAsync(user.Id, resolvedEmpresaId.Value, ct);
        if (rol is null)
            return new SessionResolution.Error("La empresa indicada no está asignada a este usuario");

        return new SessionResolution.Resolved(resolvedEmpresaId, rol, empresasDisponibles);
    }
}
