namespace ShcMvpEndPoint.Infrastructure.Security;

public static class ShacClaimTypes
{
    public const string EmpresaActivaId = "empresaActivaId";
}
