using System.Security.Claims;

namespace ShcMvpEndPoint.Infrastructure.Security;

public static class ClaimsPrincipalExtensions
{
    public static Guid GetUsuarioId(this ClaimsPrincipal user)
    {
        var raw = user.FindFirst(ClaimTypes.NameIdentifier)?.Value
            ?? throw new InvalidOperationException("El token no contiene NameIdentifier.");
        return Guid.Parse(raw);
    }

    // null para sesiones sin empresa activa (p.ej. SUPERADMIN, o login pendiente de selección de empresa).
    public static Guid? GetEmpresaActivaId(this ClaimsPrincipal user)
    {
        var raw = user.FindFirst(ShacClaimTypes.EmpresaActivaId)?.Value;
        return string.IsNullOrEmpty(raw) ? null : Guid.Parse(raw);
    }

    public static string? GetRolEfectivo(this ClaimsPrincipal user) =>
        user.FindFirst(ClaimTypes.Role)?.Value;
}
