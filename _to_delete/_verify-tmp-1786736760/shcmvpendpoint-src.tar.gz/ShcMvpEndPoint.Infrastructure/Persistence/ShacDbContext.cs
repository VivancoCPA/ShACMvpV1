using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ShcMvpEndPoint.Domain.Entities;
using ShcMvpEndPoint.Infrastructure.Identity;

namespace ShcMvpEndPoint.Infrastructure.Persistence;

public class ShacDbContext(DbContextOptions<ShacDbContext> options)
    : IdentityDbContext<ShacUser, IdentityRole<Guid>, Guid>(options)
{
    public DbSet<Empresa> Empresas => Set<Empresa>();
    public DbSet<UsuarioEmpresa> UsuariosEmpresa => Set<UsuarioEmpresa>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Empresa>(entity =>
        {
            entity.HasIndex(e => e.Ruc).IsUnique();
            entity.Property(e => e.Estado).HasConversion<string>().HasMaxLength(20);
        });

        builder.Entity<UsuarioEmpresa>(entity =>
        {
            entity.HasIndex(e => new { e.UsuarioId, e.EmpresaId }).IsUnique();
            entity.Property(e => e.Rol).HasConversion<string>().HasMaxLength(50);
            entity.Property(e => e.Estado).HasConversion<string>().HasMaxLength(20);
        });

        builder.Entity<RefreshToken>(entity =>
        {
            entity.HasIndex(e => e.TokenHash).IsUnique();
            entity.HasIndex(e => e.UsuarioId);
        });

        // snake_case va al final: opera sobre los nombres ya resueltos por el resto del modelo
        // (incluidas las tablas de Identity, AspNetUsers -> asp_net_users, etc.).
        builder.UseSnakeCaseNaming();
    }
}
