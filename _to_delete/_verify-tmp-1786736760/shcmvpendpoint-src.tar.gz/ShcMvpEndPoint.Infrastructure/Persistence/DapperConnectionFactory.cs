using System.Data;
using Npgsql;

namespace ShcMvpEndPoint.Infrastructure.Persistence;

// Registrado como Singleton: guarda solo el connection string, nunca una conexión abierta.
// Se inyecta únicamente en Query Handlers (lecturas) — los Command Handlers usan ShacDbContext.
public sealed class DapperConnectionFactory(string connectionString)
{
    public IDbConnection CreateConnection() => new NpgsqlConnection(connectionString);
}
