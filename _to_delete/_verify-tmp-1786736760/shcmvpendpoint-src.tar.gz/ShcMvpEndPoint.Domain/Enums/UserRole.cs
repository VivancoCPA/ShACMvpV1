namespace ShcMvpEndPoint.Domain.Enums;

// Los 9 valores deben calzar carácter por carácter con `UserRole` en shc-controldoc/src/types/auth.types.ts
// (ADMINISTRADOR_EMPRESA y SUPERADMIN se agregaron en la fase Multiempresa, después del contrato original).
public enum UserRole
{
    OPERARIO,
    SUPERVISOR,
    JEFE_CALIDAD_SYST,
    JEFE_CONTROL_DOCUMENTARIO,
    AUDITOR_INTERNO,
    ALTA_DIRECCION,
    ADMINISTRADOR_SISTEMA,
    ADMINISTRADOR_EMPRESA,
    SUPERADMIN,
}
