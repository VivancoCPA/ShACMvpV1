namespace ShcMvpEndPoint.Domain.Enums;

public enum UsuarioEmpresaEstado
{
    ACTIVO,
    INACTIVO,
}
