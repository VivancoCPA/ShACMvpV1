namespace ShcMvpEndPoint.Domain.Enums;

public enum EmpresaEstado
{
    ACTIVA,
    INACTIVA,
}
