namespace ShcMvpEndPoint.Domain.Common;

// Vive en Domain (no en el Shared del host) para que ShcMvpEndPoint.Infrastructure/Middleware
// (p.ej. ValidationFilter<T>) pueda envolver sus respuestas sin crear una referencia circular
// Infrastructure -> ShcMvpEndPoint (host).
public sealed record ApiResponse<T>
{
    public required T? Data { get; init; }
    public required bool Success { get; init; }
    public string? Message { get; init; }
    public string[]? Errors { get; init; }
    public PaginationMeta? Pagination { get; init; }
}

public static class ApiResponse
{
    public static ApiResponse<T> Ok<T>(T data, string? message = null) => new()
    {
        Data = data,
        Success = true,
        Message = message,
    };

    public static ApiResponse<IEnumerable<T>> Paged<T>(IEnumerable<T> data, PaginationMeta pagination, string? message = null) => new()
    {
        Data = data,
        Success = true,
        Message = message,
        Pagination = pagination,
    };

    public static ApiResponse<object?> Fail(string message, string[]? errors = null) => new()
    {
        Data = null,
        Success = false,
        Message = message,
        Errors = errors,
    };
}
