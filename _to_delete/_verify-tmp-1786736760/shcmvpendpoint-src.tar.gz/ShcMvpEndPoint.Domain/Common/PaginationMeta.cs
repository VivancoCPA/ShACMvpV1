namespace ShcMvpEndPoint.Domain.Common;

public sealed record PaginationMeta(int Page, int PageSize, int TotalItems, int TotalPages)
{
    public static PaginationMeta Create(int page, int pageSize, int totalItems)
    {
        var totalPages = pageSize <= 0 ? 0 : (int)Math.Ceiling(totalItems / (double)pageSize);
        return new PaginationMeta(page, pageSize, totalItems, totalPages);
    }
}
