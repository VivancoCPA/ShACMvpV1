namespace ShcMvpEndPoint.Domain.Entities;

// Solo el hash SHA-256 del token crudo se persiste — el valor crudo únicamente vive en la
// cookie httpOnly del cliente. Rotación: cada /auth/refresh revoca este y emite uno nuevo.
public class RefreshToken
{
    public Guid Id { get; set; }
    public required Guid UsuarioId { get; set; }
    public required string TokenHash { get; set; }

    // Empresa activa de esta sesión de refresh — se actualiza in-place en /switch-empresa (sin
    // rotar el token) para que un /refresh posterior restaure la empresa correcta. Réplica del
    // header x-mock-empresa-activa del mock, pero resuelto server-side en vez de confiar en el
    // cliente (ver mockSession.ts: "a real backend would carry empresaActivaId inside its own
    // server-side session/JWT, not in localStorage").
    public Guid? EmpresaActivaId { get; set; }

    public DateTime ExpiresAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? RevokedAt { get; set; }

    public bool IsActive => RevokedAt is null && ExpiresAt > DateTime.UtcNow;
}
