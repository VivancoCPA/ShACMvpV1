using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Domain.Entities;

public class Empresa
{
    public Guid Id { get; set; }
    public required string RazonSocial { get; set; }
    public required string Ruc { get; set; }
    public EmpresaEstado Estado { get; set; } = EmpresaEstado.ACTIVA;
    public string? LogoUrl { get; set; }
    public DateTime FechaAlta { get; set; }
}
