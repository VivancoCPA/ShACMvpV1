using ShcMvpEndPoint.Domain.Enums;

namespace ShcMvpEndPoint.Domain.Entities;

// Fuente única del rol efectivo: un usuario puede tener filas distintas en distintas empresas
// con roles distintos. Único índice (UsuarioId, EmpresaId) — reasignar reactiva y actualiza Rol
// en vez de duplicar (ver POST /api/empresas/:id/usuarios).
public class UsuarioEmpresa
{
    public Guid Id { get; set; }
    public required Guid UsuarioId { get; set; }
    public required Guid EmpresaId { get; set; }
    public UserRole Rol { get; set; }
    public UsuarioEmpresaEstado Estado { get; set; } = UsuarioEmpresaEstado.ACTIVO;
    public DateTime FechaAsignacion { get; set; }
}
