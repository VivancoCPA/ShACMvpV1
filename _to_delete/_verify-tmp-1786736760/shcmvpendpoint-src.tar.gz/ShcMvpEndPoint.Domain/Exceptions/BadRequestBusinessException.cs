namespace ShcMvpEndPoint.Domain.Exceptions;

// 400 con envelope ApiResponse.Fail para checks de negocio que el contrato documenta como 400
// pero que no son un error de forma de FluentValidation (p.ej. "Token inválido o expirado",
// "Se requiere firma (PIN) para cambiar el estado").
public sealed class BadRequestBusinessException(string message) : Exception(message);
