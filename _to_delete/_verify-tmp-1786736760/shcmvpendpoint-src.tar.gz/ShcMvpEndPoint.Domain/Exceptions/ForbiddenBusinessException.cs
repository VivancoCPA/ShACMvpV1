namespace ShcMvpEndPoint.Domain.Exceptions;

// 403 — identidad válida pero la acción está prohibida por una regla de negocio explícita
// (p.ej. usuario deshabilitado, empresa no asignada, rol sin permiso). Distinto de
// UnauthorizedBusinessException (401, sesión/credenciales inválidas).
public sealed class ForbiddenBusinessException(string message) : Exception(message);
