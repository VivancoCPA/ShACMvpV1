namespace ShcMvpEndPoint.Domain.Exceptions;

// 409 — estado del recurso incompatible con la operación (p.ej. RN-DOC-005, RN-NC-* edición bloqueada).
public sealed class ConflictException(string message) : Exception(message);
