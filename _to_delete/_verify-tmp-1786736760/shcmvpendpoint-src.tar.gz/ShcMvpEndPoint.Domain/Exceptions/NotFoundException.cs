namespace ShcMvpEndPoint.Domain.Exceptions;

// 404 uniforme — usar también cuando el recurso existe pero pertenece a otra empresa (nunca 403,
// para no filtrar existencia cross-tenant, ver "Convenciones globales" del contrato de API).
public sealed class NotFoundException(string message) : Exception(message);
