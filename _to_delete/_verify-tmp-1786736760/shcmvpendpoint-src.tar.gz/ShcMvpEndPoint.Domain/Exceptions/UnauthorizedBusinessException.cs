namespace ShcMvpEndPoint.Domain.Exceptions;

// 401 con envelope ApiResponse.Fail — para credenciales inválidas / PIN inválido / sin empresa activa,
// a diferencia de un 401 genérico del pipeline de autenticación JWT.
public sealed class UnauthorizedBusinessException(string message) : Exception(message);
