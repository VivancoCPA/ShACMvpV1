namespace ShcMvpEndPoint.Domain.Exceptions;

// 422 — transición/regla de negocio inválida (p.ej. "RN-QE-002: causa raíz no firmada").
// RuleCode es opcional y se antepone al mensaje si viene, replicando el formato del contrato.
public sealed class BusinessRuleException(string message, string? ruleCode = null)
    : Exception(ruleCode is null ? message : $"{ruleCode}: {message}")
{
    public string? RuleCode { get; } = ruleCode;
}
