# SHAC — Contrato de API para Backend .NET (generado desde specs MSW + código fuente)

> Generado a partir de una lectura completa de los 31 archivos `openspec/specs/**/spec.md` del repo `ShcMvp`, el 2026-08-13. Documento de trabajo para el equipo de backend .NET — no es una spec de producto, es la extracción del contrato HTTP implícito en los MSW handlers, clientes Axios y hooks TanStack Query actuales.
>
> **Actualización 2026-08-13**: la sección 1 (Documentos) fue ampliada con el contrato completo de sus ~14 sub-endpoints de archivo/firma/PDF, reconstruido directamente desde el código fuente (no desde specs, que nunca los detallaron) — este documento unifica lo que antes eran dos archivos separados (`SHAC-Contrato-API-Backend-NET-2026-08-13.md` y `SHAC-Documentos-Subendpoints-Contrato-2026-08-13.md`) en uno solo, para tener el contrato de API completo centralizado.

## Convenciones globales (de CLAUDE.md, confirmadas)

- Toda respuesta va envuelta en `ApiResponse<T>`:
  ```ts
  interface ApiResponse<T> {
    data: T
    success: boolean
    message?: string
    errors?: string[]
    pagination?: { page: number; pageSize: number; totalItems: number; totalPages: number }
  }
  ```
- Base URL: `VITE_API_BASE_URL`.
- Auth: Bearer JWT, refresh automático en 401 (ver módulo Auth).
- **Multiemprea (empresaId)**: añadido en una fase posterior del proyecto. Todo endpoint de lista/mutación de Documentos, Incidentes, NC, Quality Events, Locales, Zonas, Notificaciones y Dashboard está ahora scoped por `empresaId` = empresa activa de la sesión (`empresaActivaId`). Reglas consistentes en todos los módulos scoped:
  - El candidato de datos se filtra por `empresaId === empresaActivaId` **antes** que cualquier otro filtro.
  - Un recurso existente pero de otra empresa responde exactamente igual que un id inexistente (mismo status, mismo shape) — nunca revela que el recurso existe en otra empresa.
  - Las creaciones fijan `empresaId` desde la sesión, nunca desde el body del cliente.
  - Si la sesión no tiene empresa activa (`empresaActivaId === null`), las creaciones responden `401`.
  - Las secuencias correlativas (código de documento, número de incidente/NC/QE/local) son independientes por empresa (RN-EMP-003).
  - Algunos módulos son anteriores a esta fase y no mencionan `empresaId` explícitamente en su spec original — están marcados abajo con **⚠ predates empresaId**.
- **Patrón "blob download" de MSW — NO replicar en el backend real**: varios módulos (ver Documentos) mencionan endpoints de archivo (`/archivo-original`, `/archivo-distribucion`, `/download-url`) que en el mock MSW simulan descarga de blobs/URLs falsas en memoria. El backend .NET real **no** necesita replicar la simulación de blobs — debe devolver URLs firmadas (signed URLs) de almacenamiento real (S3/Azure Blob/etc.), no un endpoint que sirva bytes simulados. Ver sección "Flags de revisión" para el detalle de qué de esto no está completamente especificado.

---

## 1. Documentos (M1)

Fuente de los 6 endpoints core (CRUD + workflow): `document-api-client`, `document-msw-handlers`, `document-query-hooks`, `document-msw-fixtures`.

Fuente de los ~14 sub-endpoints de archivo/firma/PDF (sección 1.2): **código fuente**, no specs — `src/mocks/handlers/documents.handlers.ts` (el handler MSW, más autoritativo), `useDocumentActions.ts`, `useDocuments.ts`, `useDocumentDetail.ts`, `useDocumentVersiones.ts`, `documents.api.ts` (wrapper Axios), `permissions.ts`, los componentes que los invocan (`DocumentActionPanel.tsx`, `DocumentReplaceArchivoOriginalModal.tsx`, `DocumentNuevaVersionModal.tsx`, `DocumentSignatureModal.tsx`, `FileUploadField.tsx`), el schema Zod `nuevaVersion.schema.ts`, y los specs `document-pdf-security`/`document-permissions` como contexto de reglas de negocio. Estos sub-endpoints nunca fueron detallados en los specs de openspec — solo mencionados de pasada en el requisito de aislamiento por empresa de `document-msw-handlers` — por lo que se reconstruyeron leyendo el código directamente (reconstrucción hecha 2026-08-13, con 4 gaps iniciales ya cerrados tras revisar `documents.api.ts` y `permissions.ts`).

Store scoped por `empresaId` (documentado explícitamente). El mock valida `doc.empresaId !== getActiveEmpresaId()` → `404` "Documento no encontrado" antes de cualquier otra lógica en **todos** los endpoints de este módulo, core y sub-endpoints — el .NET real debe replicar ese `404` (no `403`) para no filtrar existencia cross-tenant.

### 1.1 Endpoints core (CRUD + workflow)

| Método | Path | Descripción | Body / Params | Response `data` | Status especiales |
|---|---|---|---|---|---|
| GET | `/api/documents` | Lista paginada de documentos | Query: `estado?`, `tipo?`, `area?`, `search?` (substring case-insensitive en `titulo`/`codigo`), `page?` (def 1), `pageSize?` (def 10) | `Documento[]` + `pagination` | — |
| GET | `/api/documents/:id` | Detalle de un documento | — | `Documento` | 404 si no existe o es de otra empresa |
| POST | `/api/documents` | Crea documento en `BORRADOR` | `CreateDocumentInput` (`titulo`, `tipo`, `area`, `revisorId?`, `aprobadorId?`, ...) | `Documento` (id UUID, `codigo` autogenerado `<Tipo>-CD-<NNN>` correlativo por empresa, `version: 'v1.0'`, `estado: 'BORRADOR'`) | 201; 401 si no hay empresa activa |
| PUT | `/api/documents/:id` | Actualiza documento parcial | `UpdateDocumentInput` (solo campos provistos) | `Documento` | 200; 409 si `estado !== BORRADOR` |
| DELETE | `/api/documents/:id` | Elimina documento | — | `void` | 200; 409 si no está en `BORRADOR` o tiene `qeVinculados` no vacío |

### 1.2 Sub-endpoints de archivo, firma y PDF (reconstruidos desde código fuente)

Convenciones ya conocidas y no repetidas endpoint por endpoint: respuestas envueltas en `ApiResponse<T>` salvo donde se indique explícitamente "binario directo"; Auth Bearer JWT; scoping por `empresaId` como se describe arriba.

#### 1.2.1 `POST /api/documents/:id/status` (con firma) y `PATCH /api/documents/:id/status` (sin firma)

Dos rutas de cambio de estado con distinta exigencia de PIN — el frontend usa ambas desde `useChangeStatus` (`DocumentActionPanel.tsx`).

- **POST** — body JSON: `{ nuevoEstado: DocStatus; comentario?: string; firma?: string; notificarAutor?: boolean }`. `firma` es **obligatorio** — si falta, `400` con mensaje `"Se requiere firma (PIN) para cambiar el estado (RN-DOC-004)"`.
- **PATCH** — body JSON: `{ estado: DocStatus; motivo?: string; notificarAutor?: boolean }`. Sin campo de firma, sin validación de PIN.

**Response `data`**: `Documento` actualizado completo (mismo shape que GET detail, incluyendo `auditTrail` con la nueva entrada `ESTADO_CAMBIADO`).

**Status codes**: `404` documento no existe/empresa distinta; `400` (solo POST) falta `firma`; `422` transición inválida según `DOC_STATUS_TRANSITIONS[doc.estado]`; `409` si `nuevoEstado === 'OBSOLETO'` y `doc.qeVinculados.length > 0` (RN-DOC-005).

**Reglas de negocio**: RN-DOC-001 (al pasar a `PUBLICADO`, cualquier otra versión con mismo `codigo`+`empresaId` en `PUBLICADO` se obsoletiza automáticamente); al pasar a `PUBLICADO` se congela el archivo original (`archivoOriginalBloqueado = true`) y se genera `archivoDistribucionUrl` (auditoría `ARCHIVO_ORIGINAL_CONGELADO` + `ARCHIVO_DISTRIBUCION_GENERADO`); si `nuevoEstado === 'BORRADOR'` desde `EN_REVISION` con `notificarAutor: true`, notifica al autor.

**.NET**: decidir si mantiene dos rutas (POST con PIN vs PATCH sin PIN) o las colapsa en una con validación condicional — el mock las mantiene separadas y ambas están activamente en uso.

#### 1.2.2 `POST /api/documents/:id/sign`

**Request** — Content-Type JSON. Body confirmado en `documents.api.ts`: `interface SignDocumentPayload { password: string; timestamp: string }` (ambos **obligatorios**). El frontend (`DocumentSignatureModal.tsx` vía `useSignDocument`) siempre manda `{ password, timestamp: new Date().toISOString() }`.

**Response `data`**: `Documento` con `estado: 'PUBLICADO'`, `hashArchivo: 'sha256-mock-{id}'` (placeholder — el .NET debe calcular un hash real), `archivoOriginalBloqueado: true`, `archivoDistribucionUrl` generado, `auditTrail` con `FIRMA_REGISTRADA` + `ARCHIVO_ORIGINAL_CONGELADO` + `ARCHIVO_DISTRIBUCION_GENERADO`.

**Status codes**: `404`; `401` si `password !== MOCK_PIN` (mock hardcodea `'123456'`; .NET debe validar contra la credencial real) — mensaje `"Credenciales inválidas"`; `409` si `doc.estado !== 'EN_APROBACION'`.

**Roles/estados**: según `document-permissions`, solo `APROBADOR` (asignado como `aprobadorId` de ESE documento) puede firmar, y solo en `EN_APROBACION`. **El handler mock no valida el rol/identidad del firmante server-side** — solo PIN y estado; el .NET debe agregar esta verificación de autorización explícitamente, no confiar solo en el frontend.

**Reglas de negocio**: RN-DOC-004 (firma/PIN obligatoria); RN-DOC-001 (obsoletiza versión previa publicada). Confirmado en `documents.api.ts`: existe únicamente `signDocument()` llamando a `POST /sign` — ninguna función wrapper llama a `POST /publicar` (ver 1.2.13).

#### 1.2.3 `GET /api/documents/:id/archivo`

**Request**: sin body, solo `:id`.

**Response `data`**: `{ url, expiresAt (ISO, +15 min), nombreArchivo, tipoArchivo }`. `tipoArchivo` default `'application/pdf'`.

**Status codes**: `404`.

**Reglas de negocio**: cada llamada agrega `VISUALIZACION` al `auditTrail` (RN-DOC-008/009) — efecto secundario de un GET, cuidado si se cachea en .NET. El mock devuelve una URL fija de ejemplo en vez de un archivo real. Usado por `useGetArchivoUrl` (botón "Ver archivo"), que hace `window.open(data.url, '_blank')` directo — **no** usa el patrón blob (a diferencia de `archivo-original`/`archivo-distribucion`), porque aquí es una URL navegable real.

**.NET / almacenamiento local**: "signed view URL" del archivo PUBLICADO/vigente. Resolver la ruta física en disco (`/data/documentos/{empresaId}/{id}/publicado/{version}.pdf`), generar URL temporal firmada (15 min TTL) servida por un endpoint de streaming — el contrato JSON se mantiene igual.

#### 1.2.4 `POST /api/documents/:id/nueva-version`

**Request**: JSON, validado client-side (Zod, `nuevaVersion.schema.ts`): `{ tipoCambio: 'MENOR'|'MAYOR'; motivo: string (min 20 chars) }`, ambos requeridos.

**Response `data`** (201): **nuevo** `Documento` — `version` calculada por `calcularNuevaVersion` (MENOR incrementa minor, MAYOR incrementa major y resetea minor); `estado: 'BORRADOR'`; `versionAnteriorId`; `archivoUrl`/`hashArchivo`/`fechaEmision`/`revisorId`/`aprobadorId` reseteados; `archivoOriginalBloqueado: false`; `archivoDistribucionUrl: null`; `qeVinculados: []`; `historialVersiones: []`; `auditTrail` nuevo (`DOCUMENTO_CREADO`, `ARCHIVO_ORIGINAL_COPIADO_A_VERSION`). El documento origen se actualiza in-place con `NUEVA_VERSION_INICIADA`.

**Status codes**: `404`; `409` si ya existe otra versión del mismo `codigo`+`empresaId` en `BORRADOR`/`EN_REVISION`/`EN_APROBACION` (RN-DOC-001) — el backend debe re-validar aunque el frontend ya pre-chequee (carrera de condiciones).

**Roles/estados**: botón visible si `PUBLICADO && (isAutor || isJefeCalidad)`, o `EN_REVISION_PERIODICA && (isAutor || isJefeCalidad)`. El handler mock no valida rol server-side.

**Reglas de negocio**: RN-DOC-002 (numeración MENOR/MAYOR); RN-DOC-001 (no dos versiones "en proceso" simultáneas). El mock **no copia realmente el archivo físico** al crear nueva versión, solo referencia la URL vieja en auditoría — **decisión de diseño pendiente para .NET**: ¿copia física a la carpeta de la nueva versión, o referencia/symlink hasta que se reemplace?

#### 1.2.5 `POST /api/documents/:id/exportar-pdf`

**Request**: JSON `{ userNombreCompleto: string }` (enviado como `${user.nombre} ${user.apellido}`).

**Response**: **binario directo**, no `ApiResponse` — `200`, `Content-Type: application/pdf`, `Content-Disposition: attachment; filename="{codigo}-{version}-controlado.pdf"`. El mock en realidad genera **HTML** (no PDF real) con `Content-Type` mentiroso: marca de agua "COPIA NO CONTROLADA", metadata, usuario descargante, timestamp Lima, hash SHA-256 (o `'sin firma'`).

**Status codes**: `404`; `409` si `doc.estado !== 'PUBLICADO'`.

**Roles/estados**: `canExportarPdf = estado === 'PUBLICADO' && hasFileAccess && !!archivoUrl` — gate de confidencialidad, no de rol de asignación.

**Reglas de negocio**: RN-DOC-007 (watermark dinámico + timestamp Lima GMT-5); cada exportación registra `DESCARGA` en `auditTrail` (RN-DOC-008). **Es síncrono** — sin job en background. El .NET debe generar el PDF real (QuestPDF/PdfSharp o similar) síncronamente. El spec `document-pdf-security` deja explícitamente pendiente para el backend real las restricciones de copia/impresión reales (RN-DOC-010, más allá del watermark visual).

#### 1.2.6 `GET /api/documents/:id/download-url`

**Request**: query opcional `?expired=true` (solo testing en el mock — probablemente no debe existir en producción, o debe ser un modo de test controlado).

**Response `data`**: `{ url: "mock://signed-url-{id}", expiresAt (ISO, +15 min) }`.

**Status codes**: `403` si `?expired=true` (`"URL de descarga expirada"`); `404`.

**Reglas de negocio**: RN-DOC-009 (URL firmada TTL 15 min). Primer paso de un flujo de 3 pasos (`document-pdf-security`): (1) este GET → (2) `POST /audit/access` con `{accion:'DESCARGA', timestamp}` **secuencial, no paralelo** → (3) abrir descarga. Si el paso 1 devuelve 403, el flujo se detiene y no se llama al paso 2.

**.NET / almacenamiento local**: emitir token firmado real (JWT corto o token de un solo uso) apuntando a un endpoint de streaming validado contra el path físico y el TTL — reemplaza `mock://signed-url-{id}` sin cambiar el shape `{url, expiresAt}`.

#### 1.2.7 `PATCH /api/documents/:id/confirmar-revision`

**Request**: sin body.

**Response `data`**: `Documento` con `estado: 'PUBLICADO'` (siempre, incluso viniendo de `EN_REVISION_PERIODICA`) y `fechaRevisionProxima` recalculada según `tipo`: `POL`/`PRC`/`PLAN` → +1 año; `MAT` → +6 meses; `INS` → +2 años; `REG`/`INF` → `undefined`. `auditTrail` gana `REVISION_PERIODICA_CONFIRMADA`.

**Status codes**: `404`; `409` si `estado` no es `PUBLICADO` ni `EN_REVISION_PERIODICA`.

**Roles/estados**: `canStartPeriodic = PUBLICADO && isJefeCalidad` (`JEFE_CALIDAD_SYST`/`JEFE_CONTROL_DOCUMENTARIO`). Sin re-validación server-side de rol en el mock.

**Reglas de negocio**: tabla de vigencia por `DocType` — regla explícita en código, no documentada en ningún spec, debe trasladarse tal cual. Es confirmación "sin cambios": no crea versión ni modifica archivo, solo renueva fecha y estado.

#### 1.2.8 `PATCH /api/documents/:id/restaurar`

**Request**: sin body.

**Response `data`**: `Documento` con `deletedAt: undefined`, `estado: 'BORRADOR'` (siempre, sin importar el estado al momento de eliminarse), `auditTrail` gana `RESTAURADO`.

**Status codes**: `404`; `409` si `!doc.deletedAt` (`"El documento no está eliminado"`).

**Roles/estados**: `canRestore = rol ∈ {JEFE_CALIDAD_SYST, ALTA_DIRECCION}`. Sin validación server-side en el mock.

**Reglas de negocio**: restaurar siempre fuerza `BORRADOR`, aunque el estado original al eliminarse fuera `EN_REVISION` — confirmar si es intencional o gap a corregir en .NET.

#### 1.2.9 `POST /api/documents/:id/audit/access`

**Request**: JSON `{ accion: 'DESCARGA'|'VISUALIZACION'; timestamp?: string }` (si se omite, el mock usa `new Date().toISOString()` server-side).

**Response `data`**: `{ success: true }`.

**Status codes**: `404`.

**Reglas de negocio**: RN-DOC-008 (todo acceso a contenido debe auditarse). El .NET debería validar que `accion` sea uno de los valores permitidos (el mock no valida enum). Paso 2 del flujo de 3 pasos de `document-pdf-security` — **secuencial y bloqueante** antes de servir el archivo, no "fire and forget". El actor debe resolverse del JWT/sesión real en .NET, no del body (el mock usa un default hardcodeado).

#### 1.2.10 `GET /api/documents/:id/archivo-original`

**Request**: sin body, solo `:id`.

**Response**: **binario directo** — `200`, `Content-Type: .docx OOXML`, `Content-Disposition: attachment`. El mock genera un `.docx` mínimo placeholder.

**Status codes**: `404` (no existe/otra empresa); `403` si no tiene acceso al original (`"Acceso denegado al archivo original (RN-DOC-013, RN-DOC-016)"`); `404` (branch distinto) si `!doc.archivoOriginalUrl`.

**Gate de autorización exacto** (por-documento, no por rol global):
```
docRole = AUTOR si doc.autorId === user.id
        | REVISOR si doc.revisorId === user.id
        | APROBADOR si doc.aprobadorId === user.id
        | JEFE_CALIDAD si user.rol ∈ {JEFE_CALIDAD_SYST, JEFE_CONTROL_DOCUMENTARIO}
        | OPERARIO en cualquier otro caso

isEditableState = doc.estado ∈ {BORRADOR, EN_REVISION}
isHistoricalAccess = doc.estado === 'OBSOLETO' && user.rol ∈ {JEFE_CONTROL_DOCUMENTARIO, ALTA_DIRECCION}  // CA-34

acceso permitido ⟺ (docRole !== OPERARIO && isEditableState) || isHistoricalAccess
```
RN-DOC-013 (visible solo BORRADOR/EN_REVISION) + RN-DOC-016 (solo asignados). CA-34 permite a `JEFE_CONTROL_DOCUMENTARIO`/`ALTA_DIRECCION` ver el original de documentos `OBSOLETO` para trazabilidad histórica. El mismo gate decide si `GET /api/documents/:id` expone `archivoOriginalUrl`/`archivoOriginalNombre` (`null` si no corresponde).

**⚠ Discrepancia real detectada** (código vs. UI, no un gap de información): el flag de UI `canViewArchivoOriginal` en `permissions.ts` es `rol !== 'OPERARIO' && estado ∈ {BORRADOR, EN_REVISION}` — coincide con la mitad `docRole !== OPERARIO && isEditableState` del gate, pero **no contempla la excepción histórica `isHistoricalAccess`** (CA-34). Resultado: un `JEFE_CONTROL_DOCUMENTARIO` consultando un documento `OBSOLETO` **podría descargar exitosamente vía API** (el handler se lo permite por CA-34) pero **la UI no le muestra el botón**. A decidir explícitamente en el diseño .NET: alinear `canViewArchivoOriginal` para incluir el caso `OBSOLETO`+rol privilegiado, o documentar el acceso como "solo por URL directa/API, sin UI dedicada".

**Reglas de negocio**: RN-DOC-013, RN-DOC-016, CA-34 (arriba). Cada descarga exitosa agrega `DESCARGA_ARCHIVO_ORIGINAL` al `auditTrail`. El frontend usa el patrón blob (fetch → blob → object URL → `<a download>` → revoke) por la limitación de MSW con `window.open` — el backend .NET real puede volver a `window.open(url)` directo con URLs pre-firmadas, o mantener el patrón blob por consistencia (decisión abierta, no obligatoria).

**.NET / almacenamiento local**: resolver path físico (`{empresaId}/{documentId}/original/...`), aplicar el gate exacto server-side vía JWT (replicar `getDocRoleForUser`, no un query param como en el mock), streaming del archivo real, registrar auditoría de forma atómica con el streaming.

#### 1.2.11 `POST /api/documents/:id/archivo-original` — reemplazar archivo original

**Request**: **`multipart/form-data`**. Tipos aceptados client-side: `.docx`/`.xlsx` (no PDF ni legacy `.doc`/`.xls`). Máximo 50 MiB client-side. **Campo multipart confirmado en `documents.api.ts`: `archivoOriginal`** (no `file` ni `archivo`), único archivo, sin metadata adicional en el mismo request:
```ts
const formData = new FormData()
formData.append('archivoOriginal', file)
api.post<{ archivoOriginalUrl, archivoOriginalNombre }>(`/api/documents/${id}/archivo-original`, formData, {...})
```
El .NET debe esperar el binario bajo ese nombre exacto (`[FromForm] IFormFile archivoOriginal` o equivalente).

**Response `data`**: `{ archivoOriginalUrl, archivoOriginalNombre }`. El mock siempre nombra el archivo generado como `.docx` sin importar la extensión real subida (no puede leer el body) — el .NET debe devolver la extensión real.

**Status codes**: `404`; `403` si `archivoOriginalBloqueado` (RN-DOC-015); `403` si `estado` no es `BORRADOR`/`EN_REVISION` (RN-DOC-013).

**⚠ Asimetría relevante**: a diferencia del GET (1.2.10), **este handler POST no valida `docRole`/asignación en absoluto** en el mock — solo estado y congelamiento. Cualquier usuario autenticado con acceso a la ruta puede reemplazar mientras esté editable y no congelado. **Confirmado en `permissions.ts`** que la UI es más estricta: `canReplaceArchivoOriginal = (rol === 'AUTOR' || rol === 'JEFE_CALIDAD') && estado ∈ {BORRADOR, EN_REVISION} && !archivoOriginalBloqueado` — excluye `REVISOR`/`APROBADOR`, a diferencia de `canViewArchivoOriginal`. **El .NET debe aplicar exactamente este gate server-side** en el POST (no el gate más amplio de lectura del GET) — la asimetría del mock es efectivamente un gap a cerrar en .NET, ya con el gate correcto identificado.

**Reglas de negocio**: RN-DOC-015, RN-DOC-013; auditoría `ARCHIVO_ORIGINAL_ACTUALIZADO`. El mock simplemente sobreescribe la URL — no hay borrado/versionado del archivo físico anterior. **Decisión de diseño abierta para .NET**: ¿borrar el archivo anterior, archivarlo con sufijo de timestamp, o mantenerlo versionado? Recomendable mantenerlo (soft-delete/rename) dado que es un sistema ISO con trazabilidad de auditoría.

**.NET / almacenamiento local**: validar MIME real (no solo extensión) y tamaño; escribir a disco en ruta determinística (`{empresaId}/{id}/original/{timestamp}-{nombre}.{ext}`); decidir política del archivo anterior; devolver `{archivoOriginalUrl, archivoOriginalNombre}` reales manteniendo el mismo shape.

#### 1.2.12 `GET /api/documents/:id/archivo-distribucion`

**Request**: sin body, solo `:id`.

**Response**: **binario directo** — `200`, `Content-Type: application/pdf`, `Content-Disposition: attachment`. El mock genera un PDF real y mínimo con `jsPDF`.

**Status codes**: `404`; `404` (branch distinto) si `!doc.archivoDistribucionUrl`.

**Roles/estados**: sin chequeo de rol en el handler. **Confirmado en `permissions.ts`**: `canViewArchivoDistribucion = base.canRead && estado ∈ {PUBLICADO, EN_REVISION_PERIODICA}` — depende del permiso de lectura base (`true` para todos los roles en esos estados, incluido `OPERARIO`), no de asignación específica. Gate mucho más laxo que el archivo original (1.2.10) — el .NET debe replicar exactamente esta laxitud, no el gate estricto de 1.2.10.

**Reglas de negocio**: RN-DOC-018 (solo existe tras publicación); cada descarga registra `DESCARGA` en `auditTrail`; mismo patrón blob que archivo-original.

**.NET / almacenamiento local**: el PDF de distribución debe generarse **una sola vez** en el momento de publicación (`/sign` o transición a `PUBLICADO`) y persistirse en disco (`{empresaId}/{id}/distribucion/{version}.pdf`) — **no** regenerarse en cada GET como hace el mock; esta ruta solo debe hacer streaming del archivo ya generado.

#### 1.2.13 `POST /api/documents/:id/publicar`

**Request**: JSON `{ password?: string }`.

**Response `data`**: efecto **idéntico a `/sign`** (1.2.2) — mismos campos, misma obsoletización de versión previa, misma auditoría.

**Status codes**: `404`; `401` si password inválido; `409` si `estado !== 'EN_APROBACION'`.

**⚠ Recomendación — candidato a no portar**: revisando `documents.api.ts` completo (17 funciones exportadas), **no existe ninguna función wrapper que llame a `POST /publicar`** — el único call site real de firma/publicación en toda la app es `signDocument()` → `POST /sign`. El código comenta `/publicar` como "(ADD-02)", sugiriendo que viene de un addendum de spec distinto. Desde la perspectiva de "qué necesita el .NET para servir a la UI actual", la respuesta es clara: **solo `/sign` es estrictamente necesario**. Lo que el código no puede resolver es la intención de negocio original (¿vestigial, o pensado para un consumidor API-to-API fuera del frontend?) — **requiere confirmación de Toño/PM, no más lectura de código**. Recomendación: implementar `/sign` como ruta canónica y no portar `/publicar` salvo que se confirme un consumidor externo.

#### 1.2.14 `POST /api/documents/:id/upload`

Único otro endpoint de archivo en el handler, para el archivo "de trabajo" `archivoUrl` (no el original ni el de distribución). Incluido por completitud.

**Request**: `multipart/form-data`. El propio mock trae el comentario "MSW cannot parse multipart/form-data boundaries in the browser. This handler ignores the request body". **Confirmado en `documents.api.ts`**: ninguna de las 17 funciones exportadas llama a `/upload` — es efectivamente **vestigial, sin consumidor en el frontend actual**.

**Response `data`**: `{ archivoUrl, hashArchivo (64 hex random) }`.

**Status codes**: `404`.

**Recomendación**: no portar a .NET salvo que se identifique un consumidor externo al frontend. `hashArchivo` debería ser un SHA-256 real si se implementa.

### 1.3 Resumen de traducción "mock blob simulation" → disco local (.NET)

| Endpoint | Mock hoy | .NET / disco local |
|---|---|---|
| `GET /archivo` | URL fija externa hardcodeada | Path del archivo publicado vigente en disco, URL firmada de streaming (TTL 15 min) |
| `GET /download-url` | `mock://signed-url-{id}` falso | Token firmado real hacia endpoint de streaming validado contra disco |
| `POST /archivo-original` | Ignora el body, nombre/URL falsos | Multipart real → disco (`{empresaId}/{id}/original/`), decide retención del anterior |
| `GET /archivo-original` | `.docx` mínimo on-the-fly | Streaming real desde disco, gate de autorización por asignación (1.2.10) |
| `GET /archivo-distribucion` | PDF mínimo on-the-fly en cada request | Generado **una vez** al publicar, persistido; esta ruta solo hace streaming |
| `POST /exportar-pdf` | HTML con `Content-Type` mentiroso, síncrono | PDF real (con watermark dinámico) síncrono; mismo `Content-Disposition` |
| `POST /upload` | Ignora body, nombre/hash falsos (vestigial) | No recomendado portar — sin consumidor real |

En todos los casos, el **contrato JSON que el frontend consume no cambia** (mismos nombres de campo: `url`, `expiresAt`, `archivoUrl`, `archivoOriginalUrl`, `archivoOriginalNombre`, `hashArchivo`) — el frontend no se reescribe, solo el backend pasa de MSW/simulado a .NET real sobre disco. El patrón blob del frontend seguirá funcionando sin cambios contra un backend real que sirva `Content-Disposition: attachment` con bytes reales.

### 1.4 Shape `Documento` (campos confirmados por fixtures y handler)
`id, codigo, titulo, tipo (POL|PRC|INS|REG|INF|MAT|PLAN), version, estado (BORRADOR|EN_REVISION|EN_APROBACION|PUBLICADO|OBSOLETO|EN_REVISION_PERIODICA), area, autorId, revisorId?, aprobadorId?, archivoUrl?, hashArchivo?, fechaEmision?, archivoOriginalUrl?, archivoOriginalNombre?, archivoOriginalBloqueado, archivoDistribucionUrl?, fechaRevisionProxima?, versionAnteriorId?, deletedAt?, qeVinculados: string[], historialVersiones: VersionEntry[], auditTrail: AuditTrailEntry[], creadoEn, actualizadoEn, empresaId`

### 1.5 Query keys / hooks (TanStack Query, `src/features/documents/hooks/`)
- `QUERY_KEYS.documents.list(filters)`, `.detail(id)`, `.all`
- `useDocuments(filters)`, `useDocument(id)` (disabled si `id===''`)
- `useCreateDocument()`, `useUpdateDocument()`, `useChangeDocumentStatus()`, `useDeleteDocument()` — todas invalidan `documents.all` en éxito
- `useDocumentActions.ts`: `useSignDocument()`, `useGetArchivoUrl()`, `useCreateNuevaVersion()`, `useExportarPdfControlado()`, `useConfirmarRevisionPeriodica()`, `useRestaurarDocumento()`, `useReplaceArchivoOriginal()`, `useGetArchivoOriginalUrl()`, `useGetArchivoDistribucionBlob()`, `useRegisterDocumentAccess()`, `useGetDocumentDownloadUrl()`

### 1.6 Reglas de negocio relevantes al contrato (core)
- RN-DOC-001: máquina de estados estricta (`DOC_STATUS_TRANSITIONS`); publicar un documento obsoleta automáticamente cualquier otro documento con el mismo `codigo` en `PUBLICADO`.
- RN-DOC-004: `firma` (PIN) obligatoria en toda transición de estado.
- RN-DOC-005: no se puede pasar a `OBSOLETO` un documento con QE vinculados activos.
- RN-DOC-006: referenciada pero sin detalle explícito en ningún spec ni en el código de sub-endpoints revisado — sigue siendo **flag de revisión**.
- Notificaciones `ASIGNACION` se generan al asignar/cambiar `revisorId`/`aprobadorId`; notificación `CAMBIO_ESTADO` al rechazar (`EN_REVISION → BORRADOR`) con `notificarAutor: true`.

### 1.7 Puntos de Documentos que siguen requiriendo una decisión de producto (no de código)
Estos 5 puntos no se resuelven leyendo más código — son decisiones de diseño/negocio para .NET, ya con todo el contexto técnico disponible:
1. **`/publicar` vs `/sign`**: sin consumidor en el frontend actual; decisión pendiente de Toño/PM sobre si portarlo (ver 1.2.13).
2. **Archivo original anterior al reemplazar** (1.2.11): ¿se borra, se archiva con timestamp, o se versiona? Recomendado versionar por trazabilidad ISO.
3. **Copia física en `nueva-version`** (1.2.4): ¿se copia el archivo original a la carpeta de la nueva versión en disco, o se referencia la versión anterior hasta que se reemplace?
4. **`canViewArchivoOriginal` vs. excepción CA-34** (1.2.10): alinear el permiso de UI con el gate real del backend, o documentar el acceso `OBSOLETO`+rol privilegiado como "solo API, sin botón en UI".
5. **Nombre de archivo `.docx` vs `.xlsx`** en la respuesta de `POST /archivo-original`: confirmar si el campo de subida real (`FileUploadField` permite ambos tipos) debe reflejarse con la extensión real en la respuesta — el mock siempre devuelve `.docx` como artefacto de su propia limitación, a ignorar en .NET.

---

## 2. Incidentes (M3)

Fuente: `incident-api-client`, `incident-msw-handlers`, `incident-tanstack-hooks`, `incident-msw-fixtures`.

Store scoped por `empresaId`. Incluye también sub-recursos de Locales/Zonas de solo lectura (ADD-03).

### Endpoints — Incidentes

| Método | Path | Descripción | Body / Params | Response `data` | Status especiales |
|---|---|---|---|---|---|
| GET | `/api/incidents` | Lista paginada | Query: `tipo?`, `fechaDesde?`, `fechaHasta?`, `search?` (numero/descripcion), `showDeleted?`, `page?`, `pageSize?` | `{ items: Incidente[], pagination }` (nota: shape es `data.items`, no `data` directo — ver Flags) | — |
| GET | `/api/incidents/:id` | Detalle | — | `Incidente` | 404 si no existe/otra empresa |
| POST | `/api/incidents` | Crea incidente | `CreateIncidentInput` (`tipo`, `descripcion` (≥20 chars), `areaId`, `turno`, `fechaEvento`, `huboLesionados`, `numPersonasAfectadas?`) | `Incidente` (numero `INC-2026-NNN` correlativo por empresa, `estado: 'ABIERTO'`, `severidad` auto-calculada) | 201; 400 si validación falla; 401 sin empresa activa |
| PATCH | `/api/incidents/:id` | Actualiza campos de investigación | `Partial<UpdateIncidentInvestigacionInput>` | `Incidente` | 200 |
| PATCH | `/api/incidents/:id/status` | Transición de estado | `{ estado: IncidentStatus, comentario? }` | `Incidente` | 200; 422 si transición inválida |
| DELETE | `/api/incidents/:id` | Soft delete | — | `void` (sets `deletedAt`) | 200; 422 si `estado !== 'ABIERTO'` |
| PATCH | `/api/incidents/:id/restore` | Restaura soft-delete | — | `Incidente` (`deletedAt` limpiado) | 200; 422 si no estaba eliminado |
| POST | `/api/incidents/:id/acciones` | Crea acción correctiva del incidente | `CreateACIncidenteInput` (`descripcion`, `responsableId`, `fechaLimite`) | `AccionCorrectivaIncidente` | 201 |
| PATCH | `/api/incidents/:incidenteId/acciones/:acId` | Actualiza AC del incidente | `Partial<AccionCorrectivaIncidente>` (p.ej. `estado`, `evidencia`) | `AccionCorrectivaIncidente` | 200 |
| PATCH | `/api/incidents/:incidenteId/acciones/:acId/cerrar` | Cierra AC (mencionado en requisito de aislamiento, sin requirement propio) | — | — | **flag de revisión** — sin contrato detallado |

### Endpoints — Locales/Zonas (solo lectura, ADD-03, vive en el mismo handler file)

| Método | Path | Descripción | Response `data` | Status |
|---|---|---|---|---|
| GET | `/api/locales` | Lista locales activos | `Local[]` (sin pagination — lista completa) | 200 |
| GET | `/api/locales/:localId/zonas` | Zonas activas de un local | `Zona[]` | 200; 404 si `localId` no existe |

### Shape `Incidente` (campos confirmados)
`id, numero (INC-2026-NNN), tipo (ACCIDENTE|INCIDENTE|CUASI_ACCIDENTE|CONDICION_INSEGURA), estado (ABIERTO|EN_INVESTIGACION|ANALISIS_COMPLETADO|EN_EJECUCION|PENDIENTE_CIERRE|CERRADO|ANULADO), severidad, turno, fechaEvento, fechaReporte, reportadoPorId, areaId, localId?, zonaId?, ubicacion?{x,y}, localNombre?, zonaNombre?, condicionesEntorno?, huboLesionados, numPersonasAfectadas?, accionesCorrectivas: AccionCorrectivaIncidente[], auditTrail, deletedAt?, empresaId`

### Query keys / hooks
- `INCIDENT_QUERY_KEYS.all` = `['incidents']`, `.list(filters)`, `.detail(id)`
- `useIncidents(filters)`, `useIncident(id)` (enabled solo si `id` truthy)
- `useCreateIncident()`, `useUpdateIncident()`, `useUpdateIncidentStatus()`, `useDeleteIncident()`, `useRestoreIncident()` — invalidan `['incidents']`
- `useCreateACIncidente(incidenteId)`, `useUpdateACIncidente(incidenteId)` — invalidan `INCIDENT_QUERY_KEYS.detail(incidenteId)`
- `useLocales()` — query key `['locales']`
- `useZonasByLocal(localId)` — query key `['locales', localId, 'zonas']`, disabled si `localId===''`

### Reglas de negocio relevantes al contrato
- Severidad auto-calculada server-side para `ACCIDENTE` según `huboLesionados`/`numPersonasAfectadas` (p.ej. 2 lesionados → `CRITICA`).
- "Reporte tardío" (>24h entre `fechaEvento` y submisión) genera entrada de audit trail `REPORTE_TARDIO` automáticamente — el backend debe calcular esto server-side, no confiar en el cliente.
- Solo se puede soft-delete incidentes en `ABIERTO`.
- Transición de estado válida notifica al reportante y a responsables de ACs no cerradas (excluyendo al actor).

---

## 3. No Conformidades (M2)

Fuente: `nc-api-client`, `nc-msw-handlers`, `nc-query-hooks`, `nc-msw-fixtures`.

Store scoped por `empresaId`.

### Endpoints

| Método | Path | Descripción | Body / Params | Response `data` | Status especiales |
|---|---|---|---|---|---|
| GET | `/api/nonconformities` | Lista paginada | Query: `estado?`, `tipo?`, `severidad?`, `dominio?`, `areaAfectada?`, `search?`, `fechaDesde?`, `fechaHasta?` (sobre `fechaDeteccion`), `page?` (def 1), `pageSize?` (def 20) | `NoConformidad[]` + `pagination` | — |
| GET | `/api/nonconformities/:id` | Detalle con ACs embebidas | — | `NoConformidad` (con `accionesCorrectivas` completo) | 404 `{success:false, message:'nonconformities:errors.notFound'}` si no existe/otra empresa |
| POST | `/api/nonconformities` | Crea NC | `CreateNCInput` (`origen`, `tipo`, `severidad`, `areaAfectada`, `descripcion`, `fechaDeteccion`, `dominio`, `forzar?: boolean`) | `NoConformidad & { warning?: 'POSIBLE_DUPLICADO', ncsSimilares?: NoConformidad[] }` | 201; `estado: 'DETECTADA'`, `numero` correlativo por empresa+dominio (`NC-<DOM>-2025-NNN`); 400 si faltan campos requeridos; 401 sin empresa activa |
| PATCH | `/api/nonconformities/:id` | Edita campos | `UpdateNCInput` (parcial) | `NoConformidad` | 200; 404 si no existe/otra empresa; 409 si `estado` es `CERRADA` o `ANULADA` |
| POST | `/api/nonconformities/:id/anular` | Anula la NC | `{ justificacion: string }` (requerido, no vacío) | `NoConformidad` (`estado: 'ANULADA'`) | 200; 400 si falta `justificacion`; 404 |
| POST | `/api/nonconformities/:id/acciones-correctivas` | Crea AC | `CreateACInput` (`descripcion`, `responsableId`, `plazoFecha` — todos requeridos) | `AccionCorrectiva` (`estado: 'PENDIENTE'`) | 201; 400 si falta campo; 404 |
| PATCH | `/api/nonconformities/:ncId/acciones-correctivas/:acId` | Actualiza AC | `UpdateACInput` | `AccionCorrectiva` | 200; 404 |
| POST | `/api/nonconformities/:ncId/acciones-correctivas/:acId/cerrar` | Cierra AC | `CerrarACInput` (`descripcionEvidencia` requerido, `evidenciaUrl?`) | `AccionCorrectiva` (`estado: 'COMPLETADA'`, `fechaCierre`) | 200; 400 si falta `descripcionEvidencia`; 404 |
| GET | `/api/users` | Lista de usuarios (vive en este mismo handler file por razones históricas) | — | `User[]` (6 fixtures, uno por rol) | Ver también módulo Gestión de Usuarios — hay dos endpoints `/api/users` documentados en specs distintas, ver Flags |

### Shape `NoConformidad`
`id, numero (NC-<DOM>-YYYY-NNN), origen, tipo, severidad (incl. CRITICA), dominio (CALIDAD|SST|ADUANERO|OPERACIONAL), areaAfectada, descripcion, fechaDeteccion, estado (ABIERTA|EN_INVESTIGACION|ANALISIS_COMPLETADO|EN_EJECUCION|PENDIENTE_CIERRE|CERRADA|ANULADA), reportadoPorId, causaRaiz?, requiereIPER? (solo SST), notificacionComercioExterior? (solo ADUANERO: {fecha, referencia, descripcion}), qeGeneradoId?, accionesCorrectivas: AccionCorrectiva[], auditTrail, empresaId`

`AccionCorrectiva`: `id, descripcion, responsableId, responsableNombre, plazoFecha, estado (PENDIENTE|EN_EJECUCION|COMPLETADA|VENCIDA), fechaCierre?, descripcionEvidencia?, evidenciaUrl?, qeId?`

### Query keys / hooks (`src/features/nonconformities/hooks/useNonconformities.ts`)
- `QUERY_KEYS.nonconformities.all/list(filters)/detail(id)`
- `useNonconformities(filters)` (staleTime 5 min), `useNonconformity(id)` (disabled si vacío)
- `useCreateNonconformity()`, `useUpdateNonconformity()`, `useAnularNonconformity()`, `useCreateAccionCorrectiva(ncId)`, `useUpdateAccionCorrectiva(ncId)`, `useCerrarAccionCorrectiva(ncId)`

### Reglas de negocio relevantes al contrato
- RN-NC-005: detección de duplicados — al crear, si existe otra NC del mismo `dominio`+`areaAfectada` creada en los últimos 30 días **de la misma empresa**, se devuelve `warning: 'POSIBLE_DUPLICADO'` + `ncsSimilares` junto con la NC creada (HTTP 201, no bloquea creación). `forzar: true` en el body salta esta detección.
- Edición bloqueada (409) si `estado` es `CERRADA` o `ANULADA`.
- Cambiar `estado` vía PATCH genera notificación `CAMBIO_ESTADO` al reportante y a responsables de ACs no cerradas.

---

## 4. Quality Events / QE

Fuente: `quality-event-api`, `quality-event-msw-handlers`, `quality-event-hooks`, `quality-event-msw-fixtures`.

Store scoped por `empresaId`. Es el módulo más complejo — máquina de estados de 9 estados con ciclos de reapertura, firma dual de cierre, verificación de eficacia, y solicitudes de ajuste de plazo con aprobación jerárquica.

### Endpoints — CRUD y transición principal

| Método | Path | Descripción | Body | Response `data` | Status |
|---|---|---|---|---|---|
| GET | `/api/quality-events` | Lista paginada | Query: `estado?`, `tipo?`, `severidad?`, `origen?`, `fechaDesde?`/`fechaHasta?` (sobre `fechaHoraEvento`), `soloReincidencias?` (ciclo>1), `page`, `pageSize` (def 10, requeridos en el tipo cliente `QEListParams`) | `QualityEvent[]` + `pagination` | — |
| GET | `/api/quality-events/:id` | Detalle | — | `QualityEvent` | 404 |
| POST | `/api/quality-events` | Crea QE | `QualityEventCreateInput` | `QualityEvent` (numero `QE-2026-NNN` correlativo por empresa) | 201; 401 sin empresa activa |
| PATCH | `/api/quality-events/:id` | Edita campos | `QualityEventUpdateInput` | `QualityEvent` | 200 |
| PATCH | `/api/quality-events/:id/status` | Transición de estado genérica | `QEStatusTransitionInput = { nuevoEstado, comentario?, firmaPin? }` | `QualityEvent` | 200; 422 con `message` de negocio (ej. `'RN-QE-002: causa raíz no firmada'`, `'RN-QE-004: se requiere firma dual'`) |

### Endpoints especializados del ciclo de vida QE

| Método | Path | Descripción | Body | Response / notas |
|---|---|---|---|---|
| GET | `/api/quality-events/:id/audit-trail` | Audit trail ordenado desc por timestamp | — | `QEAuditTrailEntry[]`; 404 |
| PATCH | `/api/quality-events/:id/solicitar-ac` | Incrementa `solicitudesAC` +1 | — | `QualityEvent`; 404 |
| PATCH | `/api/quality-events/:id/cerrar` | Inicia cierre (primer paso) | `{ resultadoCierre, plazoVerificacionDias }` | Setea campos sin cambiar `estado`; audit `CIERRE_INICIADO`; 422 si `estado !== PENDIENTE_CIERRE`; 404 |
| PATCH | `/api/quality-events/:id/firmar-cierre` | Firma dual de cierre (RN-QE-004 / QE-AC-006) | `{ rol, pin }` | 1ª firma (`JEFE_CALIDAD_SYST`): setea `cerradoPorId`, no cambia estado. 2ª firma (`SUPERVISOR`/`ALTA_DIRECCION`): setea `cierreFirmaSupervisorId/Rol`, `estado → CERRADO`, `fechaCierre`, calcula `fechaVerificacionProgramada = fechaCierre + plazoVerificacionDias`. 422 si orden de firma incorrecto o rol/estado inválido; 404 |
| PATCH | `/api/quality-events/:id/forzar-vencimiento-verificacion` | Dev-only, sin body — fuerza vencimiento de plazo de verificación | — | Desde `CERRADO`→`EN_VERIFICACION`; desde `EN_VERIFICACION`→`EN_INVESTIGACION` (incrementa `ciclo`, audit `REABIERTO` motivo `VENCIMIENTO_PLAZO`); 422 en otro estado; 404. **Nota: dev-only, probablemente no debe existir en producción real** |
| POST | `/api/quality-events/:id/verificacion-eficacia` | Registra resultado de verificación de eficacia | `{ resultado: 'EFECTIVO'|'NO_EFECTIVO', evidencia }` | `EFECTIVO` → `estado: VERIFICADO`. `NO_EFECTIVO` → incrementa `ciclo`, `estado: EN_INVESTIGACION`, audit `REABIERTO` motivo `NO_EFECTIVO`; 422 si `estado !== EN_VERIFICACION` o `evidencia` vacía; 404 |
| PATCH | `/api/quality-events/:id/editar-reporte-inicial` | Edita campos del reporte inicial dentro de ventana RN-QE-014 (2h) | Body validado — rechaza `numero`, `origen`, `tipo`, `fechaHoraReporte`, `reportadoPorId`, `severidad` | 422 si fuera de ventana, si actor no es creador/Supervisor del área, o si incluye campo protegido; un audit entry `QE_REPORTE_INICIAL_EDITADO` por campo cambiado; 404 |
| PATCH | `/api/quality-events/:id/editar-severidad` | Cambia severidad (solo `JEFE_CALIDAD_SYST`) | `{ severidad }` | 422 si rol incorrecto o `estado` en `CERRADO`/`EN_VERIFICACION`/`VERIFICADO`; si nueva severidad es `CRITICA` (o deja de serlo) devuelve flag `requiereNotificacionUrgente` (RN-QE-005/011); 404 |
| PATCH | `/api/quality-events/:id/editar-mineral` | Cambia mineral involucrado (solo `JEFE_CALIDAD_SYST`, solo `tipo` CALIDAD/OPERACIONAL) | `{ mineralInvolucrado }` | 422 si rol/estado/tipo inválido; 404 |
| POST | `/api/quality-events/:id/export-pdf` | Registra exportación PDF (llamado antes de generar el PDF, individual o batch) | — | Añade audit entry `EXPORTACION_PDF` (`realizadoPorId/Nombre`, `generadoPorIA: false`); retorna QE completo actualizado; 404 |

### Endpoints — Acciones correctivas del QE y ajuste de plazo

| Método | Path | Descripción | Body | Notas |
|---|---|---|---|---|
| GET | `/api/quality-events/:id/acciones-correctivas` | Lista ACs del QE | — | 404 si QE no existe |
| POST | `/api/quality-events/:id/acciones-correctivas` | Crea AC | body con `responsableId` | `responsableNombre` resuelto server-side; 404 |
| PATCH | `/api/quality-events/:id/acciones-correctivas/:acId` | Actualiza AC | — | 404 |
| PATCH | `/api/quality-events/:id/acciones-correctivas/:acId/status` | Cambia estado de AC | `{ estado, descripcionEvidencia? }` | 422 si `estado: 'CERRADA'` sin `descripcionEvidencia` |
| POST | `/api/quality-events/:id/acciones-correctivas/:acId/solicitud-plazo` | Solicita ajuste de plazo | `{ fechaSolicitada, justificacion }` | Solo el `responsableId` de la AC puede solicitar; 422 si AC `CERRADA`, si ya hay solicitud `PENDIENTE`, o si el plazo implícito es menor a `PLAZO_MINIMO_DIAS_HABILES[severidad]`; calcula `requiereAprobacionGerencia`; crea entrada `SolicitudAjustePlazoAC` (`estado: 'PENDIENTE'`); audit `AC_AJUSTE_PLAZO_SOLICITADO`; 201; 404 si QE/AC no existen |
| PATCH | `/api/quality-events/:id/acciones-correctivas/:acId/solicitud-plazo/:solicitudId` | Aprueba/rechaza solicitud de ajuste de plazo | `{ accion: 'APROBAR'|'RECHAZAR', comentarioRevision? }` | Requiere rol correcto según `requiereAprobacionGerencia` (`JEFE_CALIDAD_SYST` si false, `ALTA_DIRECCION` si true); `APROBAR` actualiza `ac.plazoFecha`, audit `AC_AJUSTE_PLAZO_APROBADO`; `RECHAZAR` requiere `comentarioRevision`, audit `AC_AJUSTE_PLAZO_RECHAZADO`; 404 si `:id`/`:acId`/`:solicitudId` no coinciden o la solicitud ya fue decidida; 422 en validaciones de rol/campo |

### Shape `QualityEvent` (campos confirmados)
`id, numero (QE-YYYY-NNN), origen (O1_INCIDENTE_CAMPO|O2_NC_DETECTADA|O3_HALLAZGO_AUDITORIA|O4_REPORTE_EXTERNO), tipo (CALIDAD|SST|ADUANERO|OPERACIONAL), severidad (BAJA|MEDIA|ALTA|CRITICA), estado (9 valores: ABIERTO|EN_INVESTIGACION|ANALISIS_COMPLETADO|EN_EJECUCION|PENDIENTE_CIERRE|CERRADO|EN_VERIFICACION|VERIFICADO|REABIERTO), areaAfectada, fechaHoraEvento, fechaHoraReporte, reportadoPorId, ciclo (int, incrementa en cada reapertura), causaRaizFirmadaEn?, resultadoCierre?, plazoVerificacionDias?, cerradoPorId?, cierreFirmaSupervisorId?, cierreFirmaSupervisorRol?, fechaCierre?, fechaVerificacionProgramada?, resultadoVerificacion? ('EFECTIVO'|'NO_EFECTIVO'), evidenciaVerificacion?, verificadoPorId?, fechaVerificacionRealizada?, auditorAsignadoId? (solo si EN_VERIFICACION+), solicitudesAC (int), hallazgoCodigo?/normativaVinculada? (solo origen O3), documentosVinculados?: string[], mineralInvolucrado? (solo CALIDAD/OPERACIONAL), accionesCorrectivas: AccionCorrectivaQE[], auditTrail: QEAuditTrailEntry[], empresaId`

`AccionCorrectivaQE` incluye `solicitudesAjustePlazo: SolicitudAjustePlazoAC[]` (⚠ ver flag — evolucionó de campo singular `solicitudAjustePlazo` a array plural; una spec de fixtures no fue actualizada).

`SolicitudAjustePlazoAC`: `id, fechaSolicitada, justificacion, estado (PENDIENTE|APROBADA|RECHAZADA), requiereAprobacionGerencia: boolean, revisadoPorId?, revisadoEn?, comentarioRevision?`

### Query keys / hooks (`src/features/quality-events/hooks/useQualityEvents.ts`)
- `QE_QUERY_KEYS.all = ['quality-events']`, `.list(filters)`, `.detail(id)`
- `useQualityEvents(filters)`, `useQualityEvent(id)` (enabled: Boolean(id))
- `useCreateQualityEvent()` (toast con `numero`), `useUpdateQualityEvent()`, `useTransitionQEStatus()` (toast.error con `message` del backend en errores de negocio — el backend DEBE devolver mensajes descriptivos tipo `RN-QE-XXX: ...` en `message`, el frontend los muestra tal cual)

### Reglas de negocio relevantes al contrato
- RN-QE-002/004: la transición a ciertos estados requiere causa raíz firmada / firma dual — el backend valida y devuelve 422 con `message` legible que el frontend re-expone directamente al usuario.
- RN-QE-005/011: severidad `CRITICA` dispara notificación a Alta Dirección (escalación); el backend calcula esto en `editar-severidad`, `cerrar`→`CERRADO`, y `VERIFICADO`+`EFECTIVO`.
- RN-QE-008: reapertura (`NO_EFECTIVO` o vencimiento forzado) notifica de forma escalada.
- RN-EMP-004: resolución de roles para notificaciones usa el rol *efectivo* del usuario en la empresa del QE (`getRolEfectivo(usuarioId, empresaId)`), no el rol "base" — importante porque un mismo usuario puede tener distinto rol en cada empresa.
- Plazos máximos por severidad (`PLAZO_MAXIMO_QE_DIAS_HABILES`): BAJA=22, MEDIA=17, ALTA=14, CRITICA=10 días hábiles — usado también por Dashboard (KPI-01) y por `solicitud-plazo` (plazo mínimo).

---

## 5. Dashboard

Fuente: `dashboard-msw-handlers`, `dashboard-query-hooks`, `dashboard-msw-fixtures`. Es un módulo de agregación de solo lectura sobre los otros 4 dominios — no tiene mutaciones propias.

### Endpoints

| Método | Path | Descripción | Query | Response `data` | Status |
|---|---|---|---|---|---|
| GET | `/api/dashboard/kpis` | 9 KPIs calculados sobre datos en vivo scoped a empresa activa | `periodo?` (`'YYYY-MM'`, default mes actual) | `KpiResult[]` (exactamente 9, uno por `KpiId`) | 200 siempre — sin datos retorna `valor: 0`, no error |
| GET | `/api/dashboard/summary` | Resumen dashboard, forma de respuesta depende del rol del usuario autenticado | — | `DashboardSummaryData` (shape varía por rol — ver abajo) | 401 sin token válido |

### Shape `KpiResult`
`{ kpiId, valor, meta, metaTipo ('ABSOLUTO'|'REDUCCION_INTERANUAL'), unidad, semaforo ('VERDE'|'AMARILLO'|'ROJO'|'INFORMATIVO'), periodo, valorPeriodoAnterior? (solo KPI-04), distribucion?: {area,valor}[] (solo KPI-09) }`

Reglas de semáforo (importante para el backend, ya que el cálculo debe replicarse exactamente):
- 7 KPIs "absolutos" estándar: VERDE si cumple meta, AMARILLO si está dentro de ±20% de desviación, ROJO en cualquier otro caso.
- KPI-01: plazo máximo por severidad (no fijo) — ver tabla arriba.
- KPI-04 (reducción interanual): VERDE si reducción ≥ meta(10%), AMARILLO si reducción entre 0 y 10%, ROJO si empeoró o si no hay `valorPeriodoAnterior`.
- KPI-05: solo cuenta ACs de origen `QE`/`NC` (excluye `INCIDENTE`) cerradas, numerador/denominador basado en `resultadoVerificacion` de la entidad padre.
- KPI-07: usa timestamp de `auditTrail` con `accion:'ESTADO_CAMBIADO', estadoNuevo:'ANALISIS_COMPLETADO'` (la más reciente), no `causaRaizFirmadaEn`. QE sin esa transición se excluye del promedio.
- KPI-08: no filtra por `periodo` (tiempo real, `periodo: 'TIEMPO_REAL'`), banda propia: 0→VERDE, 1-3→AMARILLO, >3→ROJO.
- KPI-09: retorna distribución por área (no un escalar), ordenada desc, `semaforo: 'INFORMATIVO'`.
- Todos los cálculos de días usan **días hábiles** (`contarDiasHabiles`), nunca diferencia de milisegundos/calendario.

### Shape `DashboardSummaryData` por rol (`rol` + `data`)
- `OPERARIO`: `misIncidentesReportados`, `misQEReportados` (filtrados por `reportadoPorId`), `documentosPendientesLectura` (filtrado por `areaId`)
- `SUPERVISOR`: todo filtrado por `areaIds` del usuario — incluye `qeAbiertosPorTipo`, `qesEnVerificacionArea`, `accionesCorrectivasPendientesArea`, `accionesCorrectivasVencidas` (solo `EN_EJECUCION` vencidas, no `PENDIENTE`)
- `JEFE_CALIDAD_SYST` → `rol: 'JEFE_CALIDAD'`: alcance organizacional completo (toda la empresa activa); incluye `tendenciaMensualVolumen` (12 meses, `abiertos`/`cerrados`) y `tendenciaMensualKpis` (KPI-01/04/05 × 12 meses)
- `JEFE_CONTROL_DOCUMENTARIO` → `rol: 'JEFE_CONTROL_DOC'`, `data: {}` (vacío — forma propia, no comparte `JefeCalidadDashboardData`)
- `ALTA_DIRECCION`: alcance organizacional completo; `resumenPorModulo`, `comparativaMensual` (KPI-01/04/05 sobre últimos 2 meses), `reaperturas`, `acsConSolicitudAjustePlazo`
- `AUDITOR_INTERNO`: `hallazgosPorArea`, `hallazgosPorEstado` (los 9 estados, sin claves ausentes), `evidenciasHallazgos` (con/sin `documentosVinculados`), `tasaCierreEnPlazoPorArea` (asc por tasa)

### Query keys / hooks
- `DASHBOARD_QUERY_KEYS.all = ['dashboard']`, `.kpis(periodo)`, `.summary()`
- `useDashboardKpis(periodo?)`, `useDashboardSummary()` (enabled: `Boolean(authStore.user)`)
- Cliente puro: `getDashboardKpis(periodo?)`, `getDashboardSummary()` en `src/features/dashboard/api/dashboard.api.ts`

### Reglas de negocio relevantes al contrato
- RN-EMP-004: todas las agregaciones deben acotarse por empresa activa antes de cualquier filtro por rol — ningún dato de otra empresa debe filtrarse a ningún rol, incluyendo `ALTA_DIRECCION`.
- Fixture auxiliar `horasTrabajadasFixtures` (`{area, periodo:'YYYY-MM', horas}`) es el denominador de KPI-04 — el backend real necesitará una fuente de datos equivalente (horas trabajadas por área/mes) que hoy no existe en ningún otro módulo de este contrato. **Flag de revisión**: no está claro qué sistema de origen alimentará esto en producción.

---

## 6. Gestión de Usuarios (M6)

Fuente: `user-management-api-hooks`, `user-management-msw`.

**⚠ predates empresaId** en su forma explícita — el usuario global (`MockUser`/`User`) es cross-empresa; la asociación usuario↔empresa↔rol vive en el módulo Empresas (`UsuarioEmpresa`), no aquí. Ver sección 7.

### Endpoints

| Método | Path | Descripción | Body / Params | Response `data` | Status |
|---|---|---|---|---|---|
| GET | `/api/users` | Lista usuarios | Query: `rol?`, `activo?` | `User[]` (incluye password en el mock — **NO exponer en producción real**, ver flag) | 200 |
| POST | `/api/users` | Crea usuario | datos de alta (email, nombre, rol, área...) | `{ ...User, temporaryPassword }` — password temporal alfanumérica de 8 chars generada server-side | 201; 409 si email duplicado |
| PATCH | `/api/users/:id` | Edita usuario | `email?`, `rol?`, `areaId?`, `areaIds?`, `avatarUrl?` (nunca `password`/`activo`) | `User` | 200; 409 si email duplicado (excluyendo el propio usuario) |
| PATCH | `/api/users/:id/toggle-active` | Activa/desactiva usuario | — | `User` (`activo` invertido) | 200 — siempre exitoso, sin condición de bloqueo (a diferencia de Locales/Áreas) |
| POST | `/api/users/:id/reset-password` | Resetea contraseña (admin) | — | `{ temporaryPassword }` (8 chars alfanuméricos) | 200 |

### Query keys / hooks (`src/features/users/hooks/useUsers.ts`)
- `QUERY_KEYS.users.all`, `.list(filters)`, `.detail(id)?`
- `useUsers(filters?)`, `useCreateUser()`, `useUpdateUser()`, `useToggleUserActive()`, `useResetUserPassword()` — todas invalidan `users.all`
- Cliente: `src/api/endpoints/users.api.ts` → `listUsers`, `createUser`, `updateUser`, `toggleUserActive`, `resetUserPassword`

### Reglas de negocio relevantes al contrato
- RN-USR-001/002/003: login rechaza usuarios inactivos con mensaje **distinto** de "credenciales inválidas" — importante para UX, el backend real debe distinguir estos dos casos de error.
- RN-USR-004/005/006: passwords temporales de 8 caracteres alfanuméricos en alta y en reset; nunca se persiste en texto plano fuera de la respuesta única de esa operación (para el backend real: hash inmediato, la respuesta de la API es la única vía de entrega del password en claro).
- Editar el rol de un usuario NO revalida ni invalida referencias históricas en otros dominios (p.ej. `responsableInvestigacionId` en un QE existente permanece apuntando al id aunque el rol cambie).
- Cada mutación de usuarios debe registrar `AuditTrailEntry` (`entidadTipo` de usuarios, `generadoPorIA: false`).

### ⚠ Flag de revisión — dos endpoints `GET /api/users` distintos
`nc-msw-handlers` especifica también un `GET /api/users` que retorna **exactamente 6 usuarios fixture, uno por rol** (`ApiResponse<User[]>`), mientras que `user-management-msw` especifica `GET /api/users` retornando **todos los usuarios del store, con filtros `rol`/`activo`, incluyendo password**. Ambas specs describen el mismo path pero con contratos incompatibles (conteo fijo de 6 vs. lista completa filtrable; con/sin exposición de `password`). Es muy probable que sean dos generaciones sucesivas del mismo endpoint (M2 temprano → M6), pero el backend debe implementar solo la versión de `user-management-msw` (más completa y posterior) y el equipo debe confirmar que ningún código de M2 sigue dependiendo de la forma "6 usuarios fijos".

---

## 7. Empresas / Multiempresa

Fuente: `empresa-admin-mocks`, `empresa-msw-fixtures`. Administración exclusiva de rol `SUPERADMIN`.

### Endpoints

| Método | Path | Descripción | Body | Response `data` | Status |
|---|---|---|---|---|---|
| GET | `/api/empresas` | Lista todas las empresas del sistema (sin scoping — SUPERADMIN no tiene empresa activa) | — | `Empresa[]` | 200; 401 sin sesión; 403 si rol ≠ `SUPERADMIN` |
| POST | `/api/empresas` | Crea empresa | `razonSocial`, `ruc` (único), `logoBase64?` (validado contra `empresaFormSchema`) | `Empresa` (`estado: 'ACTIVA'` por defecto, `id`, `fechaAlta`) | 201 |
| PATCH | `/api/empresas/:id` | Edita empresa; si `estado: 'INACTIVA'` dispara cascada | body parcial validado | `Empresa` | 200; 404. Cascada: si pasa de ACTIVA→INACTIVA, pone en `INACTIVO` **todas** las filas `UsuarioEmpresa` de esa empresa en la misma operación |
| GET | `/api/empresas/:id/usuarios` | Lista asignaciones `UsuarioEmpresa` de una empresa (activas e inactivas) enriquecidas con datos del `Usuario` | — | `UsuarioEmpresa[]` (+ nombre/apellido/email) | 200; 404 |
| POST | `/api/empresas/:id/usuarios` | Asigna un usuario existente a la empresa con un rol | `{ usuarioId, rol }` (validado contra `asignarUsuarioEmpresaSchema`) | `UsuarioEmpresa` | 201 (nueva fila) — si ya existía una fila inactiva para ese par usuario/empresa, la reactiva y actualiza `rol` en vez de duplicar; 404 si `usuarioId` no existe |
| PATCH | `/api/empresas/:id/usuarios/:usuarioId` | Activa/desactiva una asignación puntual | `{ estado: 'ACTIVO'|'INACTIVO' }` | `UsuarioEmpresa` | 200; 404 |

### Shape `Empresa`
`id, razonSocial, ruc, estado ('ACTIVA'|'INACTIVA'), logoUrl?, fechaAlta`

### Shape `UsuarioEmpresa`
`usuarioId, empresaId, rol (UserRole), estado ('ACTIVO'|'INACTIVO'), fechaAsignacion`

### Reglas de negocio relevantes al contrato
- Un usuario puede tener **filas distintas en distintas empresas con roles distintos** — el "rol" no es un atributo fijo del usuario, es un atributo de la relación `UsuarioEmpresa`. Esto es clave: el backend .NET debe modelar rol como parte de la relación usuario-empresa, no como columna en la tabla de usuarios.
- El "rol efectivo" (`getRolEfectivo(usuarioId, empresaId)`) de un usuario para una empresa dada se resuelve desde `UsuarioEmpresa`, y es lo que se usa para scoping de notificaciones y dashboards — no el rol "base" que pudiera existir en otro contexto.
- Desactivar una empresa (`PATCH /:id` con `estado:'INACTIVA'`) debe ser **transaccional**: la cascada a `UsuarioEmpresa` ocurre en la misma operación, antes de responder.

---

## 8. Locales

Fuente: `location-admin-api` (CRUD admin), `location-admin-mocks` (handlers), más el sub-recurso de solo lectura en `incident-msw-handlers`/`incident-tanstack-hooks` (sección Incidentes arriba: `GET /api/locales`, `GET /api/locales/:localId/zonas`).

**Dos clientes Axios separados y deliberadamente desacoplados**: `src/api/endpoints/locales.api.ts` (M3, solo lectura) vs `src/features/locations/api/locales.api.ts` (M6, admin CRUD) — mismo backend, distinto cliente frontend. El backend expone un único conjunto de endpoints REST; la separación es solo del lado del cliente.

Store scoped por `empresaId`.

### Endpoints — administración de Locales

| Método | Path | Descripción | Body | Response `data` | Status |
|---|---|---|---|---|---|
| POST | `/api/locales` | Crea local | JSON o `multipart/form-data` si incluye `planoUrl: File` | `Local` (id, `codigo` correlativo por empresa, `activo:true`) | 201; 400 si excede RN-LOC-001 (máx. 5 activos **por empresa**) o si el PNG es inválido (no `image/png` o >2MB); 401 sin empresa activa |
| GET | `/api/locales` | Lista locales de la empresa activa | Query: `activo?` | `Local[]` | 200 |
| GET | `/api/locales/:id` | Detalle con zonas embebidas | — | `Local` + `zonas` | 404 si no existe/otra empresa |
| PATCH | `/api/locales/:id` | Edita campos (nunca `empresaId`) | parcial, o multipart si incluye plano nuevo | `Local` | 200; 404 |
| PATCH | `/api/locales/:id/desactivar` | Desactiva (valida RN-LOC-002) | — | `Local` (`activo:false`) | 200; 409 si tiene incidentes `ABIERTO`/`EN_INVESTIGACION` bloqueantes (mensaje incluye conteo); 404 |
| PATCH | `/api/locales/:id/reactivar` | Reactiva (revalida RN-LOC-001) | — | `Local` (`activo:true`) | 200; 400 si ya hay 5 activos en la empresa; 404 |

### Endpoints — administración de Zonas

| Método | Path | Descripción | Body | Response `data` | Status |
|---|---|---|---|---|---|
| POST | `/api/locales/:id/zonas` | Crea zona (sin límite de cantidad, RN-ZON-003) | `ZonaFormInput` | `Zona` (`empresaId` heredado del local, `codigo` correlativo por empresa) | 201; 404 si local no existe/otra empresa |
| PATCH | `/api/zonas/:id` | Edita zona | parcial | `Zona` | 200; 404 |
| PATCH | `/api/zonas/:id/desactivar` | Desactiva (valida RN-ZON-002) | — | `Zona` (`activo:false`) | 200; 409 si tiene incidentes `ABIERTO`/`EN_INVESTIGACION`/`EN_EJECUCION` bloqueantes; 404 |
| PATCH | `/api/zonas/:id/reactivar` | Reactiva (sin restricción de cupo) | — | `Zona` (`activo:true`) | 200; 404 |

Nota: `GET /api/zonas` (listado plano, sin `:localId`) se menciona implícitamente en `location-admin-mocks` (filtrado por empresa) pero su contrato completo de query params no está detallado — **flag de revisión menor**.

### Reglas de negocio relevantes al contrato
- RN-LOC-001: máximo 5 locales activos — **por empresa**, no global. Aplica tanto a creación como a reactivación.
- RN-LOC-002/RN-ZON-002: no se puede desactivar un local/zona con incidentes bloqueantes en estado no-terminal, evaluado en vivo (no solo contra fixtures estáticos) y filtrado por `empresaId` del local/zona.
- RN-LOC-003: plano PNG ≤2MB, MIME `image/png` exacto.
- RN-ZON-003: sin límite de cantidad de zonas por local.

---

## 9. Áreas

Fuente: `area-admin-api`, `area-admin-mocks`. Sin cliente de solo lectura previo (a diferencia de Locales) — un solo cliente Axios cubre todo.

**⚠ predates empresaId explícito en su propia spec** — las specs de Área no mencionan scoping por `empresaId`; los fixtures de Incidentes indican que "Área remains a shared, company-agnostic catalog in this phase" (ver `incident-msw-fixtures`). **Área es, según la evidencia disponible, un catálogo compartido entre empresas en esta fase**, a diferencia de Locales/Zonas que sí son por-empresa. El backend debe confirmar esto explícitamente con el equipo — es una asimetría de diseño real, no un descuido de la spec.

### Endpoints

| Método | Path | Descripción | Body | Response `data` | Status |
|---|---|---|---|---|---|
| GET | `/api/areas` | Lista todas las áreas (activas e inactivas) | — | `Area[]` | 200 |
| GET | `/api/areas/:id` (implícito por `obtenerArea`) | Detalle | — | `Area` | — (no detallado explícitamente) |
| POST | `/api/areas` | Crea área (sin límite de cantidad, RN-ARE-002) | `AreaFormInput` (`nombre`, `descripcion`) | `Area` (`activo:true`) | 201; 409 si `nombre` duplicado (case-insensitive) |
| PATCH | `/api/areas/:id` | Edita área | parcial (`nombre`, `descripcion`) | `Area` | 200; 404; 409 si nuevo `nombre` colisiona con otra área |
| PATCH | `/api/areas/:id/desactivar` | Desactiva (valida cross-dominio) | — | `Area` (`activo:false`) | 200; 409 con body `{ conteo: { qe, nc, incidentes, total } }` si tiene referencias bloqueantes en QE/NC/Incidentes no-terminales |
| PATCH | `/api/areas/:id/reactivar` | Reactiva sin restricción de cupo | — | `Area` (`activo:true`) | 200 |

### Shape `Area`
`id, nombre, descripcion, activo` — 19 áreas semilla fijas (`AREAS_SHAC`), ids determinísticos `area-001`..`area-019`.

### Reglas de negocio relevantes al contrato
- RN-ARE-001: desactivación bloqueada si hay QE, NC o Incidentes en estado no-terminal referenciando el área — el 409 devuelve el desglose completo por módulo (`conteo`), no solo un mensaje de texto agregado.
- RN-ARE-002: sin límite de cantidad de áreas.
- RN-ARE-004: unicidad de `nombre` case-insensitive.

---

## 10. Notificaciones

Fuente: `notification-api-client`, `notification-msw-handlers`, `notification-query-hooks`, `notification-msw-fixtures`.

Store scoped por `empresaId` **y** por `usuarioId` simultáneamente (una notificación pertenece a un usuario dentro de una empresa concreta — un usuario multi-empresa puede tener notificaciones separadas por cada empresa a la que pertenece).

### Endpoints

| Método | Path | Descripción | Body | Response `data` | Status |
|---|---|---|---|---|---|
| GET | `/api/notifications` | Lista notificaciones del usuario autenticado en su empresa activa, ordenadas por `createdAt` desc | — | `Notificacion[]` (nota: el cliente devuelve la lista **desenvuelta**, no `ApiResponse` explícito en la firma del hook — ver Flags) | 200 |
| PATCH | `/api/notifications/:id/leida` | Marca una notificación como leída | — | `Notificacion` (`leida:true`) | 200; 404 |
| PATCH | `/api/notifications/marcar-todas-leidas` | Marca todas las notificaciones del usuario (en su empresa activa) como leídas | — | `Notificacion[]` | 200 |

### Shape `Notificacion`
`id, usuarioId, empresaId, tipo (incl. ASIGNACION, CAMBIO_ESTADO, VENCIMIENTO, ...), leida: boolean, createdAt, ...payload específico del tipo`

### Query keys / hooks
- `QUERY_KEYS.notifications.all = ['notifications']`
- `useNotifications()`, `useMarkNotificationRead()`, `useMarkAllNotificationsRead()` — mutaciones invalidan `notifications.all`

### Reglas de negocio relevantes al contrato
- `GET /api/notifications` en el mock dispara, antes de leer, un "paso de generación de vencimientos" idempotente que crea notificaciones `VENCIMIENTO` para ACs/documentos/incidentes recién vencidos. **Esto es puramente un artefacto de simulación MSW** (no hay cron real en el mock) — el backend real necesita un **job/worker programado** que genere estas notificaciones de forma asíncrona, no acoplado al momento en que el usuario abre su bandeja. Este es un cambio de arquitectura real, no solo de implementación — flag de revisión importante.
- Las notificaciones se generan también inline desde otros módulos (asignación de documento, cambio de estado de incidente/NC/QE) — ver reglas de negocio de cada módulo arriba (`createAsignacionNotification`, `createCambioEstadoNotification`).

---

## 11. Auth

Fuente: `auth-flow`.

**Módulo base — no está scoped por `empresaId` en el sentido de filtrado de datos, sino que ES el módulo que resuelve la empresa activa de la sesión.**

### Endpoints

| Método | Path | Descripción | Body | Response `data` | Status |
|---|---|---|---|---|---|
| POST | `/auth/login` | Login con email/password | `{ email, password, empresaId? }` | Caso mono-empresa: `{ accessToken, user, empresaActivaId, empresasDisponibles }`. Caso multi-empresa sin `empresaId` en el body: `{ requiresEmpresaSelection: true, empresasDisponibles }` (sin `accessToken`/`user`) | 200; 401 con `{success:false, message:'Credenciales inválidas'}` |
| POST | `/auth/logout` | Cierra sesión | — | — | — (contrato no detallado más allá de existir) |
| POST | `/auth/refresh` | Refresca token, restaura rol efectivo de la empresa activa persistida | refresh token (mecanismo no detallado — cookie o header) | `{ accessToken, user (con rol efectivo correcto), empresaActivaId }` | — |
| POST | `/auth/switch-empresa` | Cambia la empresa activa de la sesión sin re-login | `{ empresaId }` + Bearer token | `{ accessToken, user, empresaActivaId, empresasDisponibles }` (sesión completa nueva) | Error (status no especificado) si `empresaId` no tiene fila `UsuarioEmpresa` activa para el usuario — sesión no se modifica |
| POST | `/auth/forgot-password` | Solicita reset de password | `{ email }` | — | Siempre 200 (no revela si el email existe) |
| POST | `/auth/reset-password` | Confirma reset con token | `{ token, password }` | — | 200 si token válido; 400 `{success:false, message:'Token inválido o expirado'}` si no |

### Reglas de negocio relevantes al contrato
- Un usuario con más de una empresa asignada NO completa el login en la primera llamada — el flujo es: (1) `POST /auth/login` sin `empresaId` → `requiresEmpresaSelection`; (2) frontend muestra selector; (3) segunda llamada a `/auth/login` (u otro endpoint — no especificado con precisión, ver flag) con `empresaId` elegido completa el login.
- El "rol efectivo" del usuario varía por empresa (viene de `UsuarioEmpresa`, no es un campo fijo del usuario) — login, refresh y switch-empresa deben recalcularlo cada vez.
- Ruta de destino post-login: `/admin/locales` si rol efectivo es `ADMINISTRADOR_SISTEMA`, `/documentos` para el resto — lógica de frontend (`getDefaultRouteForRole`), no del backend, pero el backend debe devolver el rol efectivo correcto para que esta lógica funcione.
- `MockUser` (equivalente real: tabla `Usuario`) incluye `createdAt` (fecha de alta, fijo) y `lastLogin` (actualizado en cada login exitoso) — confirmar que el backend real actualiza `lastLogin` de forma transaccional en el propio endpoint de login.
- Usuario inactivo (`activo:false`) recibe un mensaje de error **distinto** de credenciales inválidas al intentar login (ver también sección Gestión de Usuarios).

---

## Flags de revisión (resumen para el equipo de backend)

1. ~~**Documentos** — sub-endpoints sin contrato~~ — **RESUELTO 2026-08-13**. Los ~14 sub-endpoints (`/status` PATCH, `/sign`, `/archivo`, `/nueva-version`, `/exportar-pdf`, `/download-url`, `/confirmar-revision`, `/restaurar`, `/audit/access`, `/archivo-original` GET+POST, `/archivo-distribucion`, `/publicar`, `/upload`) fueron reconstruidos leyendo el código fuente directamente (handler MSW, hooks, wrapper Axios, componentes, permisos) — ver sección 1.2 arriba, con la traducción completa del patrón blob simulado a almacenamiento en disco local (sección 1.3). Quedan 5 puntos que ya no son de información sino de decisión de producto — ver sección 1.7.
2. **Incidentes — shape de la lista**: `incident-msw-handlers` describe la respuesta de `GET /api/incidents` como `data.items` + `data.pagination` (anidado un nivel más que otros módulos, que ponen el array directo en `data` y `pagination` como hermano de `data`). Confirmar si esto es intencional o una inconsistencia entre specs — todos los demás módulos de lista (`documents`, `nonconformities`, `quality-events`) usan `{ data: T[], pagination }` plano.
3. **`GET /api/users` — dos contratos incompatibles** entre `nc-msw-handlers` (6 usuarios fijos, uno por rol) y `user-management-msw` (lista completa filtrable, con password). Implementar solo la versión de `user-management-msw`; confirmar que nada depende de la versión de 6 usuarios fijos.
4. **Notificaciones — generación de vencimientos**: en el mock, se dispara de forma síncrona dentro de `GET /api/notifications`. El backend real necesita esto como job asíncrono/programado, no como side-effect de una lectura — es una diferencia de arquitectura, no solo de implementación.
5. **QE — `solicitudAjustePlazo` singular vs. `solicitudesAjustePlazo` plural**: `quality-event-msw-fixtures` contiene un requisito viejo (con nota de staleness explícita en el propio archivo) que describe el campo singular ya reemplazado por el array plural. El campo correcto y vigente es `solicitudesAjustePlazo: SolicitudAjustePlazoAC[]`.
6. **Áreas — ¿catálogo compartido entre empresas o scoped?**: a diferencia de Locales/Zonas/Documentos/Incidentes/NC/QE, las specs de Área (`area-admin-api`, `area-admin-mocks`) no mencionan `empresaId` en absoluto. Una nota lateral en `incident-msw-fixtures` confirma que "Área remains a shared, company-agnostic catalog in this phase" — pero esto no está declarado como regla de negocio formal en la propia spec de Área. Confirmar con el equipo antes de decidir si `Area` es una tabla global o por-empresa en el esquema .NET.
7. **Dashboard — `horasTrabajadasFixtures`**: KPI-04 depende de un dato (horas trabajadas por área/mes) que no tiene módulo de origen propio en ninguna otra spec leída — es puramente un fixture. El backend real necesita definir de dónde viene este dato (¿integración con RR.HH.? ¿carga manual?) — no cubierto por ninguna spec.
8. **Auth — segunda llamada de selección de empresa**: el flujo de selección de empresa en login describe la UI y el primer `POST /auth/login` (que devuelve `requiresEmpresaSelection`), pero no especifica explícitamente si la confirmación de empresa reutiliza `POST /auth/login` con `empresaId` añadido o usa un endpoint distinto. Asumido aquí que es el mismo endpoint con `empresaId` en el body (consistente con la firma general), pero debe confirmarse.
9. **`/auth/logout` y `/auth/switch-empresa` (caso error)**: no se especifica el código de status HTTP exacto para el logout ni para el rechazo de `switch-empresa` a una empresa no asignada ("responde con status de error" sin precisar cuál — probablemente 403, a confirmar).
10. **Locales — `GET /api/zonas` sin `:localId`**: mencionado como filtrado por empresa en `location-admin-mocks` pero sin requirement propio detallando sus query params — a diferencia de `GET /api/locales/:localId/zonas`, que sí está bien especificado en `incident-msw-handlers`.
11. **`incident-msw-handlers` menciona `PATCH /api/incidents/:incidenteId/acciones/:acId/cerrar`** en la lista de aislamiento por empresa, pero no existe requirement propio para ese endpoint — posible endpoint de una fase posterior no cubierta por las specs leídas.
