# SHAC — Decisiones de Arquitectura Backend .NET

> Generado 2026-08-13 por Cowork, a partir de las decisiones de arquitectura confirmadas por Toño. Complementa a `SHAC-Contrato-API-Backend-NET-2026-08-13.md` (el contrato de endpoints extraído de los specs MSW) — este documento define **cómo** se construye el backend, el otro define **qué** debe exponer.

## Decisiones confirmadas

1. **Vertical Slice Architecture con Minimal APIs** — no Controllers, no capas horizontales (Repository/Service/Controller) transversales a todo el proyecto. Cada caso de uso (un endpoint) es una "slice" autocontenida: su propio request, su propio handler, su propio mapeo a Minimal API.
2. **CQRS parcial**: **Dapper** para todas las acciones de lectura (`GET`), **EF Core** para todas las acciones de escritura (`POST`/`PUT`/`PATCH`/`DELETE`).
3. **ASP.NET Core Identity** para gestión de usuarios (reemplaza el `MockUser`/tabla `Usuario` casera del mock).
4. **PostgreSQL en Docker** como base de datos.

## 1. Estructura de solución — Vertical Slice

Un slice por caso de uso, agrupado por módulo (los mismos 11 módulos del contrato de API). Convención sugerida, calcada de la nomenclatura ya usada en el frontend (`src/features/[modulo]/...`) para que el mapeo mental sea directo:

```
src/
  Shac.Api/                          ← host: Program.cs, Minimal API endpoint mapping, middleware, DI
    Features/
      Documentos/
        ListarDocumentos/
          ListarDocumentosQuery.cs       ← record, params de filtro/paginación
          ListarDocumentosHandler.cs     ← usa Dapper, IDbConnection
          ListarDocumentosEndpoint.cs    ← MapGet, valida, llama handler, envuelve en ApiResponse<T>
        ObtenerDocumento/
          ...
        CrearDocumento/
          CrearDocumentoCommand.cs       ← record
          CrearDocumentoValidator.cs     ← FluentValidation
          CrearDocumentoHandler.cs       ← usa EF Core, ShacDbContext
          CrearDocumentoEndpoint.cs      ← MapPost
        CambiarEstadoDocumento/
          ...
        ActualizarDocumento/
        EliminarDocumento/
      Incidentes/
        ListarIncidentes/
        ObtenerIncidente/
        CrearIncidente/
        ...
      NoConformidades/
      QualityEvents/
      Dashboard/
      Usuarios/                          ← delgado: envuelve UserManager<ShacUser>/RoleManager (ver sección 3)
      Empresas/
      Locales/
      Areas/
      Notificaciones/
      Auth/                              ← login/refresh/switch-empresa, integrado con Identity (ver sección 3)
    Shared/
      ApiResponse.cs                     ← el wrapper { data, success, message, errors, pagination }
      EmpresaScopeMiddleware.cs          ← o filter: resuelve empresaActivaId del JWT, lo inyecta en el contexto de request
      Endpoints/
        IEndpoint.cs                     ← interfaz mínima: MapEndpoint(IEndpointRouteBuilder)
    Program.cs                           ← escanea/registra todos los IEndpoint vía reflection o extension methods explícitos por módulo
  Shac.Domain/                       ← entidades EF Core (agregados), enums (DocStatus, UserRole, etc.), sin dependencias de infraestructura
  Shac.Infrastructure/
    Persistence/
      ShacDbContext.cs                   ← EF Core, usado SOLO por los Commands (writes)
      Migrations/
      DapperConnectionFactory.cs         ← IDbConnection factory (Npgsql), usado SOLO por las Queries (reads)
    Identity/
      ShacUser.cs                        ← IdentityUser<Guid> + campos extra (nombre, apellido, area, activo)
      ShacDbContext (o contexto separado) hereda IdentityDbContext<ShacUser, IdentityRole<Guid>, Guid>
  Shac.Tests/
    Features/[modulo]/...                ← un test de integración por endpoint como mínimo (WebApplicationFactory + Testcontainers Postgres)
```

**Por qué un endpoint por carpeta y no un `DocumentsController` con 6 acciones:** es el punto central de Vertical Slice — el costo de tocar un endpoint queda contenido a una carpeta, no obliga a tocar un archivo compartido por los 6. Facilita también que Claude Code reciba instrucciones grounded ("edita `Features/Documentos/CambiarEstadoDocumento/CambiarEstadoDocumentoHandler.cs`") sin ambigüedad.

**Nota sobre MediatR:** Vertical Slice no exige MediatR — se puede llamar al handler directamente desde el endpoint sin pipeline de mediador. Dado que el contrato no tiene requisitos de cross-cutting concerns complejos por ahora (más allá de logging/validación/auth, que se resuelven con filtros de Minimal API), la recomendación es **empezar sin MediatR** y añadirlo solo si aparece necesidad real de pipeline behaviors (ej. transacciones automáticas, logging uniforme). Confirmar esta preferencia con Toño antes de que Claude Code escanfolde — es la única decisión de esta sección que no vino explícita en el mensaje original.

## 2. CQRS: Dapper (reads) vs EF Core (writes)

Regla operativa, módulo por módulo, tal como está reflejada en el contrato de API:

| Verbo HTTP | Tecnología | Devuelve |
|---|---|---|
| `GET` (lista, detalle) | Dapper, SQL explícito | DTOs planos que ya calzan con el shape `data` de `ApiResponse<T>` — sin pasar por entidades de dominio |
| `POST` / `PUT` / `PATCH` / `DELETE` | EF Core, `ShacDbContext`, entidades de `Shac.Domain` | La entidad actualizada (mapeada a DTO de respuesta) |

Implicaciones a decidir antes de escanfolder:

- **Dos formas de acceso a los mismos datos** (Dapper para leer, EF Core para escribir) significan que el modelo relacional (nombres de tabla/columna) debe fijarse una sola vez y ambas capas apuntan al mismo esquema — no hay generación de esquema "desde Dapper", las migraciones EF Core son la única fuente de verdad del esquema físico.
- Los DTOs de lectura (Dapper) deben calzar exactamente con los shapes documentados en el contrato de API (ej. `Documento` con sus campos, `pagination`) — conviene generarlos una vez a partir del contrato y no dejarlos derivar del modelo EF Core, para evitar acoplar el shape de respuesta a la forma interna de las tablas.
- **Paginación y filtros** (`page`, `pageSize`, `search`, `estado`, etc., documentados por módulo en el contrato) se construyen a mano en SQL con Dapper — no hay LINQ que lo resuelva. Cada `ListarXQuery` handler necesita su propio SQL con `WHERE` dinámico (parametrizado, nunca concatenado, para evitar SQL injection) y un `COUNT(*)` aparte para `pagination.totalItems`.
- El **scoping por `empresaId`** (obligatorio en casi todos los módulos, según el contrato) debe aplicarse tanto en el SQL de Dapper como en los queries de EF Core — es el punto más fácil de olvidar en un módulo nuevo. Recomendación: un filtro/interceptor central que inyecte `WHERE empresa_id = @empresaActivaId` no es trivial con Dapper (SQL explícito), así que la disciplina real es: cada `ListarXQuery`/`ObtenerXQuery` handler recibe `empresaActivaId` como parámetro obligatorio (nunca opcional) desde el endpoint, y cada `INSERT`/`UPDATE` en EF Core fija `EmpresaId` desde ese mismo valor, nunca desde el body del cliente — tal como ya especifica el contrato para el mock.

## 3. ASP.NET Core Identity — gestión de usuarios y auth

Puntos de fricción reales entre lo que pide el contrato de API (extraído del mock) y lo que Identity da por defecto — hay que resolver esto explícitamente, no asumir que "usar Identity" cierra el tema:

- **El mock expone `POST /auth/login`, `/auth/refresh`, `/auth/switch-empresa`, `/auth/logout`, `/auth/forgot-password`, `/auth/reset-password` con el envelope `ApiResponse<T>` y un flujo de selección de empresa multi-tenant** (ver contrato, módulo Auth). Identity trae sus propios endpoints (`MapIdentityApi<TUser>()`) pero con un contrato de respuesta distinto y sin noción de empresa activa. **Recomendación: usar Identity como el motor de usuarios (hashing de password, lockout, roles) pero NO montar `MapIdentityApi` — escribir los 6 endpoints de Auth como slices propios que usan `UserManager<ShacUser>`/`SignInManager<ShacUser>` internamente** y emiten el JWT + el envelope `ApiResponse<T>` a mano, para no romper el contrato ya consumido por el frontend.
- **Refresh token**: `CLAUDE.md` es explícito — el backend real **debe** usar una cookie `httpOnly` verdadera para el refresh token (el mock usaba `localStorage` solo como parche temporal por la limitación de MSW con cookies). Identity no gestiona refresh tokens JWT por defecto (su cookie es de sesión, no de JWT bearer) — esto es lógica a implementar aparte: tabla de refresh tokens (o Identity `UserTokens` reutilizado), emisión de cookie `httpOnly` + `Secure` + `SameSite`, rotación en cada refresh.
- **Roles**: el contrato y `CLAUDE.md` documentan 7 roles originales (`OPERARIO`, `SUPERVISOR`, `JEFE_CALIDAD_SYST`, `JEFE_CONTROL_DOCUMENTARIO`, `AUDITOR_INTERNO`, `ALTA_DIRECCION`, `ADMINISTRADOR_SISTEMA`) más 2 agregados en la fase Multiempresa (`ADMINISTRADOR_EMPRESA`, `SUPERADMIN`, según el resumen de sesión previa). Estos calzan de forma natural con `IdentityRole<Guid>` — pero el **rol efectivo del usuario varía por empresa** (viene de la fila `UsuarioEmpresa`, no es un campo fijo del usuario). Identity's `UserManager.GetRolesAsync` asume roles globales por usuario, no por-tenant. **Esto requiere una tabla propia `UsuarioEmpresa` (fuera del modelo estándar de Identity) que registre `(usuarioId, empresaId, rol, activo)`, y el JWT debe llevar el rol efectivo de la empresa activa de la sesión, no los roles globales de Identity.** Los roles de Identity (`AspNetRoles`/`AspNetUserRoles`) pueden quedar sin usar, o usarse solo para una distinción binaria de sistema (ej. `SUPERADMIN` global vs. no) — a decidir.
- **`ShacUser : IdentityUser<Guid>`** necesita los campos extra del contrato: `nombre`, `apellido`, `area` (home area), `areasAsignadas` (solo Supervisor), `activo`, `createdAt` (ya lo da Identity indirectamente), `lastLogin`.
- **Reset de contraseña por administrador** (mecanismo funcional actual descrito en `CLAUDE.md`, ya que el envío de email real es parte de este mismo esfuerzo de backend): Identity trae `GeneratePasswordResetTokenAsync`/`ResetPasswordAsync`, que cubre bien tanto el flujo self-service (`/auth/forgot-password` + `/auth/reset-password`, una vez que exista envío de email real) como el flujo de admin (generar password temporal). Este es probablemente el único punto donde Identity encaja sin fricción con el contrato tal cual está.

## 4. PostgreSQL en Docker

No hay decisión adicional que tomar aquí más allá de lo estándar — un `docker-compose.yml` con el servicio `postgres`, volumen nombrado para persistencia, healthcheck, y variables de entorno para usuario/password/db, más un `appsettings.Development.json`/`.env` con la cadena de conexión que usan tanto `ShacDbContext` (EF Core) como `DapperConnectionFactory` (Npgsql). Migraciones EF Core (`dotnet ef database update`) son la única vía de creación/evolución de esquema; Dapper nunca crea tablas.

Punto a decidir con Toño: si el docker-compose vive en el mismo repo `shc-controldoc` (monorepo frontend+backend) o en un repo/carpeta separada — afecta cómo Claude Code arma la estructura de carpetas raíz.

## Decisiones sobre las preguntas abiertas (confirmadas por Toño, 2026-08-13)

1. **MediatR: no.** Los endpoints llaman al handler directamente desde el Minimal API, sin pipeline de mediador.
2. **Repo backend: nuevo**, separado de `ShcMvp`/`shc-controldoc` (no monorepo). Falta definir nombre y ubicación exacta en disco cuando se arranque el scaffolding.
3. **RBAC vive enteramente en la tabla `UsuarioEmpresa` custom.** Los roles de Identity (`AspNetRoles`/`AspNetUserRoles`) **no se usan** para el RBAC de negocio — quedan fuera del diseño o se reservan exclusivamente para necesidades internas de Identity, nunca como fuente del rol efectivo por empresa. Todo permiso/guard se resuelve contra `UsuarioEmpresa (usuarioId, empresaId, rol, activo)`.
4. **Documentos — reconstruir el contrato primero.** Antes de escanfoldar el módulo de Documentos, se reconstruye el contrato exacto de los ~10 sub-endpoints sin spec (`/sign`, `/upload`, `/nueva-version`, `/exportar-pdf`, `/download-url`, `/confirmar-revision`, `/restaurar`, `/audit/access`, `/archivo-original` (GET/POST), `/archivo-distribucion`, `/publicar`) leyendo el código fuente real del frontend (cliente Axios, handlers MSW, componentes que los invocan) — no se escanfolda ese módulo con el contrato incompleto. Ver documento separado una vez reconstruido.
5. **Almacenamiento de archivos: disco local del contenedor para el MVP** (no S3/Azure Blob todavía). Implica: un volumen Docker montado para persistencia de archivos subidos (documentos, adjuntos), y los endpoints de descarga devuelven una ruta/URL servida por el propio backend (no signed URLs de un proveedor cloud) — a diferenciar del lenguaje genérico de "signed URLs" usado en el contrato de API original, que ahí se refería solo a "no repliques el patrón blob simulado de MSW", no a un proveedor cloud específico.

---

*Complementa: `SHAC-Contrato-API-Backend-NET-2026-08-13.md` (contrato de endpoints). Ambos documentos en el proyecto AppCoDoc.*
