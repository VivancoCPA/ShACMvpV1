# Resumen de sesión — Scaffolding inicial (2026-08-14)

> Generado por Claude Code al terminar `INSTRUCCIONES-CLAUDE-CODE-scaffolding-inicial.md`. Léase antes de arrancar el siguiente módulo — documenta qué existe, qué compila, qué corre, y las decisiones tomadas que no estaban explícitas en el contrato/arquitectura.

## Estado: todo lo pedido en Pasos 1–5 está hecho y verificado

- **Git**: `ShcMvpEndPoint` es un repo independiente (`git init` hecho). `ShcMvp/.gitignore` (repo padre) excluye `ShcMvpEndPoint/` — confirmado con `git status` en ambos repos. **Nada se commiteó todavía** (política: solo commitear si el usuario lo pide explícitamente) — hay 18 entradas untracked listas para el primer commit.
- **Solución**: 4 proyectos (`ShcMvpEndPoint`, `.Domain`, `.Infrastructure`, `.Tests`), todos en `ShcMvpEndPoint.slnx`, referencias correctas. `ShcMvpEndPoint.csproj` excluye explícitamente `ShcMvpEndPoint.*/**` de su glob de compilación (los proyectos hermanos viven como subcarpetas del mismo directorio que el `.csproj` del host — sin ese exclude, el host recompila también los `.cs` de Domain/Infrastructure/Tests).
- **Paquetes**: todos instalados y resueltos a versiones `net10.0`-compatibles (EF Core/Identity/JwtBearer 10.0.11, Npgsql 10.0.3, FluentValidation 12.1.1, Swashbuckle.AspNetCore 10.2.3, Testcontainers.PostgreSql 4.14.0). `Microsoft.EntityFrameworkCore.Design` está en **ambos** `ShcMvpEndPoint.csproj` e `.Infrastructure.csproj` — las EF Core Tools lo exigen en el *startup project*, no solo donde vive el DbContext.
- **Docker**: `docker-compose.yml` con un único servicio `postgres:16`. **Puerto 5435, no 5432** — 5432 ya lo usa otro proyecto (`postgres_db`) en esta máquina; ver `.env`/`.env.example`. Contenedor `shac-postgres` corriendo y `healthy` al cierre de la sesión.
- **Secretos**: `appsettings.Development.json` y `.env` tienen credenciales dev reales y están gitignored; `.example` de ambos están commiteables.

## Compila y corre — verificado en esta sesión

- `dotnet build` en la solución completa: **0 errores, 0 advertencias**.
- `dotnet ef migrations add InitialCreate` + `dotnet ef database update`: aplicada contra Postgres real (puerto 5435). Tablas creadas: `asp_net_*` (Identity), `empresas`, `usuarios_empresa`, `refresh_tokens`, `__EFMigrationsHistory` — todas en snake_case (convención propia vía `SnakeCaseModelBuilderExtensions`, no un paquete de terceros).
- `dotnet run` (con `ASPNETCORE_ENVIRONMENT=Development`) arranca sin errores de DI. Probado manualmente:
  - `GET /swagger/v1/swagger.json` → 200.
  - `POST /api/empresas` sin token → 401 (RBAC por rol vía JWT funcionando).
  - `POST /api/auth/login` con credenciales inexistentes → 401 con el envelope `ApiResponse<T>` exacto (`{data:null, success:false, message:"Credenciales inválidas", ...}`).
- `dotnet test`: **2/2 tests pasan**, usando `WebApplicationFactory<Program>` + `Testcontainers.PostgreSql` real (contenedor efímero, migraciones aplicadas en `InitializeAsync`). Cobertura actual: solo 2 tests de humo (Login 401, CrearEmpresa 401 sin auth) — **falta el resto de los 13 endpoints**, ver pendientes abajo.

## Módulo de referencia 1 — Auth (`Features/Auth/`)

**7 endpoints implementados, no 6** — se descubrió `POST /api/auth/change-password` leyendo `shc-controldoc/src/features/auth/api/auth.api.ts` y `mocks/handlers/auth.handlers.ts` directamente (el contrato resumido no lo listaba). Todos como slices propios sobre `UserManager<ShacUser>`/`SignInManager`, sin `MapIdentityApi`.

| Endpoint | Notas |
|---|---|
| `POST /api/auth/login` | Replica `resolveSession()` del mock carácter por carácter (`SessionResolver` en Infrastructure). Maneja `esSuperadminMultiempresa`, multiempresa con selección pendiente, y los códigos de estado exactos del handler real (**403**, no 401, para "usuario deshabilitado" y "empresa no asignada" — el contrato resumido solo documentaba el 401 de credenciales inválidas). |
| `POST /api/auth/refresh` | Lee el refresh token de una cookie `httpOnly` (no header/localStorage como el mock). Rota el token en cada refresh. |
| `POST /api/auth/switch-empresa` | No rota el refresh token (igual que el mock) — solo actualiza `RefreshToken.EmpresaActivaId` in-place si hay cookie válida. |
| `POST /api/auth/logout` | Revoca el refresh token si existe, limpia la cookie. `AllowAnonymous` (debe funcionar incluso con access token ya vencido). |
| `POST /api/auth/forgot-password` | Siempre 200. Genera el token de Identity pero **no envía email** (no hay infra de correo — ver `CLAUDE.md`). Solo lo loguea server-side por ahora. |
| `POST /api/auth/reset-password` | **Decisión de diseño no cubierta por el contrato**: el body público es solo `{token, password}` (sin email/userId), pero `UserManager.ResetPasswordAsync` necesita el usuario resuelto. Se codifica `userId:identityToken` en base64 como el "token" que viajaría por email (`PasswordResetTokenCodec`) — el contrato público no cambia. |
| `POST /api/auth/change-password` | Self-service, autenticado. Nuevo, no estaba en las 6 rutas originales del documento de instrucciones. |

**Decisiones de diseño no explícitas en el contrato, tomadas en esta sesión:**
1. **Refresh token real**: tabla `RefreshToken` propia (hash SHA-256, nunca el valor crudo), rotación en cada `/refresh`, cookie `httpOnly + Secure + SameSite=Strict`, `Path=/api/auth`.
2. **`RefreshToken.EmpresaActivaId`**: el mock usa un header `x-mock-empresa-activa` (hack de MSW, explícitamente marcado como mock-only en `mockSession.ts`) para que `/refresh` sepa qué empresa restaurar. El backend real no puede confiar en un header del cliente para esto sin re-validar — se guarda `EmpresaActivaId` en la fila del refresh token server-side, actualizada por `/switch-empresa`, y `/refresh` la usa como hint (siempre revalidada contra `UsuarioEmpresa`).
3. **`ShacUser.EsSuperadminMultiempresa`**: campo crítico descubierto leyendo `auth.types.ts`/`auth.handlers.ts` directamente — **no estaba en `CLAUDE.md` ni en el contrato resumido**. Es un flag global independiente de `UsuarioEmpresa` que fuerza rol `SUPERADMIN` + `empresaActivaId: null` sin importar asignaciones. Sin este campo, el login de `user-superadmin-001` (que deliberadamente no tiene ninguna fila `UsuarioEmpresa`) sería imposible de replicar.
4. **`UserRole` tiene 9 valores, no 7**: `CLAUDE.md` solo documenta los 7 originales. `ADMINISTRADOR_EMPRESA` y `SUPERADMIN` se agregaron en la fase Multiempresa — confirmado leyendo `shc-controldoc/src/types/auth.types.ts` directamente. `SUPERADMIN` explícitamente **no es asignable** vía `UsuarioEmpresa` (es el flag de arriba) — `AsignarUsuarioEmpresaValidator` lo rechaza.
5. **`ShacUser.AreaId`/`AreaIds`** (no `Area`/`AreasAsignadas` como decía `CLAUDE.md`): son FKs (`Guid`) al catálogo de Áreas de M9, todavía no scaffoldeado — se agregaron las columnas sin FK real en la BD todavía.

## Módulo de referencia 2 — Empresas (`Features/Empresas/`)

6 endpoints, todos `RequireAuthorization(RequireRole("SUPERADMIN"))`. Cascada RN-EMP-005 (desactivar empresa → todas sus `UsuarioEmpresa` a `INACTIVO`) implementada con transacción EF Core explícita (`ExecuteUpdateAsync` + `SaveChangesAsync` en la misma transacción, porque son dos round-trips distintos a la BD). Validación de RUC (`^\d{11}$`) y unicidad tomadas de `empresaForm.schema.ts` real, no del contrato resumido.

## Shared / convenciones (aplican a todos los módulos futuros)

- `ApiResponse<T>` y `PaginationMeta` viven en **`ShcMvpEndPoint.Domain/Common/`**, no en `ShcMvpEndPoint/Shared/` como sugiere `docs/SHAC-Arquitectura.md` — es la única forma de que `ValidationFilter<T>` (que vive en `Infrastructure/Middleware/`, por decisión del skill) pueda construir `ApiResponse.Fail(...)` sin crear una referencia circular Infrastructure→Host. Documentado con un comentario en el propio archivo.
- Excepciones de dominio (`Domain/Exceptions/`): `NotFoundException` (404), `ConflictException` (409), `BusinessRuleException` (422), `UnauthorizedBusinessException` (401), `ForbiddenBusinessException` (403), `BadRequestBusinessException` (400) — mapeadas centralmente en `ApiExceptionHandler` (Infrastructure/Middleware). Los dos últimos tipos **no estaban previstos en las instrucciones originales** (que solo mencionaban 400/404/409/422) — se agregaron porque el código fuente real (`auth.handlers.ts`, `empresas.handlers.ts`) usa 401 y 403 explícitamente en varios casos.
- `EndpointExtensions.cs` (`MapFeatureEndpoints`/`AddFeatureHandlers`) vive en **`ShcMvpEndPoint/Extensions/`** (host), no en Infrastructure — el skill genérico lo ubicaba ahí pero es imposible en este layout de 4 proyectos (Infrastructure no puede referenciar tipos de `Features/` sin ciclo).
- JSON: `PropertyNamingPolicy = CamelCase` global + `JsonStringEnumConverter()` **sin** policy propia (los enums deben viajar como `"SUPERADMIN"`, `"ACTIVA"`, etc. — literales exactos de los union types de TypeScript, no camelCase).
- CORS: policy nombrada `ShacFrontend`, orígenes desde `Cors:AllowedOrigins` (default `http://localhost:5173`, puerto real de Vite no confirmado explícitamente — revisar si el frontend corre en otro puerto).
- Swagger: `Swashbuckle.AspNetCore` 10.2.3 + `Microsoft.OpenApi` 2.7.5 (breaking change de namespace: `Microsoft.OpenApi.Models` → `Microsoft.OpenApi`). **Pendiente**: el candado "Authorize" en Swagger UI (`AddSecurityRequirement` con `OpenApiReference`) no compila con la v2 de `Microsoft.OpenApi` — la definición del esquema Bearer está lista pero no está enlazada globalmente. Hay un `TODO` en `Program.cs`.

## Pendiente para la siguiente sesión (explícitamente fuera de alcance hoy, por instrucción)

- **Documentos** (sección 1 del contrato) — no tocado, como se pidió.
- **Job de notificaciones de vencimiento** — no tocado, como se pidió.
- Candado "Authorize" en Swagger UI (ver arriba) — deuda técnica menor, no bloqueante.
- Tests de integración: solo 2 de ~13 endpoints tienen cobertura. El resto de Auth (`refresh`, `switch-empresa`, `logout`, `forgot/reset/change-password`) y Empresas (CRUD completo + cascada RN-EMP-005) no tienen test todavía.
- No hay ningún endpoint para **crear el primer usuario** (`ShacUser`) — M6 Usuarios no está scaffoldeado. Verificar login end-to-end con un usuario real requiere sembrar uno manualmente (SQL directo o un script) hasta que exista ese módulo.
- Revisar puerto real del dev server de Vite (`shc-controldoc`) para `Cors:AllowedOrigins` — se asumió 5173 (default de Vite), no confirmado en `vite.config.ts`.
