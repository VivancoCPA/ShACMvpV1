# nc-list-view

Vista principal del módulo M2 en `/nonconformities`. Cubre la página contenedora, los filtros URL-driven, la tabla paginada con badges e indicadores, y el hook que mapea URL params al query layer.

## ADDED Requirements

### Requirement: NonconformityListPage renders the M2 module entry view
The system SHALL render a `NonconformityListPage` component at the `/nonconformities` route that composes `NCListFilters` above and `NCList` below, wrapped in a `PageWrapper` with the title from `t('nonconformities:list.title')`. A "Nueva NC" button SHALL be visible only for users whose `UserRole` is `SUPERVISOR` or `JEFE_CALIDAD_SYST`. `NCList` SHALL be wrapped in an `ErrorBoundary` so filter controls remain interactive when the list fails.

#### Scenario: Authorized user sees the Nueva NC button
- **WHEN** a user with role `SUPERVISOR` or `JEFE_CALIDAD_SYST` renders `NonconformityListPage`
- **THEN** a "Nueva NC" button is visible in the page header

#### Scenario: Unauthorized user does not see the Nueva NC button
- **WHEN** a user with role `OPERARIO`, `AUDITOR_INTERNO`, `ALTA_DIRECCION`, or `JEFE_CONTROL_DOCUMENTARIO` renders `NonconformityListPage`
- **THEN** no "Nueva NC" button appears in the page header

#### Scenario: List error does not unmount filter controls
- **WHEN** `NCList` throws an error caught by its `ErrorBoundary`
- **THEN** `NCListFilters` and the page header remain mounted and interactive

---

### Requirement: NCListFilters persists all filter state in URL search params
The system SHALL render a `NCListFilters` component that manages `search`, `estado`, `dominio`, `severidad`, `areaAfectada`, `fechaDesde`, `fechaHasta`, and `page` exclusively via `useSearchParams` from react-router-dom — no `useState` for filter values. The search input SHALL debounce user keystrokes by 300 ms before updating the URL param. A "Limpiar filtros" button SHALL appear only when at least one filter param is present, and clicking it SHALL remove all filter params and reset `page` to 1. Changing any filter other than `page` SHALL also reset `page` to 1.

#### Scenario: Typing in search input updates URL param after debounce
- **WHEN** a user types "NC-CAL" into the search input
- **THEN** after 300 ms the URL search param `search=NC-CAL` is set without a full page reload

#### Scenario: Selecting a dominio filters the list
- **WHEN** a user selects "NC-SST" in the dominio select
- **THEN** the URL search param `dominio=SST` is set and `NCList` re-fetches with that filter

#### Scenario: Selecting a severidad filters the list
- **WHEN** a user selects "CRITICA" in the severidad select
- **THEN** the URL search param `severidad=CRITICA` is set and `NCList` re-fetches

#### Scenario: Selecting a fechaDesde filters the list
- **WHEN** a user picks a date in the fechaDesde input
- **THEN** the URL search param `fechaDesde=<ISO-date>` is set

#### Scenario: Clear filters button appears only with active filters
- **WHEN** no search params are present
- **THEN** the "Limpiar filtros" button is not rendered

#### Scenario: Clear filters button resets all params
- **WHEN** `search=NC-CAL&estado=CERRADA` are in the URL and the user clicks "Limpiar filtros"
- **THEN** all filter params including `page` are removed from the URL

#### Scenario: Changing a non-page filter resets page to 1
- **WHEN** the user is on page 3 and selects a different `estado` filter
- **THEN** the URL param `page` is reset to 1 along with the new `estado` value

---

### Requirement: NCListFilters does not reset search params on mount
The system SHALL NOT clear or overwrite existing URL search params when `NCListFilters` mounts. The component SHALL read `useSearchParams` as initial state and leave it unchanged if the user navigated back from a detail page or reloaded the page with params in the URL. No `useEffect` or initialization logic SHALL write to searchParams on mount.

#### Scenario: Filters survive navigation to detail and back
- **WHEN** a user has active filters `estado=EN_INVESTIGACION&dominio=SST` and clicks a row to navigate to `/nonconformities/:id`
- **AND** the user presses the browser back button to return to `/nonconformities`
- **THEN** the URL still contains `estado=EN_INVESTIGACION&dominio=SST` and the filter controls reflect those values without any reset

#### Scenario: Filters survive page reload
- **WHEN** a user has active filters `severidad=CRITICA&page=2` in the URL and reloads the page
- **THEN** after reload, `NCListFilters` renders with the severity select showing "CRITICA" and the list shows page 2 — no reset to default state

#### Scenario: NCListFilters does not emit a searchParams write on mount with empty URL
- **WHEN** a user navigates to `/nonconformities` with no search params
- **THEN** no URL params are written during the initial render of `NCListFilters`

---

### Requirement: NCList renders a paginated table with loading, empty, and error states
The system SHALL render a `NCList` component with columns: Número NC, Dominio, Área Afectada, Severidad, Estado, Responsable AC, Fecha Detección, and Acciones. Default `pageSize` SHALL be 5. Pagination controls SHALL use a sliding window and display "Mostrando X–Y de Z" using i18n keys from `t('nonconformities:list.pagination')`. While loading, the table SHALL show 5 skeleton rows with `bg-hairline animate-pulse` styling. When the result set is empty, `t('nonconformities:list.empty')` SHALL appear. When the query errors, an error message and a "Reintentar" button calling `refetch` SHALL appear. Clicking any row SHALL navigate to `/nonconformities/:id`.

#### Scenario: Loading state renders 5 skeleton rows
- **WHEN** `useNCList` returns `isLoading: true`
- **THEN** the table body contains exactly 5 rows with skeleton pulse styling and no real NC data

#### Scenario: Empty state shows localized message
- **WHEN** the query resolves with zero non-conformities
- **THEN** `t('nonconformities:list.empty')` is displayed and no table rows are present

#### Scenario: Error state shows retry button
- **WHEN** the query resolves with `isError: true`
- **THEN** an error message and a button that calls `refetch` are rendered

#### Scenario: Row click navigates to detail
- **WHEN** a user clicks anywhere on an `NCList` row
- **THEN** the router navigates to `/nonconformities/<id>` for that NC

#### Scenario: Pagination controls update the page param
- **WHEN** a user clicks page 2 in the pagination controls
- **THEN** the URL param `page=2` is set and the list re-fetches with `page: 2`

---

### Requirement: ANULADA rows are visually attenuated
The system SHALL render rows for non-conformities with `estado: 'ANULADA'` with reduced opacity (`opacity-50`) and no write-action buttons in the Acciones column. The row SHALL remain clickable to navigate to the detail page.

#### Scenario: ANULADA row has reduced opacity
- **WHEN** an `NCList` row renders a non-conformity with `estado: 'ANULADA'`
- **THEN** the row element has the `opacity-50` Tailwind class applied

#### Scenario: ANULADA row has no write-action buttons
- **WHEN** an `NCList` row renders a non-conformity with `estado: 'ANULADA'`
- **THEN** no edit, delete, or status-change buttons appear in the Acciones column regardless of the viewer's role

#### Scenario: ANULADA row is still clickable
- **WHEN** a user clicks on a row with `estado: 'ANULADA'`
- **THEN** the router navigates to `/nonconformities/<id>` for that NC

---

### Requirement: NCList row shows overdue AC indicator
The system SHALL render a warning icon in the Número NC column (or a dedicated indicator column) for any NC whose `accionesCorrectivas` array contains at least one AC with `estado: 'VENCIDA'`. The icon SHALL have an accessible `aria-label` from `t('nonconformities:list.acVencidaLabel')` and SHALL use a `text-error` color class. The indicator SHALL NOT appear for NCs with `estado: 'CERRADA'` or `estado: 'ANULADA'`.

#### Scenario: Row with overdue AC shows warning icon
- **WHEN** an `NCList` row renders a non-conformity with at least one AC with `estado: 'VENCIDA'`
- **THEN** a warning icon with `aria-label` and `text-error` class is rendered in the row

#### Scenario: Row without overdue ACs shows no warning icon
- **WHEN** an `NCList` row renders a non-conformity with no ACs in `VENCIDA` state
- **THEN** no AC warning icon is rendered

#### Scenario: Closed or annulled NC shows no warning icon
- **WHEN** an `NCList` row renders a non-conformity with `estado: 'CERRADA'` or `estado: 'ANULADA'`
- **THEN** no AC warning icon is rendered even if ACs are in `VENCIDA` state

---

### Requirement: useNCList maps URL search params to useNonconformities query
The system SHALL export a `useNCList` hook from `src/features/nonconformities/hooks/useNCList.ts` that reads `search`, `estado`, `dominio`, `severidad`, `areaAfectada`, `fechaDesde`, `fechaHasta`, and `page` from `useSearchParams`, maps them to an `NCFilters` object with `pageSize: 5`, and delegates to `useNonconformities()`. The hook SHALL return `{ nonconformidades, isLoading, isError, pagination, refetch }` with no UI logic or JSX.

#### Scenario: Hook returns nonconformidades array from query result
- **WHEN** `useNCList` is called and `useNonconformities` resolves with data
- **THEN** `nonconformidades` equals the `data.data` array from the query response

#### Scenario: Hook passes dominio from URL param
- **WHEN** the URL contains `dominio=SST`
- **THEN** `useNonconformities` is called with `dominio: 'SST'` in the filters object

#### Scenario: Hook passes page from URL param
- **WHEN** the URL contains `page=2`
- **THEN** `useNonconformities` is called with `page: 2`

#### Scenario: Hook returns isLoading true during fetch
- **WHEN** `useNonconformities` is pending
- **THEN** `useNCList` returns `isLoading: true`
