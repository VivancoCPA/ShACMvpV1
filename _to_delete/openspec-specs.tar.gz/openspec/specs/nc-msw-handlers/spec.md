# Spec: nc-msw-handlers

## Purpose

MSW v2 request handlers for the M2 Non-Conformities domain. Simulate the backend for all NC and AccionCorrectiva endpoints, enforcing business rules RN-NC-001..007 at the mock layer. All handlers use `http.*` (never `rest.*`) and simulate 400 ms network latency. Exported from `src/mocks/handlers/nonconformities.handlers.ts` and wired into `src/mocks/handlers/index.ts`.

---

## Requirements

### Requirement: GET /api/nonconformities handler with pagination and filters
The system SHALL implement an MSW v2 handler for `GET /api/nonconformities` in `src/mocks/handlers/nonconformities.handlers.ts` that applies all `NCFilters` fields in memory over the `nonconformityFixtures` array and returns a paginated `ApiResponse<NoConformidad[]>`. Supported filter parameters: `estado`, `tipo`, `severidad`, `dominio`, `areaAfectada`, `search` (substring match on `descripcion` and `numero`), `fechaDesde`, `fechaHasta` (filter on `fechaDeteccion`), `page` (default 1), `pageSize` (default 20). Before any other filter is applied, the handler SHALL restrict the candidate set to NCs whose `empresaId` matches the `empresaActivaId` of the requesting session; NCs belonging to any other `empresaId` SHALL never appear in `data` or count toward `pagination.totalItems`, regardless of other filters. The handler SHALL simulate 400 ms latency using `delay(400)`.

#### Scenario: GET list returns all fixtures for the active empresa when no filters applied
- **WHEN** a client calls `GET /api/nonconformities` with no query parameters
- **THEN** the handler returns HTTP 200 with `data` containing only fixture NCs whose `empresaId` matches the session's active empresa, and `pagination.totalItems` equal to that count

#### Scenario: GET list filters by estado
- **WHEN** a client calls `GET /api/nonconformities?estado=DETECTADA`
- **THEN** the handler returns only NCs with `estado === 'DETECTADA'` and `empresaId` equal to the session's active empresa

#### Scenario: GET list filters by dominio
- **WHEN** a client calls `GET /api/nonconformities?dominio=SST`
- **THEN** the handler returns only NCs with `dominio === 'SST'` and `empresaId` equal to the session's active empresa

#### Scenario: GET list filters by search substring
- **WHEN** a client calls `GET /api/nonconformities?search=NC-CAL`
- **THEN** the handler returns only NCs whose `numero` or `descripcion` contains `'NC-CAL'` and `empresaId` equal to the session's active empresa

#### Scenario: GET list paginates results correctly
- **WHEN** a client calls `GET /api/nonconformities?page=1&pageSize=3`
- **THEN** the handler returns at most 3 NCs, scoped to the active empresa, and sets `pagination.totalPages` to `Math.ceil(totalItems / 3)` based on that scoped count

#### Scenario: GET list filters by date range
- **WHEN** a client calls `GET /api/nonconformities?fechaDesde=2025-01-01&fechaHasta=2025-06-30`
- **THEN** the handler returns only NCs with `fechaDeteccion` falling within the specified range and `empresaId` equal to the session's active empresa

#### Scenario: GET list excludes NCs from another empresa
- **WHEN** the session's active empresa is `empresa-001` and `GET /api/nonconformities` is requested with no filters
- **THEN** no NC with `empresaId === 'empresa-002'` appears anywhere in `data`, even if it would otherwise match every other filter

---

### Requirement: GET /api/nonconformities/:id handler returning NC with ACs embedded
The system SHALL implement an MSW v2 handler for `GET /api/nonconformities/:id` that finds the NC by `id` in the in-memory array. If found and its `empresaId` matches the session's active empresa, returns HTTP 200 with the full `NoConformidad` including `accionesCorrectivas`. If not found, or found but its `empresaId` does not match the session's active empresa, returns HTTP 404 with `{ success: false, message: 'nonconformities:errors.notFound' }` — both cases are indistinguishable to the caller.

#### Scenario: GET detail returns NC with embedded ACs
- **WHEN** a client calls `GET /api/nonconformities/nc-001`, that NC exists, and its `empresaId` matches the session's active empresa
- **THEN** the handler returns HTTP 200 with `data.accionesCorrectivas` populated

#### Scenario: GET detail returns 404 for unknown id
- **WHEN** a client calls `GET /api/nonconformities/nc-unknown`
- **THEN** the handler returns HTTP 404 with `{ success: false, message: 'nonconformities:errors.notFound' }`

#### Scenario: GET detail returns 404 for an NC belonging to another empresa
- **WHEN** a client calls `GET /api/nonconformities/:id` for an id that exists in the store but whose `empresaId` differs from the session's active empresa
- **THEN** the handler returns HTTP 404 with `{ success: false, message: 'nonconformities:errors.notFound' }`, identical to the unknown-id response

---

### Requirement: POST /api/nonconformities handler with duplicate detection (RN-NC-005)
The system SHALL implement an MSW v2 handler for `POST /api/nonconformities` that: (1) validates required fields (`origen`, `tipo`, `severidad`, `areaAfectada`, `descripcion`, `fechaDeteccion`, `dominio`); (2) generates a new `id` (UUID) and `numero` (e.g., `NC-CAL-2025-009`) based on `dominio`, with the correlative count scoped to the session's active empresa (RN-EMP-003 — two empresas can each have an independent `numero` sequence per `dominio` without colliding); (3) sets `empresaId` to the session's active empresa (never a client-supplied value) and initializes the NC in `DETECTADA` state with `accionesCorrectivas: []` and an initial `auditTrail` entry; (4) checks for potential duplicates among NCs with the same `dominio` + `areaAfectada` created within the last 30 days **and belonging to the same active empresa** — an NC in another empresa with the same `dominio`/`areaAfectada` SHALL never trigger the duplicate warning; (5) returns HTTP 201 with the created NC and, if duplicates found, includes `{ warning: 'POSIBLE_DUPLICADO', ncsSimilares: [...] }` in the response. If the requesting session has no active empresa, the handler SHALL reject the request with 401 instead of creating an NC.

#### Scenario: POST creates a new NC in DETECTADA state
- **WHEN** a client calls `POST /api/nonconformities` with a valid payload
- **THEN** the handler returns HTTP 201 with `data.estado === 'DETECTADA'`, `data.accionesCorrectivas` as an empty array, and `data.empresaId` equal to the session's active empresa

#### Scenario: POST adds an auditTrail entry on creation
- **WHEN** a client calls `POST /api/nonconformities` with a valid payload
- **THEN** the response NC has `auditTrail` with exactly one entry with `accion === 'CREADA'`

#### Scenario: POST returns 400 for missing required field
- **WHEN** a client calls `POST /api/nonconformities` without `descripcion`
- **THEN** the handler returns HTTP 400 with `{ success: false, errors: ['descripcion is required'] }`

#### Scenario: POST detects potential duplicate within the same empresa and returns warning
- **WHEN** a client creates a NC with `dominio='CALIDAD'` and `areaAfectada='Almacén Norte'` and there is an existing NC with the same `dominio` + `areaAfectada`, `creadoEn` within the last 30 days, and the same `empresaId` as the active session
- **THEN** the handler returns HTTP 201 with both the created NC and `{ warning: 'POSIBLE_DUPLICADO', ncsSimilares: [...] }` in the response body

#### Scenario: POST does not set warning when no recent duplicate exists
- **WHEN** a client creates a NC with a unique `dominio` + `areaAfectada` combination
- **THEN** the handler returns HTTP 201 with no `warning` field in the response

#### Scenario: POST does not flag a matching NC from another empresa as a duplicate
- **WHEN** a client creates a NC with `dominio='CALIDAD'` and `areaAfectada='Almacén Norte'` from a session whose active empresa is `empresa-002`, and the only matching recent NC with that `dominio`/`areaAfectada` belongs to `empresa-001`
- **THEN** the handler returns HTTP 201 with no `warning` field in the response

#### Scenario: Numero sequence is independent per empresa
- **WHEN** two `CALIDAD` NCs already exist for `empresa-001` and none exist yet for `empresa-002`, and `POST /api/nonconformities` is requested with `dominio: 'CALIDAD'` from a session whose active empresa is `empresa-002`
- **THEN** the created NC's `numero` is the first correlative for `empresa-002` (e.g. `NC-CAL-2025-001`), not the third overall

#### Scenario: Create rejects when session has no active empresa
- **WHEN** `POST /api/nonconformities` is requested and the session's `empresaActivaId` is `null`
- **THEN** the response status is 401 and no NC is added to the store

---

### Requirement: PATCH /api/nonconformities/:id handler blocking closed/anulada edits
The system SHALL implement an MSW v2 handler for `PATCH /api/nonconformities/:id` that: (1) returns HTTP 404 if the NC does not exist; (2) returns HTTP 409 with `{ success: false, message: 'nonconformities:errors.editBlockedByStatus' }` if the NC `estado` is `'CERRADA'` or `'ANULADA'`; (3) otherwise applies the `UpdateNCInput` fields to the NC, updates `actualizadoEn`, appends an audit trail entry for each changed field, and returns HTTP 200 with the updated NC. When the applied fields change `estado` to a different value, the handler SHALL create a `CAMBIO_ESTADO` notification (via `createCambioEstadoNotification`) targeting the NC's `reportadoPorId` and the responsables of any of the NC's `accionesCorrectivas` not in a closed state, excluding the acting user and any unresolvable id (RN-NOTIF-001).

#### Scenario: PATCH returns 409 when NC is in CERRADA state
- **WHEN** a client calls `PATCH /api/nonconformities/nc-cerrada` and that NC has `estado === 'CERRADA'`
- **THEN** the handler returns HTTP 409 with `message: 'nonconformities:errors.editBlockedByStatus'`

#### Scenario: PATCH returns 409 when NC is in ANULADA state
- **WHEN** a client calls `PATCH /api/nonconformities/nc-anulada` and that NC has `estado === 'ANULADA'`
- **THEN** the handler returns HTTP 409 with `message: 'nonconformities:errors.editBlockedByStatus'`

#### Scenario: PATCH updates allowed fields and records audit trail entry
- **WHEN** a client calls `PATCH /api/nonconformities/nc-001` with `{ causaRaiz: 'Falta de procedimiento' }` on an NC in `EN_INVESTIGACION` state
- **THEN** the handler returns HTTP 200 with `data.causaRaiz === 'Falta de procedimiento'` and a new `auditTrail` entry with `accion === 'CAMPO_EDITADO'` and `campoModificado === 'causaRaiz'`

#### Scenario: Changing estado notifies the reporter
- **WHEN** `PATCH /api/nonconformities/nc-001` is requested with `{ estado: 'EN_INVESTIGACION' }` by a user other than the NC's `reportadoPorId`
- **THEN** a `CAMBIO_ESTADO` notification is created with `usuarioId` equal to `nc.reportadoPorId`

#### Scenario: Editing a field other than estado creates no state-change notification
- **WHEN** `PATCH /api/nonconformities/nc-001` is requested with `{ causaRaiz: 'Falta de procedimiento' }` only, not changing `estado`
- **THEN** no `CAMBIO_ESTADO` notification is created for this request

#### Scenario: Acting user changing their own NC's estado does not notify themselves
- **WHEN** `PATCH /api/nonconformities/:id` changes `estado` and the acting user is the NC's `reportadoPorId`
- **THEN** no notification is created for the acting user

---

### Requirement: POST /api/nonconformities/:id/anular handler with justificacion validation
The system SHALL implement an MSW v2 handler for `POST /api/nonconformities/:id/anular` that: (1) returns HTTP 404 if the NC does not exist; (2) returns HTTP 400 with `{ success: false, errors: ['justificacion is required'] }` if the request body `justificacion` is missing or empty; (3) changes `estado` to `'ANULADA'`, appends an audit trail entry with `accion: 'ANULADA'` and `valorNuevo: justificacion`, and returns HTTP 200 with the updated NC.

#### Scenario: POST anular returns 400 when justificacion is empty string
- **WHEN** a client calls `POST /api/nonconformities/nc-001/anular` with `{ justificacion: '' }`
- **THEN** the handler returns HTTP 400 with `errors: ['justificacion is required']`

#### Scenario: POST anular returns 400 when justificacion is missing
- **WHEN** a client calls `POST /api/nonconformities/nc-001/anular` with no body
- **THEN** the handler returns HTTP 400 with `errors: ['justificacion is required']`

#### Scenario: POST anular changes estado to ANULADA
- **WHEN** a client calls `POST /api/nonconformities/nc-001/anular` with a non-empty `justificacion`
- **THEN** the handler returns HTTP 200 with `data.estado === 'ANULADA'` and a new `auditTrail` entry with `accion === 'ANULADA'`

---

### Requirement: POST /api/nonconformities/:id/acciones-correctivas handler
The system SHALL implement an MSW v2 handler for `POST /api/nonconformities/:id/acciones-correctivas` that: (1) returns HTTP 404 if the NC does not exist; (2) validates that `descripcion`, `responsableId`, and `plazoFecha` are present — returns HTTP 400 if any is missing; (3) creates a new `AccionCorrectiva` with `estado: 'PENDIENTE'`, resolving its `responsableNombre` from `responsableId` via `resolveUserDisplayName` (from `src/mocks/fixtures/userIdentity.fixtures.ts`) — never falling back to the literal string `'Usuario'` for a `responsableId` that resolves to a real `authFixtures` account or a `seedLegacyNames` entry — appends it to `nc.accionesCorrectivas`, appends an audit trail entry with `accion: 'AC_CREADA'`, and returns HTTP 201 with `ApiResponse<AccionCorrectiva>`.

#### Scenario: POST creates AC with PENDIENTE state
- **WHEN** a client calls `POST /api/nonconformities/nc-001/acciones-correctivas` with valid `{ descripcion, responsableId, plazoFecha }`
- **THEN** the handler returns HTTP 201 with `data.estado === 'PENDIENTE'`

#### Scenario: POST returns 400 when descripcion is missing
- **WHEN** a client calls `POST /api/nonconformities/nc-001/acciones-correctivas` without `descripcion`
- **THEN** the handler returns HTTP 400

#### Scenario: POST resolves responsableNombre for a real, non-legacy account
- **WHEN** a client calls `POST /api/nonconformities/nc-001/acciones-correctivas` with `{ ..., responsableId: 'user-supervisor-002' }`, an id present in `authFixtures` but absent from the removed `users.fixtures.ts` catalog
- **THEN** the created AC's `responsableNombre` is the resolved display name, never the literal string `'Usuario'`

---

### Requirement: PATCH /api/nonconformities/:id/acciones-correctivas/:acId handler
The system SHALL implement an MSW v2 handler for `PATCH /api/nonconformities/:ncId/acciones-correctivas/:acId` that: (1) returns HTTP 404 if the NC or AC does not exist; (2) applies `UpdateACInput` fields to the AC; (3) updates `ac.actualizadoEn` and appends an audit trail entry to the parent NC with `accion: 'AC_ACTUALIZADA'`; (4) returns HTTP 200 with `ApiResponse<AccionCorrectiva>`.

#### Scenario: PATCH AC returns 404 when AC does not exist
- **WHEN** a client calls `PATCH /api/nonconformities/nc-001/acciones-correctivas/ac-unknown`
- **THEN** the handler returns HTTP 404

#### Scenario: PATCH AC updates estado and records audit trail entry
- **WHEN** a client calls `PATCH /api/nonconformities/nc-001/acciones-correctivas/ac-1` with `{ estado: 'EN_EJECUCION' }`
- **THEN** the handler returns HTTP 200 with `data.estado === 'EN_EJECUCION'` and the parent NC has a new `auditTrail` entry with `accion === 'AC_ACTUALIZADA'`

---

### Requirement: POST /api/nonconformities/:id/acciones-correctivas/:acId/cerrar handler
The system SHALL implement an MSW v2 handler for `POST /api/nonconformities/:ncId/acciones-correctivas/:acId/cerrar` that: (1) returns HTTP 404 if the NC or AC does not exist; (2) returns HTTP 400 with `{ success: false, errors: ['descripcionEvidencia is required'] }` if `descripcionEvidencia` is missing or empty; (3) sets `ac.estado = 'COMPLETADA'`, `ac.fechaCierre = new Date().toISOString()`, sets `ac.descripcionEvidencia` and `ac.evidenciaUrl` from the request, appends an audit trail entry with `accion: 'AC_CERRADA'` to the parent NC, and returns HTTP 200 with `ApiResponse<AccionCorrectiva>`.

#### Scenario: POST cerrar returns 400 when descripcionEvidencia is empty
- **WHEN** a client calls `POST /api/nonconformities/nc-001/acciones-correctivas/ac-1/cerrar` with `{ descripcionEvidencia: '' }`
- **THEN** the handler returns HTTP 400 with `errors: ['descripcionEvidencia is required']`

#### Scenario: POST cerrar sets AC estado to COMPLETADA
- **WHEN** a client calls `POST /api/nonconformities/nc-001/acciones-correctivas/ac-1/cerrar` with valid `{ descripcionEvidencia: 'Evidencia de corrección' }`
- **THEN** the handler returns HTTP 200 with `data.estado === 'COMPLETADA'` and `data.fechaCierre` set to a non-empty ISO 8601 string

#### Scenario: POST cerrar appends AC_CERRADA to NC audit trail
- **WHEN** a client successfully closes an AC
- **THEN** the parent NC has a new `auditTrail` entry with `accion === 'AC_CERRADA'`

---

### Requirement: Empresa-scoped isolation across all by-id nonconformity operations
Every MSW handler in `nonconformities.handlers.ts` that operates on an existing NC identified by `:id` or `:ncId` — including `PATCH /api/nonconformities/:id`, `DELETE /api/nonconformities/:id`, `PATCH /api/nonconformities/:id/restore`, `POST /api/nonconformities/:id/anular`, `POST /api/nonconformities/:ncId/acciones-correctivas`, `PATCH /api/nonconformities/:id/acciones-correctivas/:acId`, and `POST /api/nonconformities/:id/acciones-correctivas/:acId/cerrar` — SHALL first verify that the NC's `empresaId` matches the session's active empresa before performing any further validation or mutation. Accion correctiva sub-resources do not carry their own `empresaId`; their isolation SHALL be enforced entirely through the parent NC lookup. When the parent NC's `empresaId` does not match, the handler SHALL respond exactly as it would for a non-existent NC id (`404` with `{ success: false, message: 'nonconformities:errors.notFound' }`), without performing the requested operation.

#### Scenario: Edit on another empresa's NC is rejected as not found
- **WHEN** `PATCH /api/nonconformities/:id` is requested for an NC id that exists but whose `empresaId` differs from the session's active empresa
- **THEN** the response is HTTP 404 with `{ success: false, message: 'nonconformities:errors.notFound' }`, and the NC is unchanged

#### Scenario: Anular on another empresa's NC is rejected as not found
- **WHEN** `POST /api/nonconformities/:id/anular` is requested for an NC id that exists but whose `empresaId` differs from the session's active empresa
- **THEN** the response is HTTP 404 with `{ success: false, message: 'nonconformities:errors.notFound' }`, and the NC's `estado` is unchanged

#### Scenario: Accion correctiva sub-resource on another empresa's NC is rejected as not found
- **WHEN** `POST /api/nonconformities/:ncId/acciones-correctivas` is requested for an `:ncId` that exists but whose `empresaId` differs from the session's active empresa
- **THEN** the response is HTTP 404 with `{ success: false, message: 'nonconformities:errors.notFound' }`, and no accion correctiva is created

---

### Requirement: GET /api/users handler returning one fixture user per role
The system SHALL implement an MSW v2 handler for `GET /api/users` in `src/mocks/handlers/nonconformities.handlers.ts` (or a shared `users.handlers.ts` added to the handlers index) that returns `ApiResponse<User[]>` with exactly six fixture users — one per `UserRole`. The handler SHALL simulate 400 ms latency using `delay(400)`. Each user object SHALL have at minimum: `id` (string), `nombre` (string), `apellido` (string), `rol` (UserRole), `email` (string). The fixture data SHALL live in `src/mocks/fixtures/users.fixtures.ts`.

#### Scenario: GET /api/users returns six fixture users
- **WHEN** a client calls `GET /api/users` with no query parameters
- **THEN** the handler returns HTTP 200 with `data` containing exactly six users, one per role

#### Scenario: GET /api/users returns data in ApiResponse shape
- **WHEN** a client calls `GET /api/users`
- **THEN** the response body satisfies `ApiResponse<User[]>` with `success: true`

---

### Requirement: POST /api/nonconformities accepts optional forzar flag to bypass duplicate check
The existing `POST /api/nonconformities` handler SHALL be extended to accept an optional `forzar: boolean` field in the request body. When `forzar === true`, the handler SHALL skip the duplicate detection logic (RN-NC-005) and return HTTP 201 with the created NC and no `warning` field in the response.

#### Scenario: POST with forzar=true skips duplicate detection
- **WHEN** a client calls `POST /api/nonconformities` with `forzar: true` and a payload that would normally trigger a POSIBLE_DUPLICADO warning
- **THEN** the handler returns HTTP 201 with no `warning` field in the response body

#### Scenario: POST with forzar=false behaves identically to POST without forzar
- **WHEN** a client calls `POST /api/nonconformities` with `forzar: false` and a duplicate-triggering payload
- **THEN** the handler returns HTTP 201 with `warning: 'POSIBLE_DUPLICADO'`

---

### Requirement: All handlers simulate 400 ms network latency
Every handler in `nonconformities.handlers.ts` SHALL call `await delay(400)` before returning any response. The constant `400` SHALL be defined as a module-level `const LATENCY = 400` to facilitate future adjustment.

#### Scenario: Handler delays response by approximately 400 ms
- **WHEN** any nonconformity handler is called
- **THEN** the response arrives after approximately 400 ms of simulated latency

---

### Requirement: nonconformityHandlers wired into handlers index
The system SHALL export the `nonconformityHandlers` array from `src/mocks/handlers/nonconformities.handlers.ts` and include it in the spread of handlers in `src/mocks/handlers/index.ts`.

#### Scenario: nonconformityHandlers importable from handlers index
- **WHEN** the MSW worker starts in development mode
- **THEN** all nonconformity handlers are active and intercept requests to `/api/nonconformities*`
