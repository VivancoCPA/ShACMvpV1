# Spec: quality-event-msw-fixtures

## Purpose

Static mock fixtures for the Quality Events module (`src/mocks/fixtures/quality-events.fixtures.ts`). Provides a deterministic array of at least 20 `QualityEvent` objects covering all enum values, reincidence cycles, terminal states, and a date distribution across the last 6 months so that pagination, date filtering, and badge rendering are all visually verifiable in development.

---

## Requirements

### Requirement: At least 20 static fixtures
The system SHALL define at least 20 fixtures of type `QualityEvent[]` exported as `qualityEventFixtures` from `src/mocks/fixtures/quality-events.fixtures.ts`. The minimum count of 20 ensures a second page exists when the default `pageSize` of 10 is applied.

#### Scenario: Fixture count satisfies pagination threshold
- **WHEN** `qualityEventFixtures` is imported
- **THEN** the array has at least 20 elements

---

### Requirement: Full enum coverage across fixtures
The fixtures SHALL collectively cover all values of `QEOrigin`, `QEType`, `QESeverity`, and `QEStatus` across the array. All 4 origins, 4 types, 4 severities, and all 9 lifecycle states SHALL appear at least once.

#### Scenario: All QEOrigin values present
- **WHEN** unique `origen` values are collected from all fixtures
- **THEN** `O1_INCIDENTE_CAMPO`, `O2_NC_DETECTADA`, `O3_HALLAZGO_AUDITORIA`, and `O4_REPORTE_EXTERNO` are all present

#### Scenario: All QEType values present
- **WHEN** unique `tipo` values are collected from all fixtures
- **THEN** `CALIDAD`, `SST`, `ADUANERO`, and `OPERACIONAL` are all present

#### Scenario: All QESeverity values present
- **WHEN** unique `severidad` values are collected from all fixtures
- **THEN** `BAJA`, `MEDIA`, `ALTA`, and `CRITICA` are all present

#### Scenario: All QEStatus values present
- **WHEN** unique `estado` values are collected from all fixtures
- **THEN** all 9 states (`ABIERTO`, `EN_INVESTIGACION`, `ANALISIS_COMPLETADO`, `EN_EJECUCION`, `PENDIENTE_CIERRE`, `CERRADO`, `EN_VERIFICACION`, `VERIFICADO`, `REABIERTO`) are present

---

### Requirement: Fixture numbering format
Each fixture SHALL have a `numero` field in the format `QE-2025-NNN` or `QE-2026-NNN` where NNN is zero-padded to 3 digits. No two fixtures SHALL share the same `numero`.

#### Scenario: First fixture numero format
- **WHEN** `qualityEventFixtures[0].numero` is accessed
- **THEN** the value matches the pattern `QE-20\d\d-\d{3}`

#### Scenario: All numeros are unique
- **WHEN** `numero` values from all fixtures are placed in a Set
- **THEN** the Set size equals the total fixture count

---

### Requirement: fechaHoraEvento distributed across the last 6 months
The `fechaHoraEvento` field across all fixtures SHALL be spread across the 6-month window ending on the current reference date (2026-07-01), so that applying `fechaDesde`/`fechaHasta` date filters produces non-empty and non-full subsets for visual verification.

#### Scenario: Fixtures span multiple months
- **WHEN** unique month values are extracted from all `fechaHoraEvento` fields
- **THEN** at least 4 distinct calendar months are represented

#### Scenario: No fixture has a future fechaHoraEvento
- **WHEN** all `fechaHoraEvento` values are compared against the reference date 2026-07-01
- **THEN** all values are on or before 2026-07-01

---

### Requirement: fechaHoraReporte y fechaCierre distribuidos en los 12 meses de tendencia mensual
Además de la distribución de `fechaHoraEvento` en los últimos 6 meses (ver requisito existente), las fixtures SHALL colectivamente cubrir con al menos una entrada por mes los 12 meses hacia atrás desde la fecha de referencia del sistema tanto para `fechaHoraReporte` como para `fechaCierre`, de forma que el widget de tendencia mensual (`dashboard-trend-widget`) no muestre `0` estructural en `tendenciaMensualVolumen.abiertos` para ningún mes del rango de 12 meses. Los ajustes de fecha SHALL preservar las restricciones narrativas ya existentes de cada fixture (`causaRaizFirmadaEn` < `fechaCierre` < `fechaVerificacionProgramada`/`fechaVerificacionRealizada`/fecha actual del sistema) y SHALL priorizar mover fechas de registros existentes antes que agregar fixtures nuevos, para no alterar las proporciones mínimas ya exigidas por los demás requisitos de esta spec (cobertura de enums, `ciclo > 1`, `VERIFICADO`, seeded ACs).

#### Scenario: Cada uno de los 12 meses tiene al menos un fechaHoraReporte
- **WHEN** se agrupan los 12 meses hacia atrás desde la fecha de referencia del sistema
- **THEN** cada mes tiene al menos una fixture con `fechaHoraReporte` dentro de ese mes

#### Scenario: La mayoría de los 12 meses tiene al menos un fechaCierre
- **WHEN** se agrupan los 12 meses hacia atrás desde la fecha de referencia del sistema
- **THEN** al menos 10 de los 12 meses tienen al menos una fixture con `fechaCierre` dentro de ese mes (los meses sin cierre, si los hay, quedan documentados como gap aceptado en `design.md`, no forzados artificialmente)

#### Scenario: Los ajustes de fecha no rompen restricciones narrativas existentes
- **WHEN** se inspecciona cualquier fixture cuyo `fechaCierre` fue movido para esta spec
- **THEN** `fechaCierre` sigue siendo posterior a `causaRaizFirmadaEn` y anterior a `fechaVerificacionProgramada`/`fechaVerificacionRealizada` (cuando existan) y a la fecha actual del sistema

---

### Requirement: At least 5 fixtures with ciclo > 1
At least 5 fixtures SHALL have `ciclo >= 2` to exercise the Reincidencia badge. Their `ciclo` values SHALL include at least one instance of `ciclo === 3` to verify that the badge label reads "Reincidencia ×3".

#### Scenario: Minimum reincidence fixtures
- **WHEN** `qualityEventFixtures` is filtered by `f => f.ciclo > 1`
- **THEN** the result has at least 5 elements

#### Scenario: ciclo 3 present in at least one fixture
- **WHEN** `qualityEventFixtures` is filtered by `f => f.ciclo === 3`
- **THEN** the result has at least 1 element

---

### Requirement: At least 2 fixtures in VERIFICADO state
At least 2 fixtures SHALL have `estado === 'VERIFICADO'` so that filtering by active states (e.g., `estado=ABIERTO`) produces a visually empty second page scenario, and filtering by `VERIFICADO` shows a non-empty result.

#### Scenario: At least 2 VERIFICADO fixtures
- **WHEN** `qualityEventFixtures` is filtered by `f => f.estado === 'VERIFICADO'`
- **THEN** the result has at least 2 elements

---

### Requirement: EN_VERIFICACION fixtures include fechaVerificacionProgramada
All fixtures with `estado === 'EN_VERIFICACION'` SHALL have `fechaVerificacionProgramada` set to a non-null ISO 8601 string so that `DeadlineBadge` always receives a valid date prop for those rows.

#### Scenario: EN_VERIFICACION fixtures have fechaVerificacionProgramada
- **WHEN** `qualityEventFixtures` is filtered by `f => f.estado === 'EN_VERIFICACION'`
- **THEN** every result has `fechaVerificacionProgramada` defined and parseable as a Date

---

### Requirement: EN_VERIFICACION fixtures include auditorAsignadoId
All fixtures with `estado === 'EN_VERIFICACION'` SHALL have `auditorAsignadoId` set to the id of a user fixture with `rol === 'AUDITOR_INTERNO'`, so that the `AUDITOR_INTERNO` role has at least one QE actionable in `dashboard-acciones-requeridas` and in `quality-event-verificacion`'s REG-EFEC-001 form during development. Fixtures that never reached `EN_VERIFICACION` (i.e. never `CERRADO` or beyond) SHALL leave `auditorAsignadoId` absent.

#### Scenario: EN_VERIFICACION fixtures have auditorAsignadoId
- **WHEN** `qualityEventFixtures` is filtered by `f => f.estado === 'EN_VERIFICACION'`
- **THEN** every resulting fixture has a non-empty `auditorAsignadoId` matching an existing `AUDITOR_INTERNO` user fixture

#### Scenario: At least one AUDITOR_INTERNO fixture user has an assigned QE
- **WHEN** `userFixtures` is filtered to `rol === 'AUDITOR_INTERNO'` and cross-referenced against `qualityEventFixtures`
- **THEN** at least one such user id appears as `auditorAsignadoId` on at least one `EN_VERIFICACION` fixture

#### Scenario: Fixtures that never reached EN_VERIFICACION leave auditorAsignadoId unset
- **WHEN** `qualityEventFixtures` is filtered by `f => ['ABIERTO', 'EN_INVESTIGACION', 'ANALISIS_COMPLETADO', 'EN_EJECUCION', 'PENDIENTE_CIERRE'].includes(f.estado)`
- **THEN** none of the resulting fixtures have `auditorAsignadoId` set

---

### Requirement: AuditTrail and consistent date fields
Each fixture SHALL include at least one `AuditTrailEntry` in `auditTrail`. `fechaReporte` SHALL be a valid ISO 8601 string on or after `fechaHoraEvento`. `creadoEn` and `actualizadoEn` SHALL be valid ISO 8601 strings.

#### Scenario: Minimum audit trail per fixture
- **WHEN** any fixture's `auditTrail` is checked
- **THEN** `auditTrail.length >= 1`

#### Scenario: fechaReporte is not before fechaHoraEvento
- **WHEN** any fixture's `fechaReporte` and `fechaHoraEvento` are compared
- **THEN** `new Date(fechaReporte) >= new Date(fechaHoraEvento)`

---

### Requirement: reportadoPorId rotation
The `reportadoPorId` field across all fixtures SHALL rotate among at least 4 different user IDs from the mock user pool (`user-001` through `user-008`).

#### Scenario: At least 4 distinct reporter IDs
- **WHEN** unique `reportadoPorId` values are collected from all fixtures
- **THEN** the set has size >= 4

---

### Requirement: Seeded reporter names resolve through resolveUserDisplayName
`quality-events.fixtures.ts`'s reporter-rotation seed helper (`nombrePor`, used by `REPORTEROS_ROTACION` to populate `reportadoPorId`/display-name pairs on synthetic trend-seed `QualityEvent`s) SHALL resolve every id via `resolveUserDisplayName` (from `src/mocks/fixtures/userIdentity.fixtures.ts`) instead of importing `USER_NOMBRE_MAP`/`userFixtures` from the removed `src/mocks/fixtures/users.fixtures.ts` directly. `REPORTEROS_ROTACION` mixes ids with a real `authFixtures` login (e.g. `user-005`) and login-less legacy ids covered only by `seedLegacyNames` (`user-001`, `user-002`, `user-003`, `user-008`); both categories SHALL resolve to a correct display name from the same call site.

#### Scenario: Rotation seed resolves a login-less legacy id
- **WHEN** `nombrePor('user-001')` is called
- **THEN** the return value is the name resolved from `seedLegacyNames['user-001']`

#### Scenario: Rotation seed resolves a real authFixtures id
- **WHEN** `nombrePor('user-005')` is called and `user-005` exists in `authFixtures`
- **THEN** the return value is the name resolved from the matching `authFixtures` entry

#### Scenario: Trend-seed QEs built from REPORTEROS_ROTACION show correct names after the catalog consolidation
- **WHEN** `qualityEventFixtures` seed data built via `buildTendenciaSeedQE` is inspected for any `QualityEvent` whose `reportadoPorId` is one of `REPORTEROS_ROTACION`
- **THEN** the corresponding display name resolves correctly for both the legacy and the real-login ids in that list

---

### Requirement: At least 5 fixtures carry seeded acciones-correctivas
The fixture file SHALL define a `qeAccionesCorrectivas: Record<string, AccionCorrectivaQE[]>` map with 2–3 ACs for at least 5 of the 20 `qualityEventFixtures`, used to seed each matching QE's `accionesCorrectivas` array at module load. The `TODO(M4-S05)` comments marking the unresolved Modelo A/B ownership question SHALL be removed from the file.

#### Scenario: At least 5 QEs have non-empty accionesCorrectivas
- **WHEN** `qualityEventFixtures` is imported
- **THEN** filtering by `qe => qe.accionesCorrectivas.length > 0` returns at least 5 QEs

#### Scenario: Seeded ACs have 2 to 3 entries and reference their owning QE
- **WHEN** any seeded QE's `accionesCorrectivas` is inspected
- **THEN** the array has between 2 and 3 elements, and every element's `qeId` equals that QE's `id`

#### Scenario: No TODO(M4-S05) markers remain
- **WHEN** `quality-events.fixtures.ts` is inspected
- **THEN** it contains no `TODO(M4-S05)` comment

---

### Requirement: Every fixture QE has at least 4 audit trail entries
Each of the 20 `qualityEventFixtures` SHALL have `auditTrail.length >= 4`, covering at minimum a creation entry, a state-change entry, a field-edit entry, and (for QEs whose `estado` has progressed past `EN_INVESTIGACION`) a causa-raíz-approval entry.

#### Scenario: Every fixture has at least 4 audit entries
- **WHEN** each fixture in `qualityEventFixtures` is inspected
- **THEN** `auditTrail.length >= 4` for all 20 fixtures

---

### Requirement: Closure and verification data anchored to the current KPI period
A representative subset of `qualityEventFixtures` in `CERRADO` or `VERIFICADO` state SHALL carry `fechaCierre`, `ciclo`, `auditTrail` `ANALISIS_COMPLETADO` entries, and `resultadoVerificacion`/`fechaVerificacionRealizada` values anchored to the reference "current period" date 2026-07-01 (matching the reference date used elsewhere in this spec), so that the period-scoped dashboard KPI formulas (Tasa de cierre en plazo, Tiempo promedio de cierre, Tasa de reincidencia, Tasa de eficacia de ACs, Tiempo promedio de investigación) produce non-zero results from the static fixture set without any change to the calculation code.

#### Scenario: At least one CERRADO/VERIFICADO fixture closes in-plazo within the current month
- **WHEN** `qualityEventFixtures` is filtered to `estado ∈ {CERRADO, VERIFICADO}` with `fechaCierre` in 2026-07
- **THEN** at least one result has business days from `fechaHoraReporte` to `fechaCierre` at or under its severity's plazo (BAJA=22, MEDIA=17, ALTA=14, CRITICA=10 días hábiles)

#### Scenario: At least one CERRADO/VERIFICADO fixture closes out-of-plazo within the current month
- **WHEN** `qualityEventFixtures` is filtered to `estado ∈ {CERRADO, VERIFICADO}` with `fechaCierre` in 2026-07
- **THEN** at least one result has business days from `fechaHoraReporte` to `fechaCierre` over its severity's plazo

#### Scenario: At least one CERRADO/VERIFICADO fixture closing in-period has ciclo > 1
- **WHEN** `qualityEventFixtures` is filtered to `estado ∈ {CERRADO, VERIFICADO}` with `fechaCierre` in the 2026-Q3 quarter
- **THEN** at least one result has `ciclo > 1`

#### Scenario: At least one fixture has an ANALISIS_COMPLETADO audit entry timestamped in the current month
- **WHEN** each fixture's `auditTrail` is scanned for entries with `accion === 'ESTADO_CAMBIADO' && estadoNuevo === 'ANALISIS_COMPLETADO'`
- **THEN** at least one such entry across all fixtures has a `timestamp` in 2026-07, and that entry's `timestamp` is on or after the owning fixture's `fechaHoraReporte`

#### Scenario: At least one verified AccionCorrectiva is EFECTIVO and at least one is NO_EFECTIVO within the current month
- **WHEN** `qeAccionesCorrectivas` entries with `estado === 'CERRADA'` are joined to their owning fixture's `resultadoVerificacion` and `fechaVerificacionRealizada`
- **THEN** among entries whose owning fixture's `fechaVerificacionRealizada` falls in 2026-07, at least one owning fixture has `resultadoVerificacion === 'EFECTIVO'` and at least one has `resultadoVerificacion === 'NO_EFECTIVO'`

---

### Requirement: Al menos 2 QE de origen O3 tienen documentosVinculados no vacío, al menos 2 no tienen ninguno
De los QE fixture con `origen === 'O3_HALLAZGO_AUDITORIA'`, al menos 2 SHALL tener `documentosVinculados` con al menos 1 elemento (reutilizando IDs de documento ya existentes en `documents.fixtures.ts`, sin crear documentos nuevos), y al menos 2 SHALL mantener `documentosVinculados: []`, de modo que el widget de evidencias disponibles (`dashboard-auditor-view`) tenga un caso positivo y uno negativo verificables.

#### Scenario: Al menos 2 hallazgos O3 con evidencia
- **WHEN** se filtran los QE fixture por `origen === 'O3_HALLAZGO_AUDITORIA'` y `documentosVinculados.length > 0`
- **THEN** el resultado tiene al menos 2 elementos

#### Scenario: Al menos 2 hallazgos O3 sin evidencia
- **WHEN** se filtran los QE fixture por `origen === 'O3_HALLAZGO_AUDITORIA'` y `documentosVinculados.length === 0`
- **THEN** el resultado tiene al menos 2 elementos

#### Scenario: Los IDs de documento referenciados existen en documents.fixtures.ts
- **WHEN** un QE `origen O3` tiene `documentosVinculados` no vacío
- **THEN** cada ID referenciado corresponde a un documento existente en `documents.fixtures.ts`, no un ID inventado

---

### Requirement: O3 fixtures carry hallazgoCodigo and normativaVinculada, not hallazgoAuditoriaRef
Every fixture `QualityEvent` with `origen === 'O3_HALLAZGO_AUDITORIA'` SHALL define `hallazgoCodigo` and `normativaVinculada` and SHALL NOT define `hallazgoAuditoriaRef`. Fixtures previously carrying `hallazgoAuditoriaRef: 'HAL-XXXX-NNN · <Norma> · §<Cláusula>'` SHALL be migrated field-by-field: the `HAL-XXXX-NNN` segment becomes `hallazgoCodigo`; the `<Norma>` segment maps to `normativaVinculada.norma` (`'ISO 9001:2015'` → `'ISO_9001_2015'`, `'ISO 45001:2018'` → `'ISO_45001_2018'`, any non-ISO label → `'OTRA'` with that label preserved verbatim in `normativaVinculada.normaOtraDetalle`); the `§<Cláusula>` segment becomes `normativaVinculada.clausula` (without the `§` prefix). Any `auditTrail` entry in the same fixture with `campoModificado: 'hallazgoAuditoriaRef'` SHALL be updated to `campoModificado: 'normativaVinculada'` with `valorNuevo` reflecting the migrated value.

#### Scenario: QE-2026-003 migrates ISO 9001:2015 clause 8.4.1
- **WHEN** fixtures are loaded and the QE with `numero: 'QE-2026-003'` is read
- **THEN** it has `hallazgoCodigo: 'HAL-2026-001'`, `normativaVinculada: { norma: 'ISO_9001_2015', clausula: '8.4.1' }`, and no `hallazgoAuditoriaRef` property

#### Scenario: QE-2026-011 migrates ISO 45001:2018 clause 8.2
- **WHEN** fixtures are loaded and the QE with `numero: 'QE-2026-011'` is read
- **THEN** it has `hallazgoCodigo: 'HAL-2026-003'`, `normativaVinculada: { norma: 'ISO_45001_2018', clausula: '8.2' }`, and no `hallazgoAuditoriaRef` property

#### Scenario: QE-2026-015 migrates a non-ISO reference to norma OTRA
- **WHEN** fixtures are loaded and the QE with `numero: 'QE-2026-015'` (previously `hallazgoAuditoriaRef: 'HAL-2026-004 · Auditoría Operacional · §3.2'`) is read
- **THEN** it has `hallazgoCodigo: 'HAL-2026-004'` and `normativaVinculada: { norma: 'OTRA', normaOtraDetalle: 'Auditoría Operacional', clausula: '3.2' }`

#### Scenario: No fixture QE retains hallazgoAuditoriaRef
- **WHEN** all fixtures are loaded and filtered to `origen === 'O3_HALLAZGO_AUDITORIA'`
- **THEN** none of them has a `hallazgoAuditoriaRef` property, migrated or otherwise

#### Scenario: Migrated audit trail entries reference normativaVinculada, not hallazgoAuditoriaRef
- **WHEN** the fixture QE with `numero: 'QE-2026-011'` or `numero: 'QE-2026-019'` is read
- **THEN** any `auditTrail` entry that previously had `campoModificado: 'hallazgoAuditoriaRef'` now has `campoModificado: 'normativaVinculada'`

---

### Requirement: Fixtures migrate to the solicitudesAjustePlazo array shape
Every seeded `AccionCorrectivaQE` in `qeAccionesCorrectivas` (`src/mocks/fixtures/quality-events.fixtures.ts`) SHALL define `solicitudesAjustePlazo: SolicitudAjustePlazoAC[]` (defaulting to `[]`). Any fixture that previously populated the removed singular `solicitudAjustePlazo` field SHALL have that object migrated to the first (and, at seed time, only) element of `solicitudesAjustePlazo`, gaining a generated `id` and `requiereAprobacionGerencia` computed from its owning QE's `severidad` and the stored `fechaSolicitada`.

#### Scenario: All seeded ACs expose solicitudesAjustePlazo
- **WHEN** `qeAccionesCorrectivas` is inspected
- **THEN** every `AccionCorrectivaQE` has a `solicitudesAjustePlazo` array (possibly empty)

#### Scenario: No fixture references the removed singular field
- **WHEN** `quality-events.fixtures.ts` is inspected
- **THEN** it contains no `solicitudAjustePlazo` (singular) property

---

### Requirement: At least one seeded PENDIENTE request requiring Gerencia approval
The fixture set SHALL include at least one `AccionCorrectivaQE` (on a QE with `severidad` of `ALTA` or `CRITICA`) with a `solicitudesAjustePlazo` entry having `estado: 'PENDIENTE'` and `requiereAprobacionGerencia: true`, so `ACsExtensionPlazoWidget.tsx` and the Alta Dirección dashboard have non-empty data in development. The fixture set SHALL also include at least one `PENDIENTE` entry with `requiereAprobacionGerencia: false` (Jefe de Calidad-only), to exercise the `QEACSection` approve/reject panel for that role.

#### Scenario: At least one Gerencia-pending fixture request exists
- **WHEN** all `solicitudesAjustePlazo` entries across `qeAccionesCorrectivas` are filtered by `s => s.estado === 'PENDIENTE' && s.requiereAprobacionGerencia === true`
- **THEN** the result has at least 1 element

#### Scenario: At least one Jefe-de-Calidad-pending fixture request exists
- **WHEN** all `solicitudesAjustePlazo` entries across `qeAccionesCorrectivas` are filtered by `s => s.estado === 'PENDIENTE' && s.requiereAprobacionGerencia === false`
- **THEN** the result has at least 1 element

---

### Requirement: At least 2 fixtures seed a pending solicitudAjustePlazo on an ALTA/CRITICA QE's AC
`qeAccionesCorrectivas` SHALL include at least 2 `AccionCorrectivaQE` entries with `solicitudAjustePlazo.estado === 'PENDIENTE'`, each belonging to a QE fixture with `severidad === 'ALTA'` or `severidad === 'CRITICA'`. At least 1 additional `AccionCorrectivaQE` entry SHALL have `solicitudAjustePlazo.estado` set to `'APROBADA'` or `'RECHAZADA'`, to verify that the Alta Dirección widget filters by `PENDIENTE` and does not simply show every AC that has ever had a request.

> Nota de staleness (m5-s06-dashboard-altadireccion): este requisito describe el campo singular `solicitudAjustePlazo`, pero el campo real (evolucionado por `m4-gap-extensio-plazos`, archivado 2026-07-12) es el arreglo plural `solicitudesAjustePlazo: SolicitudAjustePlazoAC[]` — ver los requisitos "Fixtures migrate to the solicitudesAjustePlazo array shape" y "At least one seeded PENDIENTE request requiring Gerencia approval" más arriba en este mismo archivo, que ya cubren la misma intención (2+ fixtures PENDIENTE en QEs ALTA/CRITICA) con la forma correcta. Este requisito se sincronizó tal como está escrito en la delta, sin corregir la terminología, por decisión explícita del usuario. Pendiente de reconciliación en un cambio de limpieza futuro.

#### Scenario: At least 2 PENDIENTE requests on ALTA/CRITICA QEs
- **WHEN** `qeAccionesCorrectivas` is flattened and filtered by `ac => ac.solicitudAjustePlazo?.estado === 'PENDIENTE'`
- **THEN** the result has at least 2 elements, and each one's owning QE fixture has `severidad === 'ALTA'` or `severidad === 'CRITICA'`

#### Scenario: At least 1 non-pending request exists as a negative fixture
- **WHEN** `qeAccionesCorrectivas` is flattened and filtered by `ac => ac.solicitudAjustePlazo?.estado === 'APROBADA' || ac.solicitudAjustePlazo?.estado === 'RECHAZADA'`
- **THEN** the result has at least 1 element

---

### Requirement: Quality event fixtures carry empresaId
Every element of `qualityEventFixtures` (`src/mocks/fixtures/quality-events.fixtures.ts`) existing prior to this change SHALL have `empresaId: 'empresa-001'`. No pre-existing fixture's `id`, `numero`, or any other field SHALL change as a result of adding this field.

#### Scenario: All pre-existing QE fixtures belong to empresa-001
- **WHEN** `qualityEventFixtures` is filtered to only the fixtures that existed before this change (identified by their pre-existing `id` values)
- **THEN** every one of them has `empresaId === 'empresa-001'`

---

### Requirement: New empresa-002 quality event fixtures
The system SHALL add at least 4 new `QualityEvent` fixtures to `qualityEventFixtures` with `empresaId: 'empresa-002'`, using ids in the `qe-e2-2026-NNN` range to avoid colliding with existing ids. Each new fixture's `reportadoPorId` SHALL reference only a user that exists in `authFixtures` and is assigned to `empresa-002` via `usuarioEmpresaFixtures` (`empresa-msw-fixtures`).

#### Scenario: At least 4 empresa-002 QE fixtures exist
- **WHEN** `qualityEventFixtures` is filtered by `empresaId === 'empresa-002'`
- **THEN** at least 4 elements are returned

#### Scenario: empresa-002 QE fixtures reference valid empresa-002 users
- **WHEN** the `reportadoPorId` of an `empresa-002` QE fixture is looked up in `usuarioEmpresaFixtures`
- **THEN** an entry exists with that `usuarioId` and `empresaId === 'empresa-002'`
