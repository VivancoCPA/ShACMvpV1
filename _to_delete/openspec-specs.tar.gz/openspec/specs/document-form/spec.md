# document-form

Create and edit form for M1 Control Documentario documents in `BORRADOR` state. Handles both create (`/documents/new`) and edit (`/documents/:id/edit`) modes from a single page component. Enforces Zod validation, role-based field access, conditional confidentiality fields, and file upload through `FileUploadField`. All text uses `react-i18next` (`documents` namespace). Triggers MSW-backed API calls via TanStack Query mutations.

## Requirements

### Requirement: DocumentFormPage detects mode from route
The system SHALL render `DocumentFormPage` in **create mode** when the route is `/documents/new` and in **edit mode** when the route is `/documents/:id/edit`. In edit mode, the page SHALL fetch the document via `useDocument(id)` and pre-populate all form fields with the fetched data before allowing interaction.

#### Scenario: Create mode renders empty form
- **WHEN** the user navigates to `/documents/new`
- **THEN** all form fields are empty except `version` which defaults to `v1.0` and `confidencialidad` which defaults to `INTERNO`

#### Scenario: Edit mode pre-populates all fields
- **WHEN** the user navigates to `/documents/:id/edit` and the document fetch succeeds
- **THEN** every editable field displays the stored document value

#### Scenario: Edit mode blocks non-BORRADOR documents
- **WHEN** the user navigates to `/documents/:id/edit` and the document `estado` is not `BORRADOR`
- **THEN** the form is NOT rendered and an inline error card is shown explaining the document cannot be edited in its current state

### Requirement: DocumentForm validates all fields via Zod schema
The system SHALL validate form input using the `documentFormSchema` Zod schema on submit. Validation errors SHALL be displayed inline below the relevant field without using `alert()` or `confirm()`. Required fields without values SHALL prevent submission.

The schema SHALL enforce:
- `titulo`: string, min 5 chars, max 200 chars, required
- `tipo`: one of `POL | PRC | INS | REG | INF | MAT | PLAN`, required
- `area`: string, min 2 chars, max 100 chars, required
- `version`: string matching `/^v\d+\.\d+$/`, required, default `v1.0`
- `confidencialidad`: one of `PUBLICO | INTERNO | CONFIDENCIAL | RESTRINGIDO`, required, default `INTERNO`
- `rolesAutorizados`: array of `UserRole` enum values, required with min(1) when `confidencialidad === 'RESTRINGIDO'`, otherwise optional (omitted or empty array accepted)
- `revisorId`: UUID string, optional
- `aprobadorId`: UUID string, optional
- `fechaVigencia`: ISO date string, optional
- `fechaRevisionProxima`: ISO date string, optional (auto-filled to `fechaVigencia + 365 days` on submit if empty)
- `descripcion`: string, max 1000 chars, optional
- `archivo`: `File | null`, optional (handled separately via FileUploadField)

#### Scenario: Empty titulo prevents submission
- **WHEN** the user submits the form without entering `titulo`
- **THEN** an inline error message appears below the `titulo` field and no API call is made

#### Scenario: Invalid version format shows inline error
- **WHEN** the user enters `1.0` (missing `v` prefix) in the `version` field and submits
- **THEN** an inline error message appears below the `version` field describing the required format

#### Scenario: Valid form submits successfully
- **WHEN** all required fields have valid values and the user submits
- **THEN** no inline errors appear and the API call is initiated

#### Scenario: RESTRINGIDO without rolesAutorizados prevents submission
- **WHEN** the user sets `confidencialidad` to `RESTRINGIDO`, leaves `rolesAutorizados` empty, and submits
- **THEN** an inline error message appears below `rolesAutorizados` and no API call is made

### Requirement: revisorId and aprobadorId must not be the same user (RN-DOC-019)
The system SHALL enforce segregation of duties between the reviewer and approver of a document. `documentFormSchema` SHALL fail validation when `revisorId` and `aprobadorId` are both non-empty and equal, attaching the validation error to the `aprobadorId` field path. This rule applies identically in create mode and in edit mode (BORRADOR), since `DocumentForm` is the single point where both fields are editable. The rule SHALL NOT apply when either field is empty, and SHALL NOT be re-validated against documents or fixtures already persisted before this rule existed.

#### Scenario: Same user as revisorId and aprobadorId blocks create submission
- **WHEN** the user selects the same person for `revisorId` and `aprobadorId` in create mode and submits
- **THEN** an inline error message appears below the `aprobadorId` field and no API call is made

#### Scenario: Same user as revisorId and aprobadorId blocks edit submission
- **WHEN** the user edits a `BORRADOR` document, changes `revisorId` or `aprobadorId` so both end up equal, and submits
- **THEN** an inline error message appears below the `aprobadorId` field and no API call is made

#### Scenario: Different users for revisorId and aprobadorId pass validation
- **WHEN** the user selects two different people for `revisorId` and `aprobadorId`, even if both share the same `UserRole` (e.g. both `ALTA_DIRECCION`), and submits
- **THEN** no inline error appears for this rule and the API call proceeds

#### Scenario: Leaving revisorId or aprobadorId empty does not trigger this rule
- **WHEN** the user submits the form with `revisorId` set and `aprobadorId` left empty (or vice versa)
- **THEN** no inline error appears for this rule

### Requirement: Create mode submits via POST and navigates on success
In create mode, a valid form submission SHALL call `POST /api/documents` with the validated payload. On a successful response, the system SHALL show a `toast.success` notification using Sonner and navigate to `/documents`. The `codigo` field SHALL NOT be sent in the request body — it is returned by the API.

#### Scenario: Successful create shows toast and redirects
- **WHEN** the form is submitted in create mode with valid data
- **THEN** `POST /api/documents` is called, a success toast appears, and the user is redirected to `/documents`

#### Scenario: Create response includes generated codigo
- **WHEN** `POST /api/documents` returns a successful response
- **THEN** the response body contains `codigo` in format `{tipo}-CD-00{n}` generated by MSW

### Requirement: Edit mode submits via PATCH and navigates on success
In edit mode, a valid form submission SHALL call `PATCH /api/documents/:id` with only the changed fields. On a successful response, the system SHALL invalidate the `["documents"]` query cache, show a `toast.success` notification, and navigate to `/documents`.

#### Scenario: Successful edit shows toast and redirects
- **WHEN** the form is submitted in edit mode with valid data
- **THEN** `PATCH /api/documents/:id` is called, the document cache is invalidated, a success toast appears, and the user is redirected to `/documents`

#### Scenario: Cancel navigates without saving
- **WHEN** the user clicks the Cancel button
- **THEN** the user is navigated to `/documents` and no API call is made

### Requirement: descripcion field is disabled for non-BORRADOR documents
The `descripcion` field SHALL be rendered as `disabled` (read-only, visually distinct) when the document `estado` is not `BORRADOR`. This prevents confusion if a user somehow reaches the edit form with a non-BORRADOR document (defense in depth beyond the page-level block).

#### Scenario: descripcion disabled in non-BORRADOR edit
- **WHEN** the edit form renders a document whose `estado` is not `BORRADOR`
- **THEN** the `descripcion` input has the `disabled` attribute and cannot receive focus

### Requirement: confidencialidad field controls document visibility level
The form SHALL render a required `<select>` field for `confidencialidad` positioned immediately after the `tipo` field. The select SHALL display four options sourced from i18n keys: `PUBLICO`, `INTERNO`, `CONFIDENCIAL`, `RESTRINGIDO`. The default selection SHALL be `INTERNO`.

#### Scenario: confidencialidad select shows four options
- **WHEN** the form renders
- **THEN** the `confidencialidad` select contains exactly 4 options: Público, Interno, Confidencial, Restringido

#### Scenario: Default value is INTERNO
- **WHEN** the user opens the form in create mode without pre-selecting a value
- **THEN** the `confidencialidad` field shows `INTERNO` as the selected option

### Requirement: rolesAutorizados field appears conditionally for RESTRINGIDO
The form SHALL render a multi-select field `rolesAutorizados` **only** when `confidencialidad` is `RESTRINGIDO`. The multi-select SHALL list all six system roles: `OPERARIO`, `SUPERVISOR`, `JEFE_CALIDAD_SYST`, `JEFE_CONTROL_DOCUMENTARIO`, `AUDITOR_INTERNO`, `ALTA_DIRECCION`. When `confidencialidad` changes away from `RESTRINGIDO`, the `rolesAutorizados` field SHALL be hidden and its value cleared via `setValue('rolesAutorizados', [])`.

#### Scenario: rolesAutorizados appears when RESTRINGIDO is selected
- **WHEN** the user selects `RESTRINGIDO` in the `confidencialidad` field
- **THEN** the `rolesAutorizados` multi-select becomes visible

#### Scenario: rolesAutorizados is hidden for non-RESTRINGIDO values
- **WHEN** `confidencialidad` is set to `PUBLICO`, `INTERNO`, or `CONFIDENCIAL`
- **THEN** the `rolesAutorizados` field is not rendered in the DOM

#### Scenario: Changing away from RESTRINGIDO clears rolesAutorizados
- **WHEN** the user selects `RESTRINGIDO`, picks some roles, then changes `confidencialidad` to `INTERNO`
- **THEN** the `rolesAutorizados` array is reset to empty and the field disappears

### Requirement: confidencialidad field is disabled for roles without permission
Only users with roles `JEFE_CONTROL_DOCUMENTARIO` or `ALTA_DIRECCION` SHALL be able to change the `confidencialidad` field. For all other roles that have access to the form (e.g., `JEFE_CALIDAD_SYST`, `SUPERVISOR`), the field SHALL render as `disabled` with the value locked to `INTERNO`. The role check SHALL read from `authStore.user.role`.

#### Scenario: JEFE_CONTROL_DOCUMENTARIO can change confidencialidad
- **WHEN** a user with role `JEFE_CONTROL_DOCUMENTARIO` views the form
- **THEN** the `confidencialidad` select is enabled and all four options are selectable

#### Scenario: JEFE_CALIDAD_SYST sees confidencialidad disabled at INTERNO
- **WHEN** a user with role `JEFE_CALIDAD_SYST` views the form
- **THEN** the `confidencialidad` select is disabled and shows `INTERNO`

#### Scenario: ALTA_DIRECCION can change confidencialidad
- **WHEN** a user with role `ALTA_DIRECCION` views the form
- **THEN** the `confidencialidad` select is enabled and all four options are selectable

### Requirement: revisorId and aprobadorId selects are populated from user fixtures
The `revisorId` and `aprobadorId` fields SHALL render as `<select>` elements populated with mock users from the document fixtures. Each option SHALL display the user's full name.

#### Scenario: Revisor select shows mock users
- **WHEN** the form renders
- **THEN** the `revisorId` select contains at least 4 options (empty + 3–4 named users)

### Requirement: fechaRevisionProxima auto-fills from fechaVigencia
When `fechaRevisionProxima` is empty on submit and `fechaVigencia` is set, the system SHALL calculate `fechaRevisionProxima` as `fechaVigencia + 365 calendar days` before sending the request. When `fechaVigencia` changes in the form, the system SHALL reset `fechaRevisionProxima` to empty if it was previously auto-filled.

#### Scenario: Auto-fill fires when fechaRevisionProxima is empty
- **WHEN** the user sets `fechaVigencia` to `2026-01-01` and leaves `fechaRevisionProxima` empty and submits
- **THEN** the submitted payload contains `fechaRevisionProxima: "2027-01-01"`

#### Scenario: Manual fechaRevisionProxima is not overwritten
- **WHEN** the user sets both `fechaVigencia` and `fechaRevisionProxima` explicitly and submits
- **THEN** the submitted payload contains the user-provided `fechaRevisionProxima` value unchanged

### Requirement: i18n keys for all form labels and messages
All visible text in the form SHALL use `t('documents:form.*')` keys. The namespace `documents` SHALL include the following keys in both `es-PE.json` and `en-US.json`:

`title_create`, `title_edit`, `field_titulo`, `field_tipo`, `field_area`, `field_version`, `field_revisor`, `field_aprobador`, `field_vigencia`, `field_revision`, `field_archivo`, `field_descripcion`, `btn_save`, `btn_cancel`, `success_create`, `success_edit`, `error_not_borrador`, `generating_code`, `field_confidencialidad`, `field_roles_autorizados`, `confidencialidad_publico`, `confidencialidad_interno`, `confidencialidad_confidencial`, `confidencialidad_restringido`, `hint_restringido`

#### Scenario: Form labels render in Spanish by default
- **WHEN** the application locale is `es-PE` (default)
- **THEN** all form labels, buttons, and messages display in Spanish

#### Scenario: Form labels render in English when locale is en-US
- **WHEN** the application locale is switched to `en-US`
- **THEN** all form labels, buttons, and messages display in English

### Requirement: DocumentsPage exposes a Nuevo Documento button
The `DocumentsPage` SHALL render a primary action button labeled `t('documents:actions.new_document')` that navigates to `/documents/new`. The button SHALL only be visible to roles with create permission (`JEFE_CONTROL_DOCUMENTARIO`, `JEFE_CALIDAD_SYST`).

#### Scenario: Button visible to JEFE_CONTROL_DOCUMENTARIO
- **WHEN** a user with role `JEFE_CONTROL_DOCUMENTARIO` views DocumentsPage
- **THEN** the "Nuevo documento" button is rendered

#### Scenario: Button hidden from OPERARIO
- **WHEN** a user with role `OPERARIO` views DocumentsPage
- **THEN** no "Nuevo documento" button is rendered

### Requirement: DocumentList shows Editar action only for BORRADOR documents
Each row in `DocumentList` SHALL show an "Editar" action that navigates to `/documents/:id/edit` **only** when the document `estado` is `BORRADOR` AND the current user has edit permission. For all other states, no edit action is shown for that row.

#### Scenario: Editar action shown for BORRADOR row
- **WHEN** a document with `estado: BORRADOR` appears in the list and the user has edit permission
- **THEN** an "Editar" action is visible for that row

#### Scenario: Editar action hidden for non-BORRADOR rows
- **WHEN** a document with `estado: PUBLICADO` or any non-BORRADOR state appears in the list
- **THEN** no "Editar" action is rendered for that row
