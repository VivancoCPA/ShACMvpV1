import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'
import { useAuthStore } from '../../../stores/authStore'
import { useUsers } from '../../nonconformities/hooks/useUsers'
import { useForzarVencimientoVerificacion } from '../hooks/useForzarVencimientoVerificacion'
import { useVerificacionEficacia } from '../hooks/useVerificacionEficacia'
import { getQualityEventPermissions } from '../utils/qualityEventPermissions'
import { verificacionEficaciaSchema, type VerificacionEficaciaInput } from '../schemas/verificacionEficacia.schema'
import type { QualityEvent, QEStatus } from '../types/qualityEvent.types'

const VISIBLE_STATES: QEStatus[] = ['CERRADO', 'EN_VERIFICACION', 'VERIFICADO']

interface QEVerificacionSectionProps {
  qe: QualityEvent
}

export function QEVerificacionSection({ qe }: QEVerificacionSectionProps) {
  const { t, i18n } = useTranslation('qualityEvents')
  const user = useAuthStore((s) => s.user)
  const { data: users = [] } = useUsers()
  const forzarVencimiento = useForzarVencimientoVerificacion()
  const verificacionEficacia = useVerificacionEficacia()
  const [auditorAsignadoId, setAuditorAsignadoId] = useState('')

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<VerificacionEficaciaInput>({
    resolver: zodResolver(verificacionEficaciaSchema),
    defaultValues: { resultado: 'EFECTIVO', evidencia: '' },
  })

  if (!VISIBLE_STATES.includes(qe.estado)) return null

  const permissions = user
    ? getQualityEventPermissions(qe.estado, user.rol, user.id === qe.auditorAsignadoId)
    : null

  const auditores = users.filter((u) => u.rol === 'AUDITOR_INTERNO')
  const showForzarVencimiento =
    import.meta.env.DEV && (qe.estado === 'CERRADO' || qe.estado === 'EN_VERIFICACION')
  const showAuditorSelect = showForzarVencimiento && qe.estado === 'CERRADO'
  const showForm = qe.estado === 'EN_VERIFICACION' && !!permissions?.puedeVerificar
  const showSummary = qe.estado === 'VERIFICADO'

  const dateFormatter = new Intl.DateTimeFormat(i18n.language, { dateStyle: 'short', timeStyle: 'short' })
  const inputClass =
    'w-full rounded-md border border-hairline bg-canvas px-3.5 py-2.5 text-sm text-ink focus:outline-none focus:ring-2 focus:ring-coral focus:border-coral dark:border-hairline/20 dark:bg-surface-dark dark:text-on-dark'
  const labelClass = 'mb-1 block text-sm font-medium text-body dark:text-on-dark-soft'

  // La entrega a Gerencia/Jefe de Calidad/Supervisor/reportante ahora ocurre vía
  // notificaciones reales y persistidas (RN-NOTIF-001, creadas por los handlers
  // `verificacion-eficacia` y `forzar-vencimiento-verificacion`) — estos toasts
  // solo confirman la acción propia de quien la realiza, sin afirmar que otras
  // personas fueron notificadas.
  const onForzarVencimiento = () => {
    forzarVencimiento.mutate(
      { id: qe.id, auditorAsignadoId: qe.estado === 'CERRADO' ? auditorAsignadoId : undefined },
      {
        onSuccess: (updated) => {
          if (updated.estado === 'EN_VERIFICACION') {
            toast.success(t('detail.verificacion.toasts.forzadoAVerificacion'))
          } else {
            toast.info(t('detail.verificacion.toasts.reapertura'))
          }
        },
      },
    )
  }

  const onSubmitVerificacion = (values: VerificacionEficaciaInput) => {
    verificacionEficacia.mutate(
      { id: qe.id, data: values },
      {
        onSuccess: (updated) => {
          reset()
          if (updated.estado === 'VERIFICADO') {
            toast.success(t('detail.verificacion.toasts.verificado'))
          } else {
            toast.info(t('detail.verificacion.toasts.reapertura'))
          }
        },
      },
    )
  }

  return (
    <section
      aria-labelledby="qe-verificacion-title"
      className="rounded-lg border border-hairline bg-surface-card p-6 dark:border-hairline/20 dark:bg-surface-dark-elevated"
    >
      <h2 id="qe-verificacion-title" className="mb-4 text-base font-medium text-ink dark:text-on-dark">
        {t('detail.verificacion.title')}
      </h2>

      {showForm && (
        <form onSubmit={(e) => void handleSubmit(onSubmitVerificacion)(e)} className="mb-4 space-y-4">
          <div>
            <span className={labelClass}>{t('detail.verificacion.form.resultado')}</span>
            <div className="flex gap-4">
              {(['EFECTIVO', 'NO_EFECTIVO'] as const).map((opt) => (
                <label key={opt} className="flex items-center gap-1.5 text-sm text-body dark:text-on-dark-soft">
                  <input type="radio" value={opt} className="accent-coral" {...register('resultado')} />
                  {t(`detail.verificacion.form.resultadoOptions.${opt}`)}
                </label>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="qe-verificacion-evidencia" className={labelClass}>
              {t('detail.verificacion.form.evidencia')}
            </label>
            <textarea
              id="qe-verificacion-evidencia"
              rows={4}
              className={inputClass}
              placeholder={t('detail.verificacion.form.evidenciaPlaceholder')}
              {...register('evidencia')}
            />
            {errors.evidencia && <p className="mt-1 text-xs text-error">{errors.evidencia.message}</p>}
          </div>

          <button
            type="submit"
            disabled={verificacionEficacia.isPending}
            className="rounded-md bg-coral px-4 py-2 text-sm font-medium text-white hover:bg-coral-dark disabled:opacity-60"
          >
            {t('detail.verificacion.form.submit')}
          </button>
        </form>
      )}

      {showSummary && (
        <dl className="mb-4 divide-y divide-hairline dark:divide-hairline/20">
          <div className="py-2.5 sm:grid sm:grid-cols-3 sm:gap-4">
            <dt className="text-sm font-medium text-muted dark:text-on-dark-soft">
              {t('detail.verificacion.summary.resultado')}
            </dt>
            <dd className="mt-0.5 text-sm text-body dark:text-on-dark sm:col-span-2 sm:mt-0">
              {qe.resultadoVerificacion
                ? t(`detail.verificacion.form.resultadoOptions.${qe.resultadoVerificacion}`)
                : '—'}
            </dd>
          </div>
          <div className="py-2.5 sm:grid sm:grid-cols-3 sm:gap-4">
            <dt className="text-sm font-medium text-muted dark:text-on-dark-soft">
              {t('detail.verificacion.summary.evidencia')}
            </dt>
            <dd className="mt-0.5 whitespace-pre-wrap text-sm text-body dark:text-on-dark sm:col-span-2 sm:mt-0">
              {qe.evidenciaVerificacion ?? '—'}
            </dd>
          </div>
          <div className="py-2.5 sm:grid sm:grid-cols-3 sm:gap-4">
            <dt className="text-sm font-medium text-muted dark:text-on-dark-soft">
              {t('detail.verificacion.summary.fechaVerificacionRealizada')}
            </dt>
            <dd className="mt-0.5 text-sm text-body dark:text-on-dark sm:col-span-2 sm:mt-0">
              {qe.fechaVerificacionRealizada ? dateFormatter.format(new Date(qe.fechaVerificacionRealizada)) : '—'}
            </dd>
          </div>
        </dl>
      )}

      {showForzarVencimiento && (
        <div className="flex flex-wrap items-end gap-2.5">
          {showAuditorSelect && (
            <div>
              <label htmlFor="qe-verificacion-auditorAsignado" className={labelClass}>
                {t('detail.verificacion.auditorAsignado.label')}
              </label>
              <select
                id="qe-verificacion-auditorAsignado"
                className={inputClass}
                value={auditorAsignadoId}
                onChange={(e) => setAuditorAsignadoId(e.target.value)}
              >
                <option value="">{t('detail.verificacion.auditorAsignado.placeholder')}</option>
                {auditores.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.nombre} {u.apellido}
                  </option>
                ))}
              </select>
            </div>
          )}
          <button
            type="button"
            onClick={onForzarVencimiento}
            disabled={forzarVencimiento.isPending || (showAuditorSelect && !auditorAsignadoId)}
            className="rounded-md border border-hairline bg-canvas px-4 py-2 text-xs font-medium text-muted hover:bg-surface-soft disabled:opacity-60 dark:border-hairline/20 dark:bg-surface-dark dark:text-on-dark-soft dark:hover:bg-surface-dark-soft"
          >
            {t('detail.verificacion.forzarVencimiento')}
          </button>
        </div>
      )}
    </section>
  )
}
