import type { QEStatus, QualityEvent } from '../types/qualityEvent.types'
import type { QEPermissions, QEEditAccess } from '../types/qualityEventPermissions.types'
import type { UserRole, User } from '../../../types/auth.types'

const ANTES_DE_CERRADO: QEStatus[] = [
  'ABIERTO',
  'EN_INVESTIGACION',
  'ANALISIS_COMPLETADO',
  'EN_EJECUCION',
  'PENDIENTE_CIERRE',
]

const DENY_ALL: QEPermissions = {
  puedeEditarCabecera: false,
  puedeEditarCausaRaiz: false,
  puedeAvanzarEstado: false,
  puedeCerrar: false,
  puedeFirmarCierre: false,
  puedeVerificar: false,
  puedeReabrir: false,
  soloLectura: true,
}

export function getQualityEventPermissions(
  estado: QEStatus,
  rol: UserRole,
  esResponsable: boolean,
): QEPermissions {
  switch (rol) {
    case 'OPERARIO':
      return { ...DENY_ALL, soloLectura: true }

    case 'SUPERVISOR': {
      const puedeEditarCabecera = estado === 'ABIERTO' && esResponsable
      const puedeAvanzarEstado = estado === 'ABIERTO'
      const puedeFirmarCierre = estado === 'PENDIENTE_CIERRE'
      return {
        ...DENY_ALL,
        puedeEditarCabecera,
        puedeAvanzarEstado,
        puedeFirmarCierre,
        soloLectura: false,
      }
    }

    case 'JEFE_CALIDAD_SYST': {
      const puedeEditarCabecera = estado === 'ABIERTO'
      const puedeEditarCausaRaiz =
        estado === 'EN_INVESTIGACION' || estado === 'ANALISIS_COMPLETADO'
      const puedeAvanzarEstado = estado !== 'VERIFICADO'
      const puedeCerrar = estado === 'PENDIENTE_CIERRE'
      const puedeVerificar = estado === 'EN_VERIFICACION'
      const puedeReabrir = estado === 'EN_VERIFICACION'
      return {
        ...DENY_ALL,
        puedeEditarCabecera,
        puedeEditarCausaRaiz,
        puedeAvanzarEstado,
        puedeCerrar,
        puedeVerificar,
        puedeReabrir,
        soloLectura: false,
      }
    }

    case 'AUDITOR_INTERNO': {
      const puedeVerificar = estado === 'EN_VERIFICACION' && esResponsable
      return {
        ...DENY_ALL,
        puedeVerificar,
        soloLectura: !puedeVerificar,
      }
    }

    case 'ALTA_DIRECCION': {
      const puedeFirmarCierre = estado === 'PENDIENTE_CIERRE' && esResponsable
      return {
        ...DENY_ALL,
        puedeFirmarCierre,
        soloLectura: !puedeFirmarCierre,
      }
    }

    case 'JEFE_CONTROL_DOCUMENTARIO':
      return { ...DENY_ALL, soloLectura: true }

    case 'ADMINISTRADOR_SISTEMA':
      return { ...DENY_ALL, soloLectura: true }

    case 'ADMINISTRADOR_EMPRESA':
      return { ...DENY_ALL, soloLectura: true }

    case 'SUPERADMIN':
      return { ...DENY_ALL, soloLectura: true }
  }
}

export function puedeExportarPDF(rol: UserRole): boolean {
  switch (rol) {
    case 'JEFE_CALIDAD_SYST':
    case 'SUPERVISOR':
    case 'AUDITOR_INTERNO':
    case 'ALTA_DIRECCION':
      return true

    case 'OPERARIO':
    case 'JEFE_CONTROL_DOCUMENTARIO':
    case 'ADMINISTRADOR_SISTEMA':
    case 'ADMINISTRADOR_EMPRESA':
    case 'SUPERADMIN':
      return false
  }
}

export function ventanaReporteInicialAbierta(qe: QualityEvent, ahora: Date): boolean {
  if (qe.estado !== 'ABIERTO') return false
  const transcurridoMs = ahora.getTime() - new Date(qe.fechaHoraReporte).getTime()
  return transcurridoMs <= 2 * 60 * 60 * 1000
}

export function resolveQEEditAccess(
  qe: QualityEvent,
  usuario: Pick<User, 'id' | 'rol' | 'areaIds'>,
  ahora: Date = new Date(),
): QEEditAccess {
  const esSupervisorDelArea =
    usuario.rol === 'SUPERVISOR' && (usuario.areaIds ?? []).includes(qe.areaId)

  const reporteInicial =
    ventanaReporteInicialAbierta(qe, ahora) &&
    (usuario.id === qe.reportadoPorId || esSupervisorDelArea)

  const rolEstadoValido = usuario.rol === 'JEFE_CALIDAD_SYST' && ANTES_DE_CERRADO.includes(qe.estado)
  const severidad = rolEstadoValido
  const mineral = rolEstadoValido && (qe.tipo === 'CALIDAD' || qe.tipo === 'OPERACIONAL')

  return { reporteInicial, severidad, mineral }
}

export function puedeEditarQE(
  qe: QualityEvent,
  usuario: Pick<User, 'id' | 'rol' | 'areaIds'>,
  ahora: Date = new Date(),
): boolean {
  const access = resolveQEEditAccess(qe, usuario, ahora)
  return access.reporteInicial || access.severidad || access.mineral
}

// RN-QE-004: la escalada a ALTA_DIRECCION por "misma persona" (firmante de la
// primera firma coincide con quien firmaría la segunda) se retiró el 2026-07-17
// por ser estructuralmente inalcanzable: User.rol es un valor singular, así que
// ningún usuario real puede ser JEFE_CALIDAD_SYST y SUPERVISOR del área a la vez.
// La rama solo se ejercitaba con un mock sintético fuera de authFixtures.
// Si en el futuro se adopta un modelo de roles múltiples, reconsiderar aquí.
export function resolveRolSegundaFirma(
  _primerFirmanteId: string,
  _areaId: string,
): 'SUPERVISOR' | 'ALTA_DIRECCION' {
  return 'SUPERVISOR'
}

export function validateTransitionToEnEjecucion(qe: QualityEvent): {
  valid: boolean
  reason?: string
} {
  if (!qe.causaRaizDefinitiva || !qe.causaRaizFirmadaEn) {
    return {
      valid: false,
      reason: 'Se requiere causa raíz definitiva aprobada y firmada antes de pasar a EN_EJECUCION',
    }
  }
  return { valid: true }
}

export function validateTransitionToPendienteCierre(qe: QualityEvent): {
  valid: boolean
  reason?: string
} {
  const bloqueada = qe.accionesCorrectivas.some(
    (ac) =>
      (ac.estado === 'PENDIENTE' || ac.estado === 'EN_EJECUCION') &&
      (!ac.descripcionEvidencia || ac.descripcionEvidencia.trim() === ''),
  )
  if (bloqueada) {
    return {
      valid: false,
      reason: 'Existen acciones correctivas pendientes o en ejecución sin evidencia',
    }
  }
  return { valid: true }
}

export function validateTransitionToCerrado(qe: QualityEvent): {
  valid: boolean
  reason?: string
} {
  if (!qe.cerradoPorId || !qe.cierreFirmaSupervisorId) {
    return {
      valid: false,
      reason: 'Se requiere firma dual: Jefe Calidad y Supervisor',
    }
  }
  return { valid: true }
}
